; party menu icons
; used in MonPartySpritePointers (see data/icon_pointers.asm)
	const_def
	const ICON_MON         ; $0
	const ICON_BALL        ; $1
	const ICON_HELIX       ; $2
	const ICON_FAIRY       ; $3
	const ICON_BIRD        ; $4
	const ICON_WATER       ; $5
	const ICON_BUG         ; $6
	const ICON_GRASS       ; $7
	const ICON_SNAKE       ; $8
	const ICON_QUADRUPED   ; $9
	const ICON_GOKU        ; $a (Pokemon Rad: Goku's overworld sprite)
	const ICON_VEGETA      ; $b (Pokemon Rad)
	const ICON_FRIEZA      ; $c (Pokemon Rad)
	const ICON_BULBASAUR   ; $d (Pokemon Rad: the starter lines)
	const ICON_TRADEBUBBLE ; $e
	const ICON_CHARMANDER  ; $f (Pokemon Rad)
; SQUIRTLE's line has no slot of its own: its 4 tiles sit in the unused odd
; tiles of the BUG and GRASS icons (which mirror their even ones)
DEF ICON_SQUIRTLE_TILE EQU ICON_BUG << 2 + 1

DEF ICONOFFSET EQU $40 ; difference between alternating icon frames' tile IDs
