; ===== Pokemon Rad: the fighters walking around (Goku, Vegeta, Frieza) =====
; The overworld sprite is the party's lead: a fighter, or a POKeMON's
; overworld shape. wUnusedObtainedBadges (saved) bit 0: the lead (Goku or
; VEGETA) is shown as a SUPER SAIYAN.
DEF wShownFighter EQUS "wUnusedObtainedBadges"

; a = the lead: 0 = Goku, 1 = VEGETA, 2 = FRIEZA, 3 = a POKeMON
GetShownFighter::
	ld a, [wPartyCount]
	and a
	ret z ; no party yet (a new game): Goku
	ld a, [wPartySpecies]
	cp VEGETA
	ld b, 1
	jr z, .done
	cp FRIEZA
	ld b, 2
	jr z, .done
	cp GOKU
	ld b, 0
	jr z, .done
	ld b, 3
.done
	ld a, b
	ret

; SELECT: Goku -> Goku SSJ -> next in the party -> ... (VEGETA gets his SSJ
; step too). The one shown leads the party.
GokuSwitchFighter::
	call InGravityRoom
	jr nz, .notGravityRoom
; GRAVITY ROOM: pick who trains (anyone in the party)
	ld a, [wUnusedMapVariable]
	inc a
	ld hl, wPartyCount
	cp [hl]
	jr c, .traineeOK
	xor a
.traineeOK
	ld [wUnusedMapVariable], a
	ld a, SFX_SWAP
	call PlaySound
	call LoadPlayerSpriteGraphics
	ld a, [wUnusedMapVariable]
	ld hl, wPartyMonNicks
	call GetPartyMonName
	ld a, 1
	ld [wDoNotWaitForButtonPressAfterDisplayingText], a
	ld a, 6 ; TEXT_BLUESHOUSE_GRAVITY_TRAINEE
	ldh [hTextID], a
	jp DisplayTextID
.notGravityRoom
	ld a, [wWalkBikeSurfState]
	and a
	jr z, .onFoot
	dec a
	ret nz ; surfing
	ldh a, [hGokuFlying]
	and a
	ret z ; only Goku rides the bike
	jr .nextInParty ; on the NIMBUS: no SUPER SAIYAN step
.onFoot
	ld a, [wShownFighter]
	bit 0, a
	jr nz, .nextInParty ; already SUPER SAIYAN: move on
	call GetShownFighter
	cp 2
	jr nc, .nextInParty
	call GokuKnowsSuperSaiyan
	jr nc, .nextInParty ; not unlocked yet (FRIEZA's battle)
	ld hl, wShownFighter
	set 0, [hl]
	ld a, SFX_TELEPORT_ENTER_1
	call PlaySound
	jp LoadPlayerSpriteGraphics
.nextInParty
	ld hl, wShownFighter
	res 0, [hl]
	ld a, [wPartyCount]
	cp 2
	jr c, .reload ; alone: just change back
	call RotatePartyLeft
	ld a, SFX_SWAP
	call PlaySound
.reload
	jp LoadPlayerSpriteGraphics

; replaces LoadWalkingPlayerSpriteGraphics
GokuLoadWalkingSprite::
	call GetWalkingSheet
	jp LoadFighterSheet

; Pokemon Rad: the walking frames, copied to spare OBJ tiles $60-$6B (the
; healing machine hop walks with them while the font sits over the usual ones)
GokuSpareWalkFrames::
	call GetWalkingSheet
	ld hl, 12 tiles
	add hl, de
	ld d, h
	ld e, l
	ld hl, vNPCSprites tile $60
	ld c, 12
	jp CopyVideoData

; de = the walking sheet to show, b = its bank
GetWalkingSheet:
	call InGravityRoom
	jr nz, .normal
	ld a, [wUnusedMapVariable]
	ld c, a
	ld b, 0
	ld hl, wPartySpecies
	add hl, bc
	ld a, [hl]
	jr LoadSpeciesSheet
.normal
	ld a, [wPartyCount]
	and a
	ld a, GOKU ; no party yet (a new game): Goku
	jr z, LoadSpeciesSheet
	ld a, [wShownFighter]
	bit 0, a
	jr z, .notSSJ
	call GokuKnowsSuperSaiyan
	jr c, .notSSJ ; (carry = he knows it)
	ld hl, wShownFighter
	res 0, [hl] ; not unlocked (any more): normal hair
.notSSJ
	ld a, [wPartySpecies]
	ld c, a
	ld a, [wShownFighter]
	bit 0, a
	ld a, c
	jr z, LoadSpeciesSheet
	ld de, GokuSSJSprite
	ld b, BANK(GokuSSJSprite)
	cp GOKU
	ret z
	ld de, VegetaSSJSprite
	ld b, BANK(VegetaSSJSprite)
	cp VEGETA
	ret z
; fallthrough

; a = species: load its walking sheet (fighters, or a POKeMON's shape)
LoadSpeciesSheet:
	ld de, RedSprite
	ld b, BANK(RedSprite)
	cp GOKU
	ret z
	ld de, BlueSprite
	ld b, BANK(BlueSprite)
	cp VEGETA
	ret z
	ld de, FriezaSprite
	ld b, BANK(FriezaSprite)
	cp FRIEZA
	ret z
; a POKeMON walks around: its party-menu shape
	ld d, a
	farcall GetMonOverworldIcon ; e = ICON_* << 2
	ld a, e
	ld de, BirdSprite
	ld b, BANK(BirdSprite)
	cp ICON_BIRD << 2
	ret z
	ld de, FairySprite
	ld b, BANK(FairySprite)
	cp ICON_FAIRY << 2
	ret z
	ld de, SeelSprite
	ld b, BANK(SeelSprite)
	cp ICON_WATER << 2
	ret z
	ld de, MonsterSprite
	ld b, BANK(MonsterSprite)
	ret

; replaces LoadBikePlayerSpriteGraphics: the bike (Goku only) or the NIMBUS
GokuLoadRidingSprite::
	ldh a, [hGokuFlying]
	and a
	jr nz, .nimbus
	ld hl, wShownFighter
	res 0, [hl]
	ld de, RedBikeSprite
	ld b, BANK(RedBikeSprite)
	jr LoadFighterSheet
.nimbus
; fallthrough

; the party's lead riding the NIMBUS (also used for the NIMBUS's FLY)
GokuLoadNimbusSheet::
	call GetNimbusSheet
	jp LoadFighterSheet

; the NIMBUS icon on the town map, when the NIMBUS is what flies
GokuNimbusTownMapIcon::
	call GetNimbusSheet
	ld hl, vSprites tile $04 ; (the town map's BIRD_BASE_TILE)
	ld c, 12
	jp CopyVideoData

; de = the lead's NIMBUS sheet, b = its bank
GetNimbusSheet:
	call GetShownFighter
	ld de, GokuNimbusSprite
	and a
	jr z, .gotNimbus
	ld de, VegetaNimbusSprite
	dec a
	jr z, .gotNimbus
	ld de, FriezaNimbusSprite
	dec a
	jr z, .gotNimbus
; a POKeMON on the cloud, in its overworld shape
	ld a, [wPartySpecies]
	ld d, a
	farcall GetMonOverworldIcon ; e = ICON_* << 2
	ld a, e
	ld de, BirdNimbusSprite
	cp ICON_BIRD << 2
	jr z, .gotNimbus
	ld de, FairyNimbusSprite
	cp ICON_FAIRY << 2
	jr z, .gotNimbus
	ld de, SeelNimbusSprite
	cp ICON_WATER << 2
	jr z, .gotNimbus
	ld de, MonsterNimbusSprite
.gotNimbus
	ld b, BANK(GokuNimbusSprite)
	ret

; de = 24-tile sheet, b = its bank
LoadFighterSheet:
	push bc
	push de
	ld hl, vNPCSprites
	ld c, 12
	call CopyVideoData
	pop de
	pop bc
	ld hl, 12 tiles
	add hl, de
	ld d, h
	ld e, l
	ld hl, vNPCSprites2
	ld c, 12
	jp CopyVideoData

; Goku's own cutscenes (MT.MOON blast) need Goku on screen
ShowGokuForCutscene::
	xor a
	ld [wShownFighter], a
	jp LoadPlayerSpriteGraphics

; Route 23: VEGETA steps in and turns SUPER SAIYAN in front of the guards
VegetaOverworldShowsUp::
	ld de, BlueSprite
	ld hl, vNPCSprites
	lb bc, BANK(BlueSprite), 12
	jp CopyVideoData

VegetaOverworldSuperSaiyan::
	ld de, VegetaSSJSprite
	ld hl, vNPCSprites
	lb bc, BANK(VegetaSSJSprite), 12
	jp CopyVideoData

; Bill's PC: VEGETA or FRIEZA (species in a) gets sucked into the PC
FighterSuckedIntoPC::
	ld de, BlueSprite
	ld b, BANK(BlueSprite)
	cp VEGETA
	jr z, .gotSprite
	ld de, FriezaSprite
	ld b, BANK(FriezaSprite)
.gotSprite
	ld hl, vSprites tile $7c
	ld c, 4 ; standing, facing down
	call CopyVideoData
	ld hl, wUpdateSpritesEnabled
	ld a, [hl]
	push af
	ld [hl], $ff
	ld a, SFX_TELEPORT_ENTER_1
	call PlaySound
	ld a, [wShadowOAMSprite00YCoord] ; start where the player is
	ld d, a
	ld a, [wShadowOAMSprite00XCoord]
	ld e, a
	ld b, 24
.loop
	push bc
	ld a, b
	and %10 ; flicker as it goes in
	call .draw
	call DelayFrame
	pop bc
	dec d ; up into the PC
	dec b
	jr nz, .loop
	xor a
	call .draw ; gone
	pop af
	ld [wUpdateSpritesEnabled], a
	jp ReloadMapSpriteTilePatterns

.draw ; d = Y, e = X, a = 0 to hide
	ld hl, wShadowOAMSprite36
	and a
	jr nz, .visible
	ld b, 4
.hideLoop
	ld [hli], a
	inc hl
	inc hl
	inc hl
	dec b
	jr nz, .hideLoop
	ret
.visible
	ld c, $7c
	ld a, d
	call .entry
	ld a, d
	call .entryRight
	ld a, d
	add 8
	call .entry
	ld a, d
	add 8
	jp .entryRight
.entry ; Y in a, X = e
	ld [hli], a
	ld a, e
	ld [hli], a
	ld a, c
	ld [hli], a
	inc c
	xor a
	ld [hli], a
	ret
.entryRight ; Y in a, X = e + 8
	ld [hli], a
	ld a, e
	add 8
	ld [hli], a
	ld a, c
	ld [hli], a
	inc c
	xor a
	ld [hli], a
	ret

GokuNimbusSprite::   INCBIN "gfx/sprites/goku_nimbus.2bpp"
MonsterNimbusSprite: INCBIN "gfx/sprites/monster_nimbus.2bpp"
BirdNimbusSprite:    INCBIN "gfx/sprites/bird_nimbus.2bpp"
FairyNimbusSprite:   INCBIN "gfx/sprites/fairy_nimbus.2bpp"
SeelNimbusSprite:    INCBIN "gfx/sprites/seel_nimbus.2bpp"
VegetaNimbusSprite:: INCBIN "gfx/sprites/vegeta_nimbus.2bpp"
FriezaNimbusSprite:: INCBIN "gfx/sprites/frieza_nimbus.2bpp"
VegetaSSJSprite::    INCBIN "gfx/sprites/vegeta_ssj.2bpp"

; z if the player is in the GRAVITY TRAINING ROOM (Vegeta's old house)
InGravityRoom:
	ld a, [wCurMap]
	cp BLUES_HOUSE
	ret nz
	CheckEvent EVENT_FRIEZA_JOINED
	jr z, .no
	xor a
	ret
.no
	or 1
	ret

; GRAVITY ROOM, machine on. Called every idle overworld frame.
; Each step = massive EXP for the trainee; walking is very slow.
; Returns e = 1 if a level-up text should show.
GravityRoomTick::
	ld e, 0
	ld a, [wYCoord]
	swap a
	ld b, a
	ld a, [wXCoord]
	or b
	ld hl, wUnusedLastMapWidth
	cp [hl]
	jr z, .noStep
	ld [hl], a
; one, two or four rounds of EXP depending on the setting
	ld b, 1
	CheckEvent EVENT_GRAVITY_X2
	jr z, .notX2
	ld b, 2
.notX2
	CheckEvent EVENT_GRAVITY_X4
	jr z, .gotRounds
	ld b, 4
.gotRounds
	ld c, 0
.round
	push bc
	call GravityGiveExp ; e: bit 0 = leveled, bit 1 = unlocked a setting
	pop bc
	ld a, e
	or c
	ld c, a
	dec b
	jr nz, .round
	ld e, c
	ret
.noStep
	call .slowWalk
	ld e, 0
	ret
.slowWalk ; heavy gravity: a held direction waits before the step starts
	ldh a, [hJoyHeld] ; (from last frame: calling Joypad here would eat button presses)
	and PAD_CTRL_PAD
	ret z
	ld c, 64 ; frames per step when walking
.wait
	push bc
	call DelayFrame
	call Joypad
	pop bc
	ldh a, [hJoyHeld]
	and PAD_CTRL_PAD
	ret z ; let go
	dec c
	jr nz, .wait
	ret

; gives the trainee 3*L*L+100 EXP, handles level ups. e = 1 if leveled
GravityGiveExp:
	ld e, 0
	ld a, [wUnusedMapVariable]
	ld hl, wPartyCount
	cp [hl]
	jr c, .indexOK
	xor a
	ld [wUnusedMapVariable], a
.indexOK
	ld [wWhichPokemon], a
	ld hl, wPartyMon1
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	push hl
	ld bc, MON_LEVEL
	add hl, bc
	ld a, [hl]
	pop hl
	cp MAX_LEVEL
	ret nc
; de = 3*L*L + 100
	ld c, a
	ld b, a ; counter
	push hl
	ld hl, 100
	ld d, 0
	ld e, c
.mulLoop
	add hl, de
	add hl, de
	add hl, de
	dec b
	jr nz, .mulLoop
	ld d, h
	ld e, l
	pop hl
	push hl
	ld bc, MON_EXP + 2
	add hl, bc
	ld a, [hl]
	add e
	ld [hld], a
	ld a, [hl]
	adc d
	ld [hld], a
	ld a, [hl]
	adc 0
	ld [hl], a
	xor a ; PLAYER_PARTY_DATA
	ld [wMonDataLocation], a
	call LoadMonData
	farcall CalcLevelFromExperience ; d = new level
	ld a, d
	cp MAX_LEVEL + 1
	jr c, .levelOK
	ld d, MAX_LEVEL
.levelOK
	pop hl
	push hl
	ld bc, MON_LEVEL
	add hl, bc
	ld a, [hl]
	cp d
	jp nc, .noLevelUp
	ld a, d
	ld [hl], a
	ld [wCurEnemyLevel], a
	pop hl
	push hl
	ld a, [hl] ; species
	ld [wCurSpecies], a
	ld [wPokedexNum], a
	call GetMonHeader
	pop hl
	push hl
	ld bc, MON_MAXHP
	add hl, bc
	ld a, [hli]
	ld b, a
	ld c, [hl] ; bc = old max HP
	push bc
	dec hl
	ld d, h
	ld e, l ; de = max HP (stats start here)
	ld bc, (MON_HP_EXP - 1) - MON_MAXHP
	add hl, bc
	ld b, 1 ; use stat exp
	call CalcStats
	pop bc ; old max HP
	pop hl
	push hl
	ld de, MON_MAXHP + 1
	add hl, de
	ld a, [hld]
	sub c
	ld c, a
	ld a, [hl]
	sbc b
	ld b, a ; HP gained
	pop hl
	push hl
	ld de, MON_HP + 1
	add hl, de
	ld a, [hl]
	add c
	ld [hld], a
	ld a, [hl]
	adc b
	ld [hl], a
; the text: name, level (fighters show 9000+)
	ld a, [wWhichPokemon]
	ld hl, wPartyMonNicks
	call GetPartyMonName
	pop hl
	ld a, [hl] ; species
	call IsCustomFighter
	ld a, 0
	jr nz, .gotFlag
	inc a
.gotFlag
	ld [wStringBuffer + 15], a
	ld a, [wCurEnemyLevel]
	ld c, a
	ld b, 0
	ld hl, 0
	ld a, [wStringBuffer + 15]
	and a
	jr z, .gotBase
	ld hl, 9000 - 10
.gotBase
	add hl, bc
	ld a, h
	ld [wStringBuffer], a
	ld a, l
	ld [wStringBuffer + 1], a
	ld e, 1
	ld a, [wCurEnemyLevel]
	cp MAX_LEVEL
	ret nz
; maxed out: the first time unlocks 200x, the second 400x
	CheckEvent EVENT_GRAVITY_200X_UNLOCKED
	jr nz, .try400
	SetEvent EVENT_GRAVITY_200X_UNLOCKED
	ld e, 3
	ret
.try400
	CheckEvent EVENT_GRAVITY_400X_UNLOCKED
	ret nz
	SetEvent EVENT_GRAVITY_400X_UNLOCKED
	ld e, 3
	ret
.noLevelUp
	pop hl
	ld e, 0
	ret

; the lead goes to the back of the party; everyone else moves up one
RotatePartyLeft:
	ld a, [wPartyCount]
	dec a
	ret z
	ld c, 0
.loop
	push af
	push bc
	ld a, c
	call SwapPartyWithNext
	pop bc
	pop af
	inc c
	dec a
	jr nz, .loop
	ret

; swaps party slots a and a+1 (species, data, OT name, nickname)
SwapPartyWithNext:
	push af
	ld hl, wPartySpecies
	ld e, a
	ld d, 0
	add hl, de
	ld d, h
	ld e, l
	inc de
	ld c, 1
	call .swap
	pop af
	push af
	ld hl, wPartyMon1
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	ld d, h
	ld e, l
	ld bc, PARTYMON_STRUCT_LENGTH
	call .addDE
	ld c, PARTYMON_STRUCT_LENGTH
	call .swap
	pop af
	push af
	ld hl, wPartyMonOT
	ld bc, NAME_LENGTH
	call AddNTimes
	ld d, h
	ld e, l
	ld bc, NAME_LENGTH
	call .addDE
	ld c, NAME_LENGTH
	call .swap
	pop af
	ld hl, wPartyMonNicks
	ld bc, NAME_LENGTH
	call AddNTimes
	ld d, h
	ld e, l
	ld bc, NAME_LENGTH
	call .addDE
	ld c, NAME_LENGTH
	jr .swap
.addDE ; de += bc
	ld a, e
	add c
	ld e, a
	ld a, d
	adc b
	ld d, a
	ret
.swap ; swap c bytes at hl and de
	ld a, [de]
	ld b, [hl]
	ld [hli], a
	ld a, b
	ld [de], a
	inc de
	dec c
	jr nz, .swap
	ret

; ===== Pokemon Rad: the GRAVITY ROOM, inside and out =====
; The map blocks are patched straight into wOverworldMap when a map loads
; (before it's drawn), so nothing pops in. The CAPSULE CORP. sphere's tiles
; go over tiles that PALLET TOWN and ROUTE 1 never use.

; called right after a map's tiles are loaded (LCD off)
GravityDomeLoadTiles::
	CheckEvent EVENT_FRIEZA_JOINED
	ret z
	ld a, [wCurMap]
	cp BLUES_HOUSE
	jr nz, .notRoom
	ld hl, GravityRoomBlocks
	jp PatchMapBlocks
.notRoom
	and a ; PALLET_TOWN
	jr z, .pallet
	cp ROUTE_1
	ret nz
	ld hl, Route1DomeBlocks ; PALLET TOWN shows at ROUTE 1's south end
	call PatchMapBlocks
	jr .tiles
.pallet
	ld hl, PalletDomeBlocks
	call PatchMapBlocks
.tiles
	ld hl, GravityDomeTileRuns
	ld de, GravityDomeGfx
.run
	ld a, [hli]
	cp -1
	ret z
	push hl
	call DomeTileVRAM ; hl = VRAM address
	pop bc
	ld a, [bc] ; tiles in this run
	inc bc
	push bc
	push hl
	ld h, d
	ld l, e ; hl = the graphics
	pop de ; de = VRAM
	swap a
	ld c, a
	and $0f
	ld b, a
	ld a, c
	and $f0
	ld c, a ; bc = count * 16
	call CopyData ; hl advances to the next run's graphics
	ld d, h
	ld e, l
	pop hl
	jr .run

; crossing a map connection (no reload): put the sphere in, load or give
; back the borrowed tiles (the LCD is on here)
GravityDomeConnection::
	CheckEvent EVENT_FRIEZA_JOINED
	ret z
	ld a, [wCurMap]
	and a ; PALLET_TOWN
	jr nz, .notPallet
	ld hl, PalletDomeBlocks
	call PatchMapBlocks
	ld a, [wYCoord]
	cp 8
	ret c ; from ROUTE 1: the tiles are already there
	jr LoadDomeTilesLCDOn ; from ROUTE 21
.notPallet
	cp ROUTE_1
	jr nz, .notRoute1
	ld hl, Route1DomeBlocks
	call PatchMapBlocks
	ld a, [wYCoord]
	cp 18
	ret nc ; from PALLET TOWN
	jr LoadDomeTilesLCDOn ; from VIRIDIAN CITY
.notRoute1
	cp ROUTE_21
	jr nz, .notRoute21
	ld a, [wYCoord]
	cp 10
	ret nc ; from CINNABAR
	jr RestoreDomeTilesLCDOn ; from PALLET TOWN
.notRoute21
	cp VIRIDIAN_CITY
	ret nz
	ld a, [wYCoord]
	cp 20
	ret c ; not from ROUTE 1
	jr RestoreDomeTilesLCDOn

LoadDomeTilesLCDOn:
	ld hl, GravityDomeTileRuns
	ld de, GravityDomeGfx
.run
	ld a, [hli]
	cp -1
	ret z
	push hl
	call DomeTileVRAM
	pop bc
	ld a, [bc]
	inc bc
	push bc
	ld c, a
	push bc
	ld b, BANK(GravityDomeGfx)
	push de
	call CopyVideoData ; de = graphics, hl = VRAM, c = tiles
	pop de
	pop bc ; c = tiles
	swap c ; (count < 16) * 16
	ld a, e
	add c
	ld e, a
	jr nc, .noCarry
	inc d
.noCarry
	pop hl
	jr .run

RestoreDomeTilesLCDOn: ; copy them back from the tileset
	ld hl, GravityDomeTileRuns
.run
	ld a, [hli]
	cp -1
	ret z
	push hl
	call DomeTileVRAM ; hl = VRAM, bc = id * 16
	push hl
	ld a, [wTilesetGfxPtr]
	ld l, a
	ld a, [wTilesetGfxPtr + 1]
	ld h, a
	add hl, bc
	ld d, h
	ld e, l
	pop hl
	pop bc
	ld a, [bc]
	inc bc
	push bc
	ld c, a
	ld a, [wTilesetBank]
	ld b, a
	call CopyVideoData
	pop hl
	jr .run

; a = tile id -> hl = its VRAM address, bc = id * 16 (de kept)
DomeTileVRAM:
	ld l, a
	ld h, 0
	add hl, hl
	add hl, hl
	add hl, hl
	add hl, hl
	ld b, h
	ld c, l
	push bc
	ld bc, vTileset
	add hl, bc
	pop bc
	ret

; hl = list of y, x, block (-1 ends): write them into wOverworldMap
PatchMapBlocks:
	ld a, [hli]
	cp -1
	ret z
	push hl
	add 3 ; the map has a 3-block border
	ld b, a
	ld a, [wCurMapWidth]
	add 6
	ld e, a
	ld d, 0
	ld hl, wOverworldMap
.row
	add hl, de
	dec b
	jr nz, .row
	pop de ; de = list
	ld a, [de] ; x
	inc de
	add 3
	add l
	ld l, a
	jr nc, .noCarry
	inc h
.noCarry
	ld a, [de] ; block
	inc de
	ld [hl], a
	ld h, d
	ld l, e
	jr PatchMapBlocks

PalletDomeBlocks:
	db 1, 6, $04
	db 1, 7, $17
	db 2, 6, $46
	db 2, 7, $4a
	db -1

Route1DomeBlocks: ; the same blocks, in ROUTE 1's view of PALLET TOWN
	db 18 + 1, 6, $04
	db 18 + 1, 7, $17
	db 18 + 2, 6, $46
	db 18 + 2, 7, $4a
	db -1

GravityRoomBlocks: ; the round GRAVITY ROOM (portholes, the machine in the middle)
	db 0, 0, $23
	db 0, 1, $24
	db 0, 2, $25
	db 0, 3, $26
	db 1, 0, $27
	db 1, 1, $28
	db 1, 2, $29
	db 1, 3, $2a
	db 2, 0, $2b
	db 2, 1, $2c
	db 2, 2, $2d
	db 2, 3, $2e
	db 3, 0, $2f
	db 3, 1, $30
	db 3, 2, $31
	db 3, 3, $32
	db -1

INCLUDE "data/tilesets/gravity_dome_tiles.asm"

GravityDomeGfx:
	INCBIN "gfx/tilesets/gravity_dome.2bpp"

; after a level-up in the GRAVITY ROOM: maybe the trainee evolves
GravityTryEvolve::
	ld a, [wStringBuffer + 15]
	and a
	ret nz ; the fighters don't evolve
	ld a, [wUnusedMapVariable]
	ld [wWhichPokemon], a
	xor a
	ld [wForceEvolution], a
	ld [wCurItem], a
	callfar TryEvolvingMon
	ld a, [wEvolutionOccurred]
	and a
	ret z
; back to the room: closing the text box redraws the map and sprites
	ld a, 1
	ld [wUpdateSpritesEnabled], a
	jp RunDefaultPaletteCommand

; ===== Pokemon Rad: the fighters' special moves =====
; CUT, FLY, SURF, STRENGTH, FLASH and TELEPORT need no BADGEs for them.
; wShownFighter bits 4-5: the fighter using FLY (1 Goku, 2 VEGETA, 3 FRIEZA)

; a = the species of the party mon in wWhichPokemon
FieldMoveUserSpecies:
	ld a, [wWhichPokemon]
	ld c, a
	ld b, 0
	ld hl, wPartySpecies
	add hl, bc
	ld a, [hl]
	ret

; e = the BADGEs the field move checks ($ff for a fighter)
; z if the party mon in wWhichPokemon is a fighter
FieldMoveUserIsFighter::
	call FieldMoveUserSpecies
	jp IsCustomFighter

FieldMoveBadges::
	call FieldMoveUserSpecies
	call IsCustomFighter
	ld e, $ff
	ret z
	ld a, [wObtainedBadges]
	ld e, a
	ret

FighterFlySetup::
	call FighterFlyCancel
	call FieldMoveUserSpecies
	ld b, 1 << 4
	cp GOKU
	jr z, .set
	ld b, 2 << 4
	cp VEGETA
	jr z, .set
	ld b, 3 << 4
	cp FRIEZA
	ret nz
.set
	ld a, [wShownFighter]
	or b
	ld [wShownFighter], a
	ret

FighterFlyCancel::
	ld a, [wShownFighter]
	and %11001111
	ld [wShownFighter], a
	ret

; de, b = the walking sheet of the fighter using FLY
GetFlyingFighterSheet:
	ld a, [wShownFighter]
	swap a
	and %11
	ld c, a
	ld a, GOKU
	dec c
	jr z, .got
	ld a, VEGETA
	dec c
	jr z, .got
	ld a, FRIEZA
.got
	jp LoadSpeciesSheet

; the fly animation: the fighter himself, not a bird
GokuLoadFighterFlySheet::
	call GetFlyingFighterSheet
	jp LoadFighterSheet

GokuFighterTownMapIcon::
	call GetFlyingFighterSheet
	ld hl, vSprites tile $04 ; (the town map's BIRD_BASE_TILE)
	ld c, 12
	jp CopyVideoData

; replaces LoadSurfingPlayerSpriteGraphics: the fighters swim themselves
; (with a fighter in the party the lead SURFs riding the NIMBUS)
GokuLoadSurfSprite::
	ld hl, wPartySpecies
.fighterLoop
	ld a, [hli]
	cp $ff
	jr z, .seel
	call IsCustomFighter
	jr nz, .fighterLoop
	call GetNimbusSheet
	jp LoadFighterSheet
.seel
	ld de, SeelSprite
	ld b, BANK(SeelSprite)
	jp LoadFighterSheet

; the yells before the fighters' special moves (wNameBuffer = the user)
FighterYellCut::
	ld hl, .DestructoDiskText
	jr FighterYell
.DestructoDiskText:
	text_ram wNameBuffer
	text ":"
	line "DESTRUCTO DISK!"
	prompt

FighterYellFlash::
	ld hl, .SolarFlareText
	jr FighterYell
.SolarFlareText:
	text_ram wNameBuffer
	text ":"
	line "SOLAR FLARE!"
	prompt

FighterYellTeleport::
	ld hl, .InstantTransmissionText
	jr FighterYell
.InstantTransmissionText:
	text_ram wNameBuffer
	text ":"
	line "INSTANT"
	cont "TRANSMISSION!"
	prompt

FighterYell:
	push hl
	call FieldMoveUserSpecies
	call IsCustomFighter
	pop hl
	ret nz
	jp PrintText

; carry if Goku (in the party) knows SUPER SAIYAN: only then can Goku and
; VEGETA go SUPER SAIYAN in the overworld
GokuKnowsSuperSaiyan:
	ld hl, wPartySpecies
	ld de, wPartyMon1Moves
.find
	ld a, [hli]
	cp $ff
	jr z, .no
	cp GOKU
	jr z, .found
	push hl
	ld hl, PARTYMON_STRUCT_LENGTH
	add hl, de
	ld d, h
	ld e, l
	pop hl
	jr .find
.found
	ld b, NUM_MOVES
.check
	ld a, [de]
	inc de
	cp SUPER_SAIYAN
	jr z, .yes
	dec b
	jr nz, .check
.no
	and a
	ret
.yes
	scf
	ret
