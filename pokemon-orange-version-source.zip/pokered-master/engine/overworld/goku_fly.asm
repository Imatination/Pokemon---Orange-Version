; ===== Pokemon Rad: flying on the NIMBUS =====

; Collision check while flying. Goku ignores walls, water and people, but he can't
; leave the map where there is nothing on the other side.
; Returns carry if he can't move in the direction he's facing.
GokuFlyCollisionCheck::
	ld a, [wYCoord]
	ld d, a
	ld a, [wXCoord]
	ld e, a
	ld a, [wPlayerDirection]
	bit PLAYER_DIR_BIT_UP, a
	jr z, .notUp
	dec d
	jr .gotTarget
.notUp
	bit PLAYER_DIR_BIT_DOWN, a
	jr z, .notDown
	inc d
	jr .gotTarget
.notDown
	bit PLAYER_DIR_BIT_LEFT, a
	jr z, .notLeft
	dec e
	jr .gotTarget
.notLeft
	inc e
.gotTarget
; inside the map? (out-of-range values, including -1, compare as too big)
	ld a, [wCurMapHeight]
	add a
	ld b, a
	ld a, d
	cp b
	jr nc, .offMap
	ld a, [wCurMapWidth]
	add a
	ld b, a
	ld a, e
	cp b
	jr nc, .offMap
	and a
	ret
.offMap
; Pokemon Rad: ROUTE 22's (unused) link north to ROUTE 23 joins two different
; tilesets: flying across it scrambles the map, so it's closed
	ld a, [wCurMap]
	cp ROUTE_22
	jr nz, .notRoute22
	ld a, [wPlayerDirection]
	bit PLAYER_DIR_BIT_UP, a
	jr nz, .blocked
	jr .edgeCheck
.notRoute22
	cp ROUTE_23
	jr nz, .edgeCheck
	ld a, [wPlayerDirection]
	bit PLAYER_DIR_BIT_DOWN, a
	jr nz, .blocked
.edgeCheck
; Beyond the edge, the map buffer holds either the next area's real blocks or the
; map's filler "background" block. Only fly across where there's a real area.
	ld a, d
	add MAP_BORDER * 2
	srl a
	ld b, a ; block row in the padded map
	ld a, e
	add MAP_BORDER * 2
	srl a
	ld c, a ; block column in the padded map
	ld a, [wCurMapWidth]
	add MAP_BORDER * 2
	ld e, a
	ld d, 0
	ld hl, wOverworldMap
	ld a, b
	and a
	jr z, .addColumn
.rowLoop
	add hl, de
	dec b
	jr nz, .rowLoop
.addColumn
	ld b, 0
	add hl, bc
	ld a, [wMapBackgroundTile]
	cp [hl]
	jr z, .blocked
	and a
	ret
.blocked
	scf
	ret

; ----- landing anywhere -----

; Land the NIMBUS. Over a wall, a tree, water or a person, the cloud first
; bounces Goku over to the nearest spot he can stand on.
; nc: landed right here. carry + a=1: drifting to a landing spot (lands when the
; drift ends). carry + a=0: no land anywhere nearby.
GokuTryLand::
; Pokemon Rad: over water the rider dives in and SURFs
	ld a, [wCurMapTileset]
	and a ; OVERWORLD
	jr nz, .notWater
	lda_coord 8, 9 ; the tile under the player
	cp $14 ; water
	jr nz, .notWater
	xor a
	ldh [hGokuFlying], a
	ld a, 2
	ld [wWalkBikeSurfState], a
	call LoadPlayerSpriteGraphics
	call PlayDefaultMusic
	and a
	ret
.notWater
	ld a, [wYCoord]
	ld d, a
	ld a, [wXCoord]
	ld e, a
	call GokuLandCheckAt
	jp nc, GokuLandNow
	ld c, 1 ; search radius
.ringLoop
	ld a, $ff
	ld [wBuffer + 1], a ; best score so far (none)
	ld a, c
	cpl
	inc a
	ld d, a ; dy = -radius
.dyLoop
	ld a, c
	cpl
	inc a
	ld e, a ; dx = -radius
.dxLoop
	ld a, d
	call .abs
	cp c
	jr z, .onRing
	ld a, e
	call .abs
	cp c
	jr nz, .nextDx
.onRing
	push bc
	push de
	ld a, [wYCoord]
	add d
	ld d, a
	ld a, [wXCoord]
	add e
	ld e, a
	call GokuLandCheckAt
	jr c, .notHere
; score = distance from the middle of the map (prefer landing inside the area)
	ld a, [wCurMapHeight]
	sub d
	call .abs
	ld b, a
	ld a, [wCurMapWidth]
	sub e
	call .abs
	add b
	jr nc, .noOverflow
	ld a, $fe
.noOverflow
	ld b, a
	ld a, [wBuffer + 1]
	cp b
	jr c, .notHere
	jr z, .notHere
	pop de
	push de
	ld a, b
	ld [wBuffer + 1], a
	ld a, d
	ld [wBuffer + 2], a
	ld a, e
	ld [wBuffer + 3], a
.notHere
	pop de
	pop bc
.nextDx
	ld a, e
	cp c
	jr z, .nextDy
	inc e
	jr .dxLoop
.nextDy
	ld a, d
	cp c
	jr z, .nextRing
	inc d
	jr .dyLoop
.nextRing
	ld a, [wBuffer + 1]
	inc a
	jr nz, .gotBest
	inc c
	ld a, c
	cp 31
	jp c, .ringLoop
	xor a ; nowhere to land
	scf
	ret
.gotBest
	ld a, [wBuffer + 2]
	ld d, a
	ld a, [wBuffer + 3]
	ld e, a
	ld a, c
	cp 5
	jp nc, GokuTeleportLand ; too far to drift over: teleport down instead
.found
	ld hl, wSimulatedJoypadStatesEnd
	ld b, 0
	ld a, e
	ld c, PAD_RIGHT
	bit 7, a
	jr z, .gotX
	cpl
	inc a
	ld c, PAD_LEFT
.gotX
	call .fill
	ld a, d
	ld c, PAD_DOWN
	bit 7, a
	jr z, .gotY
	cpl
	inc a
	ld c, PAD_UP
.gotY
	call .fill
	ld a, b
	ld [wSimulatedJoypadStatesIndex], a
	call StartSimulatingJoypadStates
	ld a, $ff
	ld [wJoyIgnore], a
	ld a, 2 ; landing as soon as the drift ends
	ldh [hGokuFlying], a
	ld a, SFX_LEDGE ; boing!
	call PlaySound
	ld a, 1
	scf
	ret

.fill ; a entries of button c at hl
	and a
	ret z
.fillLoop
	ld [hl], c
	inc hl
	inc b
	dec a
	jr nz, .fillLoop
	ret

.abs
	bit 7, a
	ret z
	cpl
	inc a
	ret

; Pokemon Rad: solid ground is far away (out at sea): Goku teleports down
; onto it. d, e = how far it is (Y, X)
GokuTeleportLand:
	ld a, [wYCoord]
	add d
	ld [wYCoord], a
	ld b, a
	and 1
	ld [wYBlockCoord], a
	ld a, [wXCoord]
	add e
	ld [wXCoord], a
	ld c, a
	and 1
	ld [wXBlockCoord], a
; the view: 1 block in from the map's 3-block border, like a warp sets it
	ld a, [wCurMapWidth]
	add MAP_BORDER * 2
	ld e, a
	ld d, 0
	ld hl, wOverworldMap + 1
	add hl, de
	ld a, b
	srl a
	jr z, .rowsDone
.rowLoop
	add hl, de
	dec a
	jr nz, .rowLoop
.rowsDone
	ld a, c
	srl a
	add l
	ld l, a
	jr nc, .noCarry
	inc h
.noCarry
	ld a, l
	ld [wCurrentTileBlockMapViewPointer], a
	ld a, h
	ld [wCurrentTileBlockMapViewPointer + 1], a
	ld a, SFX_TELEPORT_ENTER_1
	call PlaySound
	xor a
	ldh [hGokuFlying], a
	ld [wWalkBikeSurfState], a
	ld hl, wFontLoaded
	res BIT_FONT_LOADED, [hl] ; (else the map reload would wait for V-blank with the LCD off)
	call LoadMapData ; redraw everything at the new spot
	call PlayDefaultMusic
	and a ; landed
	ret

GokuLandNow:
	xor a
	ldh [hGokuFlying], a
	ld [wWalkBikeSurfState], a
	call LoadPlayerSpriteGraphics ; (no font reload: it shares VRAM with the walking frames)
	call PlayDefaultMusic
	and a
	ret

; Each overworld tick while flying: finish a bounce landing once the drift is over.
GokuLandingTick::
	ldh a, [hGokuFlying]
	cp 2
	ret nz
	ld a, [wStatusFlags5]
	bit BIT_SCRIPTED_MOVEMENT_STATE, a
	ret nz
	ld a, 1
	ldh [hGokuFlying], a
	jp GokuTryLand

; SELECT: hop on or off the NIMBUS (once Goku has it).
GokuSelectNimbus::
	ld b, BICYCLE
	call IsItemInBag
	ret z
	ld a, [wWalkBikeSurfState]
	and a
	jr z, .getOn
	dec a
	ret nz ; surfing
	ldh a, [hGokuFlying]
	and a
	jr z, GokuLandNow
	call GokuTryLand
	ret nc
	and a
	ret nz ; bouncing over to solid ground
	ld a, SFX_DENIED
	jp PlaySound
.getOn
	call GokuNimbusArrives
	xor a
	ldh [hJoyHeld], a
	inc a
	ld [wWalkBikeSurfState], a
	ldh [hGokuFlying], a
	call LoadPlayerSpriteGraphics ; also puts back the walking frames over the font
	jp PlayDefaultMusic

; d = map Y, e = map X (in steps). Returns carry if Goku can't land there
; (off the map, a wall, a roof, water, a tree, or someone standing there).
GokuLandCheckAt:
	ld a, [wCurMapHeight]
	add a
	ld b, a
	ld a, d
	cp b
	jp nc, .cantLand
	ld a, [wCurMapWidth]
	add a
	ld b, a
	ld a, e
	cp b
	jp nc, .cantLand
	push de
; block under that spot
	ld a, [wCurMapWidth]
	add MAP_BORDER * 2
	ld c, a
	ld b, 0
	ld hl, wOverworldMap
	ld a, d
	srl a
	add MAP_BORDER
.rowLoop
	add hl, bc
	dec a
	jr nz, .rowLoop
	ld a, e
	srl a
	add MAP_BORDER
	ld c, a
	add hl, bc
	ld l, [hl]
	ld h, 0
	add hl, hl
	add hl, hl
	add hl, hl
	add hl, hl ; 16 tiles per block
; the bottom-left tile of that quarter of the block
	ld a, d
	and 1
	add a
	add a
	add a
	add 4
	ld c, a
	ld a, e
	and 1
	add a
	add c
	ld c, a
	ld b, 0
	add hl, bc
	ld a, [wTilesetBlocksPtr]
	ld c, a
	ld a, [wTilesetBlocksPtr + 1]
	ld b, a
	add hl, bc
	ld a, [wTilesetBank]
	ld de, wStringBuffer
	ld bc, 1
	call FarCopyData
	pop de
	ld a, [wStringBuffer]
	ld c, a
	ld hl, wTilesetCollisionPtr
	ld a, [hli]
	ld h, [hl]
	ld l, a
.passableLoop
	ld a, [hli]
	cp $ff
	jr z, .cantLand
	cp c
	jr nz, .passableLoop
; nobody standing on this spot?
	ld a, d
	add 4
	ld d, a
	ld a, e
	add 4
	ld e, a
	ld b, 1
.spriteLoop
	ld a, b
	swap a ; * $10
	ld c, a
	ld hl, wSpriteStateData1
	ld l, c
	ld a, [hl] ; picture ID
	and a
	jr z, .nextSprite
	inc hl
	inc hl
	ld a, [hl] ; image index ($ff = hidden or off screen)
	inc a
	jr z, .nextSprite
	ld hl, wSpriteStateData2 + SPRITESTATEDATA2_MAPY
	ld a, l
	add c
	ld l, a
	ld a, [hli]
	cp d
	jr nz, .nextSprite
	ld a, [hl]
	cp e
	jr z, .cantLand
.nextSprite
	inc b
	ld a, b
	cp NUM_SPRITESTATEDATA_STRUCTS
	jr nz, .spriteLoop
	and a
	ret
.cantLand
	scf
	ret

; The NIMBUS flies in from the left edge of the screen and stops under Goku.
GokuNimbusArrives::
	ld de, NimbusCloudGfx
	ld hl, vSprites tile $7c
	lb bc, BANK(NimbusCloudGfx), 2
	call CopyVideoData
	ld hl, wUpdateSpritesEnabled
	ld a, [hl]
	push af
	ld [hl], $ff
; top-left of the player's sprite (OAM entries 0-3)
	ld hl, wShadowOAM
	lb bc, $ff, $ff
	ld e, 4
.minLoop
	ld a, [hli]
	cp b
	jr nc, .notMinY
	ld b, a
.notMinY
	ld a, [hli]
	cp c
	jr nc, .notMinX
	ld c, a
.notMinX
	inc hl
	inc hl
	dec e
	jr nz, .minLoop
	ld a, b
	add 11
	ld d, a ; cloud Y
	ld e, 8 ; cloud X starts at the left edge
	ld a, SFX_FLY
	call PlaySound
.flyInLoop
	call .drawCloud
	call DelayFrame
	ld a, e
	add 2
	ld e, a
	cp c
	jr c, .flyInLoop
	ld e, c
	call .drawCloud
	ld c, 20
	call DelayFrames
	ld hl, wShadowOAMSprite36
	xor a
	ld [hli], a
	inc hl
	inc hl
	inc hl
	ld [hl], a ; hide both cloud sprites
	pop af
	ld [wUpdateSpritesEnabled], a
	call ReloadMapSpriteTilePatterns ; put back whatever used those two tiles
	jp LoadFontTilePatterns

.drawCloud ; d = Y, e = X
	ld hl, wShadowOAMSprite36
	ld a, d
	ld [hli], a
	ld a, e
	ld [hli], a
	ld a, $7c
	ld [hli], a
	xor a
	ld [hli], a
	ld a, d
	ld [hli], a
	ld a, e
	add 8
	ld [hli], a
	ld a, $7d
	ld [hli], a
	xor a
	ld [hl], a
	ret

; Goku's hair goes SUPER SAIYAN in the overworld (until the map reloads)
GokuSSJOverworldSprite::
	xor a
	ld [wUnusedObtainedBadges], a ; Goku's cutscene: show Goku again afterwards
	ld de, GokuSSJSprite
	ld hl, vNPCSprites
	lb bc, BANK(GokuSSJSprite), 12 ; standing frames only (the walking ones share VRAM with the font)
	jp CopyVideoData

GokuSSJSprite::
	INCBIN "gfx/sprites/goku_ssj.2bpp"

NimbusCloudGfx:
	INCBIN "gfx/sprites/nimbus_cloud.2bpp"

; ===== Pokemon Rad: Saiyans =====

; Goku (player side) or Vegeta (enemy side) turns Super Saiyan: new pic, and
; Attack and Special x2 (double damage) for the rest of this battle (until switched out).
SaiyanPowerUp::
	ldh a, [hWhoseTurn]
	and a
	jr nz, .enemy
	ld a, [wBattleMonSpecies]
	ld de, GokuSSJBackPic
	cp GOKU
	jr z, .gotBackPic
	cp VEGETA
	jr nz, .playerStats
	ld de, VegetaSSJBackPic ; VEGETA on Goku's team
.gotBackPic
	ld a, BANK(GokuSSJBackPic)
	call UncompressSpriteFromDE
	predef ScaleSpriteByTwo
	ld de, vBackPic
	call InterlaceMergeSpriteBuffers
.playerStats
	ld hl, wBattleMonAttack
	call .boostStats
	ld hl, wPlayerMonUnmodifiedAttack
	jr .boostStats
.enemy
	ld de, VegetaSSJFrontPic
	ld a, BANK(VegetaSSJFrontPic)
	call UncompressSpriteFromDE
	ld a, $77
	ld c, a
	ld de, vFrontPic
	call LoadUncompressedSpriteData
	ld hl, wEnemyMonAttack
	call .boostStats
	ld hl, wEnemyMonUnmodifiedAttack
	; fall through

; hl = big-endian Attack, Defense, Speed, Special: Attack and Special x2 (max 999)
.boostStats
	push hl
	call .double
	pop hl
	ld de, 6
	add hl, de
.double
	ld a, [hli]
	ld d, a
	ld a, [hld]
	ld e, a
	push hl
	ld h, d
	ld l, e
	add hl, hl
	ld a, h
	cp HIGH(999)
	jr c, .statOK
	jr nz, .capStat
	ld a, l
	cp LOW(999) + 1
	jr c, .statOK
.capStat
	ld hl, 999
.statOK
	ld d, h
	ld e, l
	pop hl
	ld a, d
	ld [hli], a
	ld [hl], e
	ret

; After a trainer's party is built: VEGETA copies Goku's moves (KAMEHAMEHA becomes GALIC GUN).
VegetaMirrorGokuMoves::
	call .mirror
	call FriezaReplacesRival
; FRIEZA only ever knows PUNCH, DEATH BEAM and DEATH SAUCER
	ld hl, wEnemyPartySpecies
	ld c, 0
.friezaLoop
	ld a, [hli]
	cp $ff
	ret z
	cp FRIEZA
	jr nz, .nextMon
	push hl
	push bc
	ld a, c
	ld hl, wEnemyMon1Moves
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	ld a, PUNCH
	ld [hli], a
	ld a, DEATH_BEAM
	ld [hli], a
	ld a, DEATH_SAUCER
	ld [hli], a
	xor a
	ld [hl], a
	pop bc
	pop hl
.nextMon
	inc c
	jr .friezaLoop
.mirror
	ld a, [wTrainerClass]
	cp RIVAL1
	jr nz, .notMtMoon
	ld a, [wTrainerNo]
	cp 10
	jr c, .notMtMoon
	ld hl, wEnemyMon2Moves ; MT.MOON: VEGETA is second
	ld a, PUNCH
	ld [hli], a
	ld a, GALIC_GUN
	ld [hli], a
	ld a, SUPER_SAIYAN
	ld [hli], a
	xor a
	ld [hl], a
	ret
.notMtMoon
	ld hl, wEnemyPartySpecies
	ld c, 0
.findVegeta
	ld a, [hli]
	cp $ff
	ret z
	cp VEGETA
	jr z, .foundVegeta
	inc c
	jr .findVegeta
.foundVegeta
	ld a, c
	ld hl, wEnemyMon1Moves
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	push hl
	ld hl, wPartySpecies
	ld c, 0
.findGoku
	ld a, [hli]
	cp $ff
	jr z, .noGoku
	cp GOKU
	jr z, .foundGoku
	inc c
	jr .findGoku
.noGoku
	pop hl
	ret
.foundGoku
	ld a, c
	ld hl, wPartyMon1Moves
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	pop de
	ld b, NUM_MOVES
.copyMove
	ld a, [hli]
	cp KAMEHAMEHA
	jr nz, .storeMove
	ld a, GALIC_GUN
.storeMove
	ld [de], a
	inc de
	dec b
	jr nz, .copyMove
	ret

; After beating BROCK, Goku learns TRANSFORM (Super Saiyan).
GokuLearnsTransform::
	ld hl, wPartySpecies
	ld c, 0
.find
	ld a, [hli]
	cp $ff
	ret z
	cp GOKU
	jr z, .found
	inc c
	jr .find
.found
	ld a, c
	ld [wWhichPokemon], a
	ld hl, GokuTransformPowerText
	call PrintText
.learn
	ld a, SUPER_SAIYAN
	ld [wMoveNum], a
	ld [wNamedObjectIndex], a
	call GetMoveName
	call CopyToStringBuffer
	predef LearnMove
	ret

; hl = Goku's party struct, or carry if Goku isn't in the party
FindGokuPartyMon:
	ld hl, wPartySpecies
	ld c, 0
.find
	ld a, [hli]
	cp $ff
	jr z, .none
	cp GOKU
	jr z, .found
	inc c
	jr .find
.none
	scf
	ret
.found
	ld a, c
	ld [wWhichPokemon], a
	ld hl, wPartyMon1
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	and a
	ret

; Losing to FRIEZA: Goku can't transform until he challenges FRIEZA again.
GokuForgetsSuperSaiyan::
	call FindGokuPartyMon
	ret c
	push hl
	ld bc, MON_MOVES
	add hl, bc
	ld d, h
	ld e, l ; de = moves
	pop hl
	ld bc, MON_PP
	add hl, bc ; hl = PP
	ld b, NUM_MOVES
.findMove
	ld a, [de]
	cp SUPER_SAIYAN
	jr z, .remove
	inc de
	inc hl
	dec b
	jr nz, .findMove
	ret
.remove ; shift the later moves (and their PP) up one slot
	dec b
	jr z, .clearLast
.shift
	inc de
	ld a, [de]
	dec de
	ld [de], a
	inc de
	inc hl
	ld a, [hld]
	ld [hli], a
	dec b
	jr nz, .shift
.clearLast
	xor a
	ld [de], a
	ld [hl], a
	ret

; Facing FRIEZA again: if Goku lost SUPER SAIYAN, his anger brings it back.
GokuRegainsSuperSaiyan::
	call FindGokuPartyMon
	ret c
	ld bc, MON_MOVES
	add hl, bc
	ld b, NUM_MOVES
.check
	ld a, [hli]
	cp SUPER_SAIYAN
	ret z ; still has it
	dec b
	jr nz, .check
	ld hl, GokuRegainPowerText
	call PrintText
	jr GokuLearnsTransform.learn

GokuRegainPowerText:
	text_far _GokuRegainPowerText
	text_end

GokuTransformPowerText:
	text_far _GokuTransformPowerText
	text_end

; ===== Pokemon Rad: FRIEZA =====

; FRIEZA is hanging on at 1 HP: his DEATH SAUCER misses Goku, comes back around
; and slices him in half. Called in place of the enemy's turn.
FriezaFinale::
	ldh a, [hSaiyanForm]
	res 2, a
	ldh [hSaiyanForm], a
	ld a, DEATH_SAUCER
	ld [wEnemyMoveNum], a
	ld hl, FriezaFinaleUsedText
	call PrintText
	ld a, DEATH_SAUCER
	call .animation
	ld hl, FriezaFinaleDodgedText
	call PrintText
	xor a ; the saucer hits FRIEZA
	ldh [hWhoseTurn], a
	ld a, SLASH
	call .animation
	ld a, 1
	ldh [hWhoseTurn], a
	xor a
	ld hl, wEnemyMonHP
	ld [hli], a
	ld [hl], a
	farcall DrawHUDsAndHPBars
	ld hl, FriezaFinaleSlicedText
	jp PrintText

.animation
	ld [wAnimationID], a
	xor a
	ld [wAnimationType], a
	call Delay3
	predef_jump MoveAnimation

FriezaFinaleUsedText:
	text_far _FriezaFinaleUsedText
	text_end

FriezaFinaleDodgedText:
	text_far _FriezaFinaleDodgedText
	text_end

FriezaFinaleSlicedText:
	text_far _FriezaFinaleSlicedText
	text_end

GokuSSJBackPic:    INCBIN "gfx/saiyan/goku_ssj_back.pic"
VegetaSSJFrontPic: INCBIN "gfx/saiyan/vegeta_ssj_front.pic"
VegetaSSJBackPic:  INCBIN "gfx/saiyan/vegeta_ssj_back.pic"


; ===== Pokemon Rad: Auto Battle move picker (moved out of the full battle bank) =====
DEF AUTO_MOVE EQUS "wBuffer"
DEF AUTO_BEST EQUS "(wBuffer + 6)"
DEF AUTO_BESTI EQUS "(wBuffer + 9)"
DEF AUTO_CUR EQUS "(wBuffer + 10)"
DEF AUTO_FALLB EQUS "(wBuffer + 11)"

; picks the usable move with the highest power * type effectiveness * STAB * accuracy
AutoPickMove::
; Pokemon Rad: Goku and VEGETA transform first if they can
	ld a, [wBattleMonSpecies]
	cp GOKU
	jr z, .saiyan
	cp VEGETA
	jr nz, .noTransform
.saiyan
	ldh a, [hSaiyanForm]
	bit 0, a
	jr nz, .noTransform
	ld hl, wBattleMonMoves
	ld c, 0
.findTransform
	ld a, [hli]
	cp SUPER_SAIYAN
	jr z, .foundTransform
	inc c
	ld a, c
	cp NUM_MOVES
	jr nz, .findTransform
	jr .noTransform
.foundTransform
	ld b, 0
	ld hl, wBattleMonPP
	add hl, bc
	ld a, [hl]
	and PP_MASK
	jr z, .noTransform
	ld a, c
	ld [AUTO_BESTI], a
	jp .done
.noTransform
	xor a
	ld [AUTO_BEST], a
	ld [AUTO_BEST + 1], a
	ld [AUTO_BEST + 2], a
	ld [AUTO_CUR], a
	dec a
	ld [AUTO_BESTI], a
	ld [AUTO_FALLB], a
.loop
	ld a, [AUTO_CUR]
	cp NUM_MOVES
	jp z, .done
	ld c, a
	ld b, 0
	ld hl, wBattleMonMoves
	add hl, bc
	ld a, [hl]
	and a
	jp z, .next
	ld hl, wBattleMonPP
	add hl, bc
	ld a, [hl]
	and PP_MASK
	jp z, .next
	ld a, [wPlayerDisabledMove]
	swap a
	and $f
	dec a
	cp c
	jp z, .next
	ld a, [AUTO_FALLB]
	inc a
	jr nz, .haveFallback
	ld a, c
	ld [AUTO_FALLB], a
.haveFallback
	ld hl, wBattleMonMoves
	add hl, bc
	ld a, [hl]
	dec a
	ld hl, Moves
	ld bc, MOVE_LENGTH
	call AddNTimes
	ld de, AUTO_MOVE
	ld a, BANK(Moves)
	call FarCopyData
	ld a, [AUTO_MOVE + MOVE_POWER]
	and a
	jp z, .next ; status moves are never chosen over attacks
	ld a, [AUTO_MOVE + MOVE_EFFECT]
	cp EXPLODE_EFFECT
	jp z, .next ; don't blow ourselves up
	cp OHKO_EFFECT
	jp z, .next
	cp DREAM_EATER_EFFECT
	jr nz, .notDreamEater
	ld a, [wEnemyMonStatus]
	and SLP_MASK
	jp z, .next
.notDreamEater
	ld a, [AUTO_MOVE + MOVE_EFFECT]
	cp SPECIAL_DAMAGE_EFFECT
	jr z, .fixedDamage
	cp SUPER_FANG_EFFECT
	jr nz, .gotPower
.fixedDamage
	ld a, 40
	ld [AUTO_MOVE + MOVE_POWER], a
.gotPower
; type effectiveness: d = 4 means x1
	ld d, 4
	ld hl, GokuTypeEffects
.effLoop
	ld a, [hli]
	cp -1
	jr z, .effDone
	ld b, a
	ld a, [AUTO_MOVE + MOVE_TYPE]
	cp b
	jr nz, .skipEntry
	ld a, [hli]
	ld b, a
	ld a, [wEnemyMonType1]
	cp b
	jr z, .applyEff
	ld a, [wEnemyMonType2]
	cp b
	jr z, .applyEff
	inc hl
	jr .effLoop
.applyEff
	ld a, [hli]
	and a
	jr nz, .notImmune
	ld d, 0
	jr .effLoop
.notImmune
	cp SUPER_EFFECTIVE
	jr nz, .notSuper
	sla d
	jr .effLoop
.notSuper
	srl d
	jr .effLoop
.skipEntry
	inc hl
	inc hl
	jr .effLoop
.effDone
	ld a, d
	and a
	jp z, .next ; no effect on this foe
; STAB: x3 instead of x2
	ld e, d
	sla d ; d = eff * 2
	ld a, [AUTO_MOVE + MOVE_TYPE]
	ld b, a
	ld a, [wBattleMonType1]
	cp b
	jr z, .stab
	ld a, [wBattleMonType2]
	cp b
	jr nz, .noStab
.stab
	ld a, d
	add e
	ld d, a
.noStab
	xor a
	ldh [hMultiplicand], a
	ldh [hMultiplicand + 1], a
	ld a, [AUTO_MOVE + MOVE_POWER]
	ldh [hMultiplicand + 2], a
	ld a, d
	ldh [hMultiplier], a
	call Multiply
; accuracy (halved for two-turn moves)
	ld a, [AUTO_MOVE + MOVE_EFFECT]
	cp CHARGE_EFFECT
	jr z, .twoTurn
	cp FLY_EFFECT
	jr z, .twoTurn
	ld a, [AUTO_MOVE + MOVE_ACC]
	jr .gotAcc
.twoTurn
	ld a, [AUTO_MOVE + MOVE_ACC]
	srl a
.gotAcc
	ldh [hMultiplier], a
	call Multiply
; compare hProduct+1..3 with AUTO_BEST
	ld hl, AUTO_BEST
	ldh a, [hProduct + 1]
	cp [hl]
	jr c, .next
	jr nz, .newBest
	inc hl
	ldh a, [hProduct + 2]
	cp [hl]
	jr c, .next
	jr nz, .newBest
	inc hl
	ldh a, [hProduct + 3]
	cp [hl]
	jr c, .next
	jr z, .next
.newBest
	ldh a, [hProduct + 1]
	ld [AUTO_BEST], a
	ldh a, [hProduct + 2]
	ld [AUTO_BEST + 1], a
	ldh a, [hProduct + 3]
	ld [AUTO_BEST + 2], a
	ld a, [AUTO_CUR]
	ld [AUTO_BESTI], a
.next
	ld hl, AUTO_CUR
	inc [hl]
	jp .loop
.done
	ld a, [AUTO_BESTI]
	cp -1
	jr nz, .chosen
	ld a, [AUTO_FALLB]
.chosen
	ld [wPlayerMoveListIndex], a
	ld [wCurrentMenuItem], a
	ld c, a
	ld b, 0
	ld hl, wBattleMonMoves
	add hl, bc
	ld a, [hl]
	ld [wPlayerSelectedMove], a
	ret

; Pokemon Rad (auto battle): e = the party mon that should take over from Goku
; because one more enemy attack could knock him out, or $ff to keep fighting
AutoBattleShouldSwitch::
	ld e, $ff
	ld a, [wEnemyBattleStatus1]
	bit USING_TRAPPING_MOVE, a
	ret nz ; held in place
	ld a, [wEnemyMonStatus]
	and (1 << FRZ) | SLP_MASK
	ret nz ; the foe can't attack anyway
	call EnemyMaxDamage ; hl = the most one hit could do
	ld a, [wBattleMonHP + 1]
	ld c, a
	ld a, [wBattleMonHP]
	ld b, a
	ld a, l
	sub c
	ld a, h
	sbc b
	ld e, $ff
	ret c ; it'd survive the hit
	ld d, h
	ld e, l ; de = that hit
; the next party mon that could take that hit (no point otherwise)
	ld a, [wPlayerMonNumber]
	ld c, a
	ld a, [wPartyCount]
	ld b, a
.find
	inc c
	ld a, c
	cp b
	jr c, .inRange
	ld c, 0
.inRange
	ld a, [wPlayerMonNumber]
	cp c
	jr z, .nobody
	push bc
	push de
	ld a, c
	ld hl, wPartyMon1HP
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	pop de
	pop bc
	ld a, [hli]
	ld l, [hl]
	ld h, a ; hl = its HP
	ld a, e
	sub l
	ld a, d
	sbc h
	jr nc, .find ; it'd fall to the hit too
	ld e, c
	ret
.nobody
	ld e, $ff ; fight on
	ret

; hl = the most damage one of the enemy's moves could do to the player's mon
; (no critical hit, best damage roll)
EnemyMaxDamage:
	xor a
	ld [AUTO_BEST], a
	ld [AUTO_BEST + 1], a
	ld [AUTO_CUR], a
.loop
	ld a, [AUTO_CUR]
	cp NUM_MOVES
	jp z, .done
	ld c, a
	ld b, 0
	ld hl, wEnemyMonMoves
	add hl, bc
	ld a, [hl]
	and a
	jp z, .next
	dec a
	ld hl, Moves
	ld bc, MOVE_LENGTH
	call AddNTimes
	ld de, AUTO_MOVE
	ld a, BANK(Moves)
	call FarCopyData
	ld a, [AUTO_MOVE + MOVE_EFFECT]
	cp SPECIAL_DAMAGE_EFFECT
	jr nz, .notFixed
	ld a, [wEnemyMonLevel] ; up to 1.5x the level (PSYWAVE)
	ld l, a
	srl a
	add l
	ld l, a
	ld h, 0
	jp .gotDamage
.notFixed
	ld a, [AUTO_MOVE + MOVE_POWER]
	and a
	jp z, .next
	cp 2
	jp c, .next ; OHKO / special moves with no real power
	ld a, [AUTO_MOVE + MOVE_TYPE]
	cp SPECIAL
	jr nc, .special
	ld hl, wEnemyMonAttack
	ld de, wBattleMonDefense
	jr .gotStats
.special
	ld hl, wEnemyMonSpecial
	ld de, wBattleMonSpecial
.gotStats
	ld a, [hli]
	ld b, a
	ld c, [hl] ; bc = attack
	ld a, [de]
	ld h, a
	inc de
	ld a, [de]
	ld l, a ; hl = defense
.scale ; like the game: both / 4 while either is over 255
	ld a, b
	or h
	jr z, .scaled
	srl b
	rr c
	srl b
	rr c
	srl h
	rr l
	srl h
	rr l
	jr .scale
.scaled
	ld a, l
	and a
	jr nz, .defenseOK
	inc l
.defenseOK
	ld a, c
	and a
	jr nz, .attackOK
	inc c
.attackOK
	push hl ; l = defense
	push bc ; c = attack
; (2 * level / 5 + 2) * power * attack / defense / 50 + 2
	xor a
	ldh [hDividend], a
	ldh [hDividend + 1], a
	ldh [hDividend + 2], a
	ld a, [wEnemyMonLevel]
	add a
	ldh [hDividend + 3], a
	ld a, 5
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ldh a, [hQuotient + 3]
	add 2
	ldh [hMultiplicand + 2], a
	xor a
	ldh [hMultiplicand], a
	ldh [hMultiplicand + 1], a
	ld a, [AUTO_MOVE + MOVE_POWER]
	ldh [hMultiplier], a
	call Multiply
	pop bc
	ld a, c
	ldh [hMultiplier], a
	call Multiply
	pop hl
	ld a, l
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ld a, 50
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ldh a, [hQuotient + 1]
	and a
	jp nz, .huge
	ldh a, [hQuotient + 2]
	ld h, a
	ldh a, [hQuotient + 3]
	ld l, a
	inc hl
	inc hl
; STAB: x1.5
	ld a, [AUTO_MOVE + MOVE_TYPE]
	ld b, a
	ld a, [wEnemyMonType1]
	cp b
	jr z, .stab
	ld a, [wEnemyMonType2]
	cp b
	jr nz, .noStab
.stab
	ld d, h
	ld e, l
	srl d
	rr e
	add hl, de
.noStab
; type effectiveness: d = 4 means x1
	push hl
	ld d, 4
	ld hl, GokuTypeEffects
.effLoop
	ld a, [hli]
	cp -1
	jr z, .effDone
	ld b, a
	ld a, [AUTO_MOVE + MOVE_TYPE]
	cp b
	jr nz, .skipEntry
	ld a, [hli]
	ld b, a
	ld a, [wBattleMonType1]
	cp b
	jr z, .applyEff
	ld a, [wBattleMonType2]
	cp b
	jr z, .applyEff
	inc hl
	jr .effLoop
.applyEff
	ld a, [hli]
	and a
	jr nz, .notImmune
	ld d, 0
	jr .effLoop
.notImmune
	cp SUPER_EFFECTIVE
	jr nz, .notSuper
	sla d
	jr .effLoop
.notSuper
	srl d
	jr .effLoop
.skipEntry
	inc hl
	inc hl
	jr .effLoop
.effDone
	pop hl
	ld a, d
	and a
	jp z, .next ; can't hurt him
	xor a
	ldh [hMultiplicand], a
	ld a, h
	ldh [hMultiplicand + 1], a
	ld a, l
	ldh [hMultiplicand + 2], a
	ld a, d
	ldh [hMultiplier], a
	call Multiply
	ld a, 4
	ldh [hDivisor], a
	ld b, 4
	call Divide
	ldh a, [hQuotient + 1]
	and a
	jr nz, .huge
	ldh a, [hQuotient + 2]
	ld h, a
	ldh a, [hQuotient + 3]
	ld l, a
; hits 2-5 times: count it as three hits
	ld a, [AUTO_MOVE + MOVE_EFFECT]
	cp TWO_TO_FIVE_ATTACKS_EFFECT
	jr nz, .notMulti
	ld d, h
	ld e, l
	add hl, de
	jr c, .huge
	add hl, de
	jr c, .huge
.notMulti
	jr .gotDamage
.huge
	ld hl, $ffff
.gotDamage
; keep the biggest
	ld a, [AUTO_BEST]
	cp h
	jr c, .newBest
	jr nz, .next
	ld a, [AUTO_BEST + 1]
	cp l
	jr nc, .next
.newBest
	ld a, h
	ld [AUTO_BEST], a
	ld a, l
	ld [AUTO_BEST + 1], a
.next
	ld hl, AUTO_CUR
	inc [hl]
	jp .loop
.done
	ld a, [AUTO_BEST]
	ld h, a
	ld a, [AUTO_BEST + 1]
	ld l, a
	ret

GokuTypeEffects: ; copy of TypeEffects for the auto battle move picker
	;  attacker,     defender,     *=
	db WATER,        FIRE,         SUPER_EFFECTIVE
	db FIRE,         GRASS,        SUPER_EFFECTIVE
	db FIRE,         ICE,          SUPER_EFFECTIVE
	db GRASS,        WATER,        SUPER_EFFECTIVE
	db ELECTRIC,     WATER,        SUPER_EFFECTIVE
	db WATER,        ROCK,         SUPER_EFFECTIVE
	db GROUND,       FLYING,       NO_EFFECT
	db WATER,        WATER,        NOT_VERY_EFFECTIVE
	db FIRE,         FIRE,         NOT_VERY_EFFECTIVE
	db ELECTRIC,     ELECTRIC,     NOT_VERY_EFFECTIVE
	db ICE,          ICE,          NOT_VERY_EFFECTIVE
	db GRASS,        GRASS,        NOT_VERY_EFFECTIVE
	db PSYCHIC_TYPE, PSYCHIC_TYPE, NOT_VERY_EFFECTIVE
	db FIRE,         WATER,        NOT_VERY_EFFECTIVE
	db GRASS,        FIRE,         NOT_VERY_EFFECTIVE
	db WATER,        GRASS,        NOT_VERY_EFFECTIVE
	db ELECTRIC,     GRASS,        NOT_VERY_EFFECTIVE
	db NORMAL,       ROCK,         NOT_VERY_EFFECTIVE
	db NORMAL,       GHOST,        NO_EFFECT
	db GHOST,        GHOST,        SUPER_EFFECTIVE
	db FIRE,         BUG,          SUPER_EFFECTIVE
	db FIRE,         ROCK,         NOT_VERY_EFFECTIVE
	db WATER,        GROUND,       SUPER_EFFECTIVE
	db ELECTRIC,     GROUND,       NO_EFFECT
	db ELECTRIC,     FLYING,       SUPER_EFFECTIVE
	db GRASS,        GROUND,       SUPER_EFFECTIVE
	db GRASS,        BUG,          NOT_VERY_EFFECTIVE
	db GRASS,        POISON,       NOT_VERY_EFFECTIVE
	db GRASS,        ROCK,         SUPER_EFFECTIVE
	db GRASS,        FLYING,       NOT_VERY_EFFECTIVE
	db ICE,          WATER,        NOT_VERY_EFFECTIVE
	db ICE,          GRASS,        SUPER_EFFECTIVE
	db ICE,          GROUND,       SUPER_EFFECTIVE
	db ICE,          FLYING,       SUPER_EFFECTIVE
	db FIGHTING,     NORMAL,       SUPER_EFFECTIVE
	db FIGHTING,     POISON,       NOT_VERY_EFFECTIVE
	db FIGHTING,     FLYING,       NOT_VERY_EFFECTIVE
	db FIGHTING,     PSYCHIC_TYPE, NOT_VERY_EFFECTIVE
	db FIGHTING,     BUG,          NOT_VERY_EFFECTIVE
	db FIGHTING,     ROCK,         SUPER_EFFECTIVE
	db FIGHTING,     ICE,          SUPER_EFFECTIVE
	db FIGHTING,     GHOST,        NO_EFFECT
	db POISON,       GRASS,        SUPER_EFFECTIVE
	db POISON,       POISON,       NOT_VERY_EFFECTIVE
	db POISON,       GROUND,       NOT_VERY_EFFECTIVE
	db POISON,       BUG,          SUPER_EFFECTIVE
	db POISON,       ROCK,         NOT_VERY_EFFECTIVE
	db POISON,       GHOST,        NOT_VERY_EFFECTIVE
	db GROUND,       FIRE,         SUPER_EFFECTIVE
	db GROUND,       ELECTRIC,     SUPER_EFFECTIVE
	db GROUND,       GRASS,        NOT_VERY_EFFECTIVE
	db GROUND,       BUG,          NOT_VERY_EFFECTIVE
	db GROUND,       ROCK,         SUPER_EFFECTIVE
	db GROUND,       POISON,       SUPER_EFFECTIVE
	db FLYING,       ELECTRIC,     NOT_VERY_EFFECTIVE
	db FLYING,       FIGHTING,     SUPER_EFFECTIVE
	db FLYING,       BUG,          SUPER_EFFECTIVE
	db FLYING,       GRASS,        SUPER_EFFECTIVE
	db FLYING,       ROCK,         NOT_VERY_EFFECTIVE
	db PSYCHIC_TYPE, FIGHTING,     SUPER_EFFECTIVE
	db PSYCHIC_TYPE, POISON,       SUPER_EFFECTIVE
	db BUG,          FIRE,         NOT_VERY_EFFECTIVE
	db BUG,          GRASS,        SUPER_EFFECTIVE
	db BUG,          FIGHTING,     NOT_VERY_EFFECTIVE
	db BUG,          FLYING,       NOT_VERY_EFFECTIVE
	db BUG,          PSYCHIC_TYPE, SUPER_EFFECTIVE
	db BUG,          GHOST,        NOT_VERY_EFFECTIVE
	db BUG,          POISON,       SUPER_EFFECTIVE
	db ROCK,         FIRE,         SUPER_EFFECTIVE
	db ROCK,         FIGHTING,     NOT_VERY_EFFECTIVE
	db ROCK,         GROUND,       NOT_VERY_EFFECTIVE
	db ROCK,         FLYING,       SUPER_EFFECTIVE
	db ROCK,         BUG,          SUPER_EFFECTIVE
	db ROCK,         ICE,          SUPER_EFFECTIVE
	db GHOST,        NORMAL,       NO_EFFECT
	db GHOST,        PSYCHIC_TYPE, NO_EFFECT
	db FIRE,         DRAGON,       NOT_VERY_EFFECTIVE
	db WATER,        DRAGON,       NOT_VERY_EFFECTIVE
	db ELECTRIC,     DRAGON,       NOT_VERY_EFFECTIVE
	db GRASS,        DRAGON,       NOT_VERY_EFFECTIVE
	db ICE,          DRAGON,       SUPER_EFFECTIVE
	db DRAGON,       DRAGON,       SUPER_EFFECTIVE
	db -1 ; end

; ===== Pokemon Rad: CHAPTER select (main menu) =====

; Lets the player pick a chapter. carry = cancelled, else wDefaultMap = start map
ChapterSelectMenu::
	hlcoord 0, 6
	ld b, 10
	ld c, 18
	call TextBoxBorder
	hlcoord 2, 8
	ld de, ChapterNamesText
	call PlaceString
	xor a
	ld [wCurrentMenuItem], a
	ld [wLastMenuItem], a
	ld [wMenuJoypadPollCount], a
	ld a, 1
	ld [wTopMenuItemX], a
	ld a, 8
	ld [wTopMenuItemY], a
	ld a, PAD_A | PAD_B
	ld [wMenuWatchedKeys], a
	ld a, 4
	ld [wMaxMenuItem], a
	call HandleMenuInput
	bit B_PAD_B, a
	jr nz, .cancel
	ld a, [wCurrentMenuItem]
	ld c, a
	ld b, 0
	ld hl, ChapterMaps
	add hl, bc
	ld a, [hl]
	ld [wDefaultMap], a
	and a
	ret
.cancel
	scf
	ret

ChapterNamesText:
	db   "1 FIRST GYM"
	next "2 VEGETA REVENGE"
	next "3 NIMBUS"
	next "4 GRAVITY ROOM"
	next "5 ELITE FOUR@"

; the fly-map the intro warps to; ChapterSetup then moves the player to the
; chapter's exact spot
ChapterMaps:
	db PEWTER_CITY, ROUTE_4, CERULEAN_CITY, PALLET_TOWN, INDIGO_PLATEAU

; After the (skipped) intro: build the save for the chapter picked
; (wDestinationMap = the chapter's fly-map).
ChapterSetup::
	ld hl, ChapterPlayerName
	ld de, wPlayerName
	ld bc, NAME_LENGTH
	call CopyData
	ld hl, ChapterRivalName
	ld de, wRivalName
	ld bc, NAME_LENGTH
	call CopyData
; the story so far: starter, rival battle in OAK's lab, OAK's PARCEL
	SetEvent EVENT_FOLLOWED_OAK_INTO_LAB
	SetEvent EVENT_FOLLOWED_OAK_INTO_LAB_2
	SetEvent EVENT_OAK_APPEARED_IN_PALLET
	SetEvent EVENT_OAK_ASKED_TO_CHOOSE_MON
	SetEvent EVENT_GOT_STARTER
	SetEvent EVENT_BATTLED_RIVAL_IN_OAKS_LAB
	SetEvent EVENT_GOT_OAKS_PARCEL
	SetEvent EVENT_GOKU_LEARNED_KAMEHAMEHA
	ld a, 18 ; SCRIPT_OAKSLAB_NOOP
	ld [wOaksLabCurScript], a
	ld a, 5 ; SCRIPT_PALLETTOWN_DAISY
	ld [wPalletTownCurScript], a
	ld a, TOGGLE_PALLET_TOWN_OAK
	call .hide
	ld a, TOGGLE_OAKS_LAB_RIVAL
	call .hide
	ld a, TOGGLE_STARTER_BALL_1
	call .hide
	ld a, TOGGLE_STARTER_BALL_2
	call .hide
	ld a, TOGGLE_OAKS_LAB_OAK_1
	call .show
	ld a, %00000011 ; PALLET TOWN and VIRIDIAN CITY
	ld [wTownVisitedFlag], a
	ld a, [wDestinationMap]
	ld [wLastBlackoutMap], a ; black out to this chapter's POKECENTER
	ld hl, wPlayerMoney
	xor a
	ld [hli], a
	ld a, $30 ; 3000
	ld [hli], a
	xor a
	ld [hl], a
	lb bc, POKE_BALL, 5
	call GiveItem
	lb bc, POTION, 5
	call GiveItem
	ld a, CHARMANDER
	ld [wPlayerStarter], a
	ld a, SQUIRTLE
	ld [wRivalStarter], a
; party: Goku and a CHARMANDER (levels depend on the chapter)
	ld a, [wDestinationMap]
	ld b, 10
	cp VIRIDIAN_CITY
	jr z, .gotLevel
	ld b, 12
	cp PEWTER_CITY
	jr z, .gotLevel
	ld b, 18
	cp ROUTE_4
	jr z, .gotLevel
	ld b, 22
.gotLevel
	push bc
	ld a, GOKU
	ld [wCurPartySpecies], a
	ld a, $10 ; player's party, skip the nickname prompt
	ld [wMonDataLocation], a
	ld a, b
	ld [wCurEnemyLevel], a
	call AddPartyMon
	ld hl, wPlayerName
	ld de, wPartyMonNicks
	ld bc, NAME_LENGTH
	call CopyData
	pop bc
	ld a, b
	sub 4
	ld c, a
	ld b, CHARMANDER
	call .addMon
	ld hl, wPartyMon1Moves
	ld a, PUNCH
	ld [hli], a
	ld a, BITE
	ld [hli], a
	ld a, KAMEHAMEHA
	ld [hli], a
	xor a
	ld [hl], a
	ld hl, wPartyMon1PP
	ld a, 35
	ld [hli], a
	ld a, 25
	ld [hli], a
	ld a, 10
	ld [hli], a
	ld a, [wDestinationMap]
	cp VIRIDIAN_CITY
	jr nz, .afterParcel
; chapter 1: just stepped out of the VIRIDIAN MART with OAK's PARCEL
	lb bc, OAKS_PARCEL, 1
	call GiveItem
	lb bc, 20, 29 ; in front of the mart door
	ld d, VIRIDIAN_CITY_WIDTH
	jp .setPosition

.afterParcel ; the POKEDEX delivered, MYSTERY BEAN, running unlocked
	push hl
	SetEvent EVENT_OAK_GOT_PARCEL
	SetEvent EVENT_GOT_POKEDEX
	SetEvent EVENT_GOKU_GOT_NIMBUS ; running unlocked
	ld a, TOGGLE_LYING_OLD_MAN
	call .hide
	ld a, TOGGLE_POKEDEX_1
	call .hide
	ld a, TOGGLE_POKEDEX_2
	call .hide
	ld a, TOGGLE_OLD_MAN
	call .show
	ld a, %00000111 ; + PEWTER CITY
	ld [wTownVisitedFlag], a
	pop hl
	ld a, [wDestinationMap]
	cp PEWTER_CITY
	jr nz, .afterBrock
; chapter 2: face to face with BROCK in his gym
	lb bc, MYSTERY_BEAN, 1
	call GiveItem
	ld a, PEWTER_GYM
	ld [wCurMap], a
	ld a, PEWTER_CITY
	ld [wLastMap], a
	lb bc, 2, 4
	ld d, PEWTER_GYM_WIDTH
	jp .setPosition

.afterBrock ; Frieza beaten, BOULDERBADGE, SENZU BEANs in the marts
	ld a, 5
	ld [hl], a ; SUPER SAIYAN PP
	ld a, SUPER_SAIYAN
	ld [wPartyMon1Moves + 3], a
	lb bc, BULBASAUR, 13 ; the starter FRIEZA stole
	call .addMon
	ld a, 1 << BIT_BOULDERBADGE
	ld [wObtainedBadges], a
	ld [wBeatGymFlags], a
	SetEvent EVENT_BEAT_BROCK
	SetEvent EVENT_GOT_TM34
	SetEvent EVENT_BEAT_PEWTER_GYM_TRAINER_0
	SetEvent EVENT_FRIEZA_DEFEATED
	SetEvent EVENT_SENZU_IN_SHOPS
	ld a, TOGGLE_GYM_GUY
	call .hide
	ld a, TOGGLE_ROUTE_22_RIVAL_1
	call .hide
	lb bc, SENZU_BEAN, 2
	call GiveItem
	ld a, [wDestinationMap]
	cp ROUTE_4
	jr nz, .afterVegeta
; chapter 3: right in front of VEGETA at MT.MOON
	lb bc, 7, 18
	ld d, ROUTE_4_WIDTH
	jp .setPosition

.afterVegeta ; chapter 4: VEGETA (and his SQUIRTLE) joined, at the bike shop counter
	SetEvent EVENT_GOKU_BLASTED_MT_MOON
	SetEvent EVENT_VEGETA_JOINED
	ld a, TOGGLE_ROUTE_4_VEGETA
	call .hide
	lb bc, SQUIRTLE, 15
	call .addMon
	lb bc, VEGETA, 10
	call .addMon
	ld a, [wPartyCount]
	dec a
	ld hl, wPartyMon1Moves
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	ld a, PUNCH
	ld [hli], a
	ld a, GALIC_GUN
	ld [hli], a
	ld a, SUPER_SAIYAN
	ld [hli], a
	ld bc, MON_PP - (MON_MOVES + 3)
	add hl, bc
	ld a, 35
	ld [hli], a
	ld a, 10
	ld [hli], a
	ld a, 5
	ld [hl], a
	ld hl, ChapterFriezaName
	ld de, wRivalName
	ld bc, NAME_LENGTH
	call CopyData
	ld a, %00001111 ; + CERULEAN CITY
	ld [wTownVisitedFlag], a
	ld a, [wDestinationMap]
	cp PALLET_TOWN
	jr z, .chapter5
	cp INDIGO_PLATEAU
	jp nz, .chapter4
.chapter5
; chapter 5: BICYCLE and NIMBUS, MISTY's trainers beaten; face to face
; with MISTY (FRIEZA waits outside once she's beaten)
	SetEvent EVENT_GOT_BICYCLE
	SetEvent EVENT_GOT_NIMBUS_ITEM
	SetEvent EVENT_BEAT_CERULEAN_RIVAL
	SetEvent EVENT_BEAT_CERULEAN_GYM_TRAINER_0
	SetEvent EVENT_BEAT_CERULEAN_GYM_TRAINER_1
; NUGGET BRIDGE cleared, and BILL helped (S.S.TICKET)
	SetEvent EVENT_BEAT_ROUTE_24_TRAINER_0
	SetEvent EVENT_BEAT_ROUTE_24_TRAINER_1
	SetEvent EVENT_BEAT_ROUTE_24_TRAINER_2
	SetEvent EVENT_BEAT_ROUTE_24_TRAINER_3
	SetEvent EVENT_BEAT_ROUTE_24_TRAINER_4
	SetEvent EVENT_BEAT_ROUTE_24_TRAINER_5
	SetEvent EVENT_BEAT_ROUTE24_ROCKET
	SetEvent EVENT_GOT_NUGGET
	SetEvent EVENT_BEAT_ROUTE_25_TRAINER_0
	SetEvent EVENT_BEAT_ROUTE_25_TRAINER_1
	SetEvent EVENT_BEAT_ROUTE_25_TRAINER_2
	SetEvent EVENT_BEAT_ROUTE_25_TRAINER_3
	SetEvent EVENT_BEAT_ROUTE_25_TRAINER_4
	SetEvent EVENT_BEAT_ROUTE_25_TRAINER_5
	SetEvent EVENT_BEAT_ROUTE_25_TRAINER_6
	SetEvent EVENT_BEAT_ROUTE_25_TRAINER_7
	SetEvent EVENT_BEAT_ROUTE_25_TRAINER_8
	SetEvent EVENT_MET_BILL
	SetEvent EVENT_MET_BILL_2
	SetEvent EVENT_BILL_SAID_USE_CELL_SEPARATOR
	SetEvent EVENT_USED_CELL_SEPARATOR_ON_BILL
	SetEvent EVENT_GOT_SS_TICKET
	SetEvent EVENT_LEFT_BILLS_HOUSE_AFTER_HELPING
	ld a, TOGGLE_NUGGET_BRIDGE_GUY
	call .hide
	ld a, TOGGLE_BILL_POKEMON
	call .hide
	ld a, TOGGLE_BILL_1
	call .hide
	ld a, TOGGLE_BILL_2
	call .show
	ld a, TOGGLE_CERULEAN_GUARD_1
	call .show
	ld a, TOGGLE_CERULEAN_GUARD_2
	call .hide
	lb bc, S_S_TICKET, 1
	call GiveItem
	lb bc, NUGGET, 1
	call GiveItem
	lb bc, BICYCLE, 1
	call GiveItem
	lb bc, NIMBUS, 1
	call GiveItem
	ld a, [wDestinationMap]
	cp INDIGO_PLATEAU
	jp z, .eliteFour
	ld a, CERULEAN_GYM
	ld [wCurMap], a
	ld a, CERULEAN_CITY
	ld [wLastMap], a
	ld [wLastBlackoutMap], a
	lb bc, 3, 4 ; right in front of MISTY
	ld d, CERULEAN_GYM_WIDTH
	jp .setPosition
.chapter4
	lb bc, BIKE_VOUCHER, 1
	call GiveItem
	ld a, BIKE_SHOP
	ld [wCurMap], a
	ld a, CERULEAN_CITY
	ld [wLastMap], a
	lb bc, 4, 6
	ld d, BIKE_SHOP_WIDTH
	jp .setPosition

; chapter ELITE FOUR: everything done, the whole team at level 100 and fully
; evolved, at the door of the POKeMON LEAGUE
.eliteFour
	SetEvent EVENT_BEAT_MISTY
	SetEvent EVENT_GOT_TM11
	SetEvent EVENT_FRIEZA_JOINED
	ld a, TOGGLE_DAISY_SITTING ; VEGETA's house is the GRAVITY ROOM
	call .hide
	ld a, TOGGLE_DAISY_WALKING
	call .hide
	ld a, TOGGLE_TOWN_MAP
	call .hide
	ld a, $ff ; all eight BADGEs, every town visited
	ld [wObtainedBadges], a
	ld [wBeatGymFlags], a
	ld hl, wTownVisitedFlag
	ld [hli], a
	ld [hl], a
	ld hl, .GaryName
	ld de, wRivalName
	ld bc, NAME_LENGTH
	call CopyData
	lb bc, FULL_RESTORE, 10
	call GiveItem
	lb bc, MAX_REVIVE, 5
	call GiveItem
; the team, in this order
	xor a
	ld [wPartyCount], a
	dec a
	ld [wPartySpecies], a
	lb bc, VEGETA, 100
	call .addMon
	lb bc, FRIEZA, 100
	call .addMon
	lb bc, CHARIZARD, 100
	call .addMon
	lb bc, BLASTOISE, 100
	call .addMon
	lb bc, VENUSAUR, 100
	call .addMon
	lb bc, GOKU, 100
	call .addMon
	ld hl, wPartyMon1Moves
	ld de, .VegetaMoves
	call .setMoves
	ld hl, wPartyMon2Moves
	ld de, .FriezaMoves
	call .setMoves
	ld hl, wPartyMon6Moves
	ld de, .GokuMoves
	call .setMoves
	ld hl, wPlayerName ; Goku goes by his own name
	ld de, wPartyMonNicks + 5 * NAME_LENGTH
	ld bc, NAME_LENGTH
	call CopyData
	ld a, ROUTE_22 ; outside the POKeMON LEAGUE FRONT GATE
	ld [wCurMap], a
	ld a, INDIGO_PLATEAU
	ld [wLastBlackoutMap], a
	lb bc, 6, 8 ; right in front of its door
	ld d, ROUTE_22_WIDTH
	jr .setPosition

; hl = a party mon's moves, de = 4 moves then their 4 PP
.setMoves
	push hl
	ld h, d
	ld l, e ; hl = the table
	pop de ; de = the moves
	push de
	ld bc, NUM_MOVES
	call CopyData ; hl now points at the PP
	pop de
	push hl
	ld hl, MON_PP - MON_MOVES
	add hl, de
	ld d, h
	ld e, l ; de = the PP
	pop hl
	ld bc, NUM_MOVES
	jp CopyData

.VegetaMoves:
	db PUNCH, GALIC_GUN, SUPER_SAIYAN, 0
	db 35, 10, 5, 0
.FriezaMoves:
	db PUNCH, DEATH_BEAM, DEATH_SAUCER, 0
	db 35, 15, 10, 0
.GokuMoves:
	db PUNCH, BITE, KAMEHAMEHA, SUPER_SAIYAN
	db 35, 25, 10, 5
.GaryName:
	db "GARY@"

; b = Y, c = X, d = map width: put the player there (like a fly warp would)
.setPosition
	ld a, b
	ld [wYCoord], a
	and 1
	ld [wYBlockCoord], a
	ld a, c
	ld [wXCoord], a
	and 1
	ld [wXBlockCoord], a
	ld hl, wOverworldMap + 7
	ld a, d
	ld e, a
	ld d, 0
	add hl, de ; + width
	ld a, e
	add 6
	ld e, a ; row length
	ld a, b
	srl a
	jr z, .rowsDone
.rowLoop
	add hl, de
	dec a
	jr nz, .rowLoop
.rowsDone
	ld a, c
	srl a
	ld e, a
	ld d, 0
	add hl, de
	ld a, l
	ld [wCurrentTileBlockMapViewPointer], a
	ld a, h
	ld [wCurrentTileBlockMapViewPointer + 1], a
	ld a, PLAYER_DIR_UP
	ld [wPlayerDirection], a
	ld [wPlayerMovingDirection], a
	ret

; b = species, c = level: add to the party, nicknamed after the species
.addMon
	ld a, b
	ld [wCurPartySpecies], a
	ld a, c
	ld [wCurEnemyLevel], a
	ld a, $10
	ld [wMonDataLocation], a
	call AddPartyMon
	ld a, [wCurPartySpecies]
	ld [wNamedObjectIndex], a
	call GetMonName
	ld a, [wPartyCount]
	dec a
	ld hl, wPartyMonNicks
	call SkipFixedLengthTextEntries
	ld d, h
	ld e, l
	ld hl, wNameBuffer
	ld bc, NAME_LENGTH
	jp CopyData

.hide
	ld c, a
	ld b, FLAG_SET
	jr .toggle
.show
	ld c, a
	ld b, FLAG_RESET
.toggle
	ld hl, wToggleableObjectFlags
	predef_jump FlagActionPredef

ChapterPlayerName:
	db "GOKU@"
ChapterRivalName:
	db "VEGETA@"
ChapterFriezaName:
	db "FRIEZA@"

; ===== Pokemon Rad: story Pokemon joining the team =====

; a = the starter that neither the player nor the rival took (FRIEZA stole it)
FriezaStolenStarter::
	ld hl, .starters
.loop
	ld a, [hli]
	ld b, a
	ld a, [wPlayerStarter]
	cp b
	jr z, .loop
	ld a, [wRivalStarter]
	cp b
	jr z, .loop
	ld a, b
	ld e, a ; (farcall keeps de, not a)
	ret
.starters
	db BULBASAUR, CHARMANDER, SQUIRTLE, BULBASAUR

; FRIEZA's party (1-3) for his stolen starter; also puts its name in wNameBuffer
FriezaTrainerNo::
	call FriezaStolenStarter
	ld [wNamedObjectIndex], a
	ld c, 1
	cp BULBASAUR
	jr z, .got
	inc c
	cp CHARMANDER
	jr z, .got
	inc c
.got
	push bc
	call GetMonName
	pop bc
	ld a, c
	ld e, a ; (farcall keeps de, not a)
	ret

; VEGETA's MT.MOON party (10-12) for his starter; also puts its name in wNameBuffer
VegetaTrainerNo::
	ld a, [wRivalStarter]
	ld [wNamedObjectIndex], a
	ld c, 10
	cp SQUIRTLE
	jr z, .got
	inc c
	cp BULBASAUR
	jr z, .got
	inc c
.got
	push bc
	call GetMonName
	pop bc
	ld a, c
	ld e, a ; (farcall keeps de, not a)
	ret

; d = species, e = level (farcall uses b). Joins the party; with a full party the
; player can send someone to the PC to make room, or send the new arrival there.
GiveStoryMon::
	ld a, d
	ld [wCurPartySpecies], a
	ld a, e
	ld [wCurEnemyLevel], a
	ld a, [wPartyCount]
	cp PARTY_LENGTH
	jr c, .addToParty
	ld a, [wBoxCount]
	cp MONS_PER_BOX
	jr nc, .toBox ; no room in the PC for a party member
	ld a, [wCurPartySpecies]
	ld [wNamedObjectIndex], a
	call GetMonName
	ld hl, StoryMonPartyFullText
	call PrintText
	call YesNoChoice
	ld a, [wCurrentMenuItem]
	and a
	jr nz, .toBox
	call .depositPartyMon
	jr c, .toBox
.addToParty
	ld a, $10 ; player's party, no nickname prompt
	ld [wMonDataLocation], a
	call AddPartyMon
	ld a, [wCurPartySpecies]
	ld [wNamedObjectIndex], a
	call GetMonName
	ld a, [wPartyCount]
	dec a
	ld hl, wPartyMonNicks
	call SkipFixedLengthTextEntries
	ld d, h
	ld e, l
	ld hl, wNameBuffer
	ld bc, NAME_LENGTH
	call CopyData
	ld a, [wCurPartySpecies]
	cp VEGETA
	call z, .vegetaMoves
	ld a, [wCurPartySpecies]
	cp FRIEZA
	call z, .friezaMoves
	ld hl, StoryMonJoinedText
	jp PrintText
.toBox
	ld a, [wCurPartySpecies]
	ld b, a
	ld a, [wCurEnemyLevel]
	ld c, a
	jp GivePokemon ; party full: off to the PC

.friezaMoves ; PUNCH, DEATH BEAM, DEATH SAUCER
	ld a, [wPartyCount]
	dec a
	ld hl, wPartyMon1Moves
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	ld a, PUNCH
	ld [hli], a
	ld a, DEATH_BEAM
	ld [hli], a
	ld a, DEATH_SAUCER
	ld [hli], a
	xor a
	ld [hl], a
	ld bc, MON_PP - (MON_MOVES + 3)
	add hl, bc
	ld a, 35
	ld [hli], a
	ld a, 15
	ld [hli], a
	ld a, 10
	ld [hli], a
	xor a
	ld [hl], a
	ret

.vegetaMoves ; PUNCH, GALIC GUN, SUPER SAIYAN
	ld a, [wPartyCount]
	dec a
	ld hl, wPartyMon1Moves
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	ld a, PUNCH
	ld [hli], a
	ld a, GALIC_GUN
	ld [hli], a
	ld a, SUPER_SAIYAN
	ld [hli], a
	xor a
	ld [hl], a
	ld bc, MON_PP - (MON_MOVES + 3)
	add hl, bc
	ld a, 35
	ld [hli], a
	ld a, 10
	ld [hli], a
	ld a, 5
	ld [hli], a
	xor a
	ld [hl], a
	ret

; carry if the player backed out
.depositPartyMon
	ld a, [wCurPartySpecies]
	push af
	ld a, [wCurEnemyLevel]
	push af
.pickAgain
	call SaveScreenTilesToBuffer2
	xor a
	ld [wUpdateSpritesEnabled], a
	ld [wPartyMenuTypeOrMessageID], a
	ld [wMenuItemToSwap], a
	call DisplayPartyMenu
	push af
	call GBPalWhiteOutWithDelay3
	call RestoreScreenTilesAndReloadTilePatterns
	call LoadGBPal
	pop af
	jr c, .backedOut
	ld a, [wCurPartySpecies]
	cp GOKU
	jr nz, .deposit
	ld hl, StoryMonGokuStaysText
	call PrintText
	jr .pickAgain
.deposit
	ld a, [wWhichPokemon]
	ld hl, wPartyMonNicks
	call GetPartyMonName
	ld a, PARTY_TO_BOX
	ld [wMoveMonType], a
	call MoveMon
	xor a
	ld [wRemoveMonFromBox], a
	call RemovePokemon
	ld hl, StoryMonDepositedText
	call PrintText
	and a
	jr .done
.backedOut
	scf
.done
	pop bc
	ld a, b
	ld [wCurEnemyLevel], a
	pop bc
	ld a, b
	ld [wCurPartySpecies], a
	ret

StoryMonPartyFullText:
	text_far _StoryMonPartyFullText
	text_end

StoryMonJoinedText:
	text_far _StoryMonJoinedText
	sound_get_item_1
	text_end

StoryMonGokuStaysText:
	text_far _StoryMonGokuStaysText
	text_end

StoryMonDepositedText:
	text_far _StoryMonDepositedText
	text_end

; After VEGETA joins, FRIEZA takes over as the rival: rival battles get
; FRIEZA's picture, and VEGETA in a rival's party becomes FRIEZA.
FriezaReplacesRival::
	CheckEvent EVENT_VEGETA_JOINED
	ret z
	ld a, [wTrainerClass]
	ld hl, Gary1Pic
	cp RIVAL1
	jr z, .rival
	ld hl, Rival2Pic ; GARY
	cp RIVAL2
	jr z, .rival
	ld hl, Rival3Pic ; GARY
	cp RIVAL3
	ret nz
.rival
	CheckEvent EVENT_FRIEZA_JOINED
	jr nz, GaryIsBack
	ld hl, wTrainerPicPointer
	ld a, LOW(ChiefPic)
	ld [hli], a
	ld [hl], HIGH(ChiefPic)
; he lost his starter: now it's MEWTWO, then FRIEZA himself
; (at the level of the team's strongest)
	xor a
	ld [wEnemyPartyCount], a
	dec a
	ld [wEnemyPartySpecies], a
	ld a, [wCurEnemyLevel]
	push af
	ld a, 15 ; MEWTWO is still a baby
	ld [wCurEnemyLevel], a
	ld a, MEWTWO
	call .add
	pop af
	ld [wCurEnemyLevel], a
	ld a, FRIEZA
.add
	ld [wCurPartySpecies], a
	ld a, ENEMY_PARTY_DATA
	ld [wMonDataLocation], a
	jp AddPartyMon

; Pokemon Rad: after FRIEZA joins, GARY (the original rival) is back, with
; his three strongest POKeMON and all three legendary birds.
; hl = GARY's picture for this battle
GaryIsBack:
	ld a, l
	ld [wTrainerPicPointer], a
	ld a, h
	ld [wTrainerPicPointer + 1], a
; keep the last 3 POKeMON (the strongest, starter included)
	ld a, [wEnemyPartyCount]
	sub 3
	jr c, .addBirds
	jr z, .trim
	ld b, a ; how many to drop
	push bc
	ld c, b
	ld b, 0
	ld hl, wEnemyPartySpecies
	add hl, bc
	ld de, wEnemyPartySpecies
	ld bc, 3
	call CopyData
	pop bc
	ld a, b
	ld hl, wEnemyMon1
	ld bc, PARTYMON_STRUCT_LENGTH
	call AddNTimes
	ld de, wEnemyMon1
	ld bc, PARTYMON_STRUCT_LENGTH * 3
	call CopyData
.trim
	ld a, 3
	ld [wEnemyPartyCount], a
	ld a, $ff
	ld [wEnemyPartySpecies + 3], a
.addBirds
	ld hl, .Birds
.birdLoop
	ld a, [hli]
	and a
	ret z
	push hl
	ld [wCurPartySpecies], a
	ld a, ENEMY_PARTY_DATA
	ld [wMonDataLocation], a
	call AddPartyMon
	pop hl
	jr .birdLoop
.Birds:
	db ARTICUNO, ZAPDOS, MOLTRES, 0

; Before GARY's first battle: he says who he is
GaryIntroduces::
	CheckEvent EVENT_FRIEZA_JOINED
	ret z
	CheckEvent EVENT_GARY_INTRODUCED
	ret nz
	SetEvent EVENT_GARY_INTRODUCED
	ld hl, GaryIntroText
	jp PrintText

GaryIntroText:
	text_far _GaryIntroText
	text_end
