AnimateHealingMachine:
	xor a
	ld [wUnusedMapVariable], a ; Pokemon Rad: set if Goku hops on
	ld de, PokeCenterFlashingMonitorAndHealBall
	ld hl, vChars0 tile $7c
	lb bc, BANK(PokeCenterFlashingMonitorAndHealBall), 3 ; should be 2
	call CopyVideoData
	ld hl, wUpdateSpritesEnabled
	ld a, [hl]
	push af
	ld [hl], $ff
	push hl
	ldh a, [rOBP1]
	push af
	ld a, $e0
	ldh [rOBP1], a
	ld hl, wShadowOAMSprite33
	ld de, PokeCenterOAMData
	call CopyHealingMachineOAM
	ld a, 4
	ld [wAudioFadeOutControl], a
	ld a, SFX_STOP_ALL_MUSIC
	ld [wNewSoundID], a
	call PlaySound
.waitLoop
	ld a, [wAudioFadeOutControl]
	and a ; is fade-out finished?
	jr nz, .waitLoop ; if not, check again
	call CountMachineBalls ; Pokemon Rad: Goku doesn't go in a # BALL
	ld a, b
	and a
	jr z, .noBalls
.partyLoop
	call CopyHealingMachineOAM
	ld a, SFX_HEALING_MACHINE
	call PlaySound
	ld c, 30
	call DelayFrames
	dec b
	jr nz, .partyLoop
.noBalls
	call GokuHopsOnHealingMachine ; Pokemon Rad
	ld a, [wAudioROMBank]
	cp BANK("Audio Engine 3")
	ld [wAudioSavedROMBank], a
	jr nz, .next
	ld a, SFX_STOP_ALL_MUSIC
	ld [wNewSoundID], a
	call PlaySound
	ld a, BANK(Music_PkmnHealed)
	ld [wAudioROMBank], a
.next
	ld a, MUSIC_PKMN_HEALED
	ld [wNewSoundID], a
	call PlaySound
	ld d, $28
	call FlashSprite8Times
.waitLoop2
	ld a, [wChannelSoundIDs]
	cp MUSIC_PKMN_HEALED ; is the healed music still playing?
	jr z, .waitLoop2 ; if so, check gain
	ld c, 32
	call DelayFrames
	call GokuPushedOffHealingMachine ; Pokemon Rad
	pop af
	ldh [rOBP1], a
	pop hl
	pop af
	ld [hl], a
	jp UpdateSprites

PokeCenterFlashingMonitorAndHealBall:
	INCBIN "gfx/overworld/heal_machine.2bpp"

PokeCenterOAMData:
	; heal machine monitor
	dbsprite  6,  4,  4,  4, $7c, OAM_PAL1
	; poke balls 1-6
	dbsprite  6,  5,  0,  3, $7d, OAM_PAL1
	dbsprite  7,  5,  0,  3, $7d, OAM_PAL1 | OAM_XFLIP
	dbsprite  6,  6,  0,  0, $7d, OAM_PAL1
	dbsprite  7,  6,  0,  0, $7d, OAM_PAL1 | OAM_XFLIP
	dbsprite  6,  6,  0,  5, $7d, OAM_PAL1
	dbsprite  7,  6,  0,  5, $7d, OAM_PAL1 | OAM_XFLIP

; d = value to xor with palette
FlashSprite8Times:
	ld b, 8
.loop
	ldh a, [rOBP1]
	xor d
	ldh [rOBP1], a
	ld c, 10
	call DelayFrames
	dec b
	jr nz, .loop
	ret

CopyHealingMachineOAM:
; copy one OAM entry and advance the pointers
REPT 4
	ld a, [de]
	inc de
	ld [hli], a
ENDR
	ret


; ===== Pokemon Rad: Goku hops onto the healing machine =====
DEF GOKU_MACHINE_OAM_Y EQU 36 ; top-left of Goku's 2x2 sprite, standing on the machine
DEF GOKU_MACHINE_OAM_X EQU 48

GokuHopsOnHealingMachine:
	ld hl, wPartySpecies
.findGoku
	ld a, [hli]
	cp $ff
	ret z ; Goku isn't in the party
	cp GOKU
	jr nz, .findGoku
	ld c, 20
	call DelayFrames
	farcall GokuSpareWalkFrames ; he walks over (the font covers the usual walking frames)
	xor a
	ld [wStringBuffer + 19], a ; walking animation counter
; top-left corner of the player's sprite (OAM entries 0-3)
	ld hl, wShadowOAM
	lb bc, $ff, $ff ; b = min Y, c = min X
	ld e, 4
.minLoop
	ld a, [hli]
	cp b
	jr nc, .notMinY
	ld b, a
.notMinY
	ld a, [hli]
	cp c
	jr nc, .notMinX
	ld c, a
.notMinX
	inc hl
	inc hl
	dec e
	jr nz, .minLoop
	ld a, b
	ld [wUnusedMapVariable], a ; where he jumped from (for the nurse)
	ld a, c
	ld [wUnusedLastMapWidth], a
	ld a, GOKU_MACHINE_OAM_Y
	sub b
	ld d, a ; d = Y still to move (signed)
	ld a, GOKU_MACHINE_OAM_X
	sub c
	ld e, a ; e = X still to move (signed)
	ld a, SFX_LEDGE
	call PlaySound
; jump up
	ld b, 10
.riseLoop
	push bc
	lb bc, -1, 0
	call ShiftPlayerOAM
	call HopWalkAnim
	pop bc
	inc d
	call DelayFrame
	dec b
	jr nz, .riseLoop
; fly over to the machine, one pixel per frame on each axis
.moveLoop
	ld b, 0
	ld a, d
	and a
	jr z, .yDone
	ld b, 1
	bit 7, a
	jr z, .yDone
	ld b, -1
.yDone
	ld c, 0
	ld a, e
	and a
	jr z, .xDone
	ld c, 1
	bit 7, a
	jr z, .xDone
	ld c, -1
.xDone
	ld a, b
	or c
	jr z, .landed
	call ShiftPlayerOAM
	call HopWalkAnim
	ld a, d
	sub b
	ld d, a
	ld a, e
	sub c
	ld e, a
	call DelayFrame
	jr .moveLoop
.landed
	call HopStandStill
	ld a, SFX_COLLISION
	call PlaySound
; the other # BALLs stay put on the machine
	xor a
	ld [wShadowOAMSprite33YCoord], a ; hide the monitor sprite under Goku
	ret

; every 4 frames, switch the player's OAM between standing and walking tiles
HopWalkAnim:
	push hl
	push bc
	ld hl, wStringBuffer + 19
	inc [hl]
	ld a, [hl]
	and 3
	jr nz, .done
	ld hl, wShadowOAMSprite00TileID
	ld b, 4
.loop
	ld a, [hl]
	xor $60 ; standing tile <-> its walking twin
	ld [hli], a
	inc hl
	inc hl
	inc hl
	dec b
	jr nz, .loop
.done
	pop bc
	pop hl
	ret

; back to the standing tiles
HopStandStill:
	push hl
	push bc
	ld hl, wShadowOAMSprite00TileID
	ld b, 4
.loop
	ld a, [hl]
	and ~$60
	ld [hli], a
	inc hl
	inc hl
	inc hl
	dec b
	jr nz, .loop
	pop bc
	pop hl
	ret

; b = Y change, c = X change for OAM entries 0-3 (the player)
ShiftPlayerOAM:
	push de
	ld hl, wShadowOAM
	ld e, 4
.loop
	ld a, [hl]
	add b
	ld [hli], a
	ld a, [hl]
	add c
	ld [hli], a
	inc hl
	inc hl
	dec e
	jr nz, .loop
	pop de
	ret

; b = number of party mons that go in a # BALL (everyone except Goku)
CountMachineBalls:
	push hl
	ld hl, wPartySpecies
	ld b, 0
.loop
	ld a, [hli]
	cp $ff
	jr z, .done
	call IsCustomFighter ; Pokemon Rad: fighters don't go in # BALLs
	jr z, .loop
	inc b
	jr .loop
.done
	pop hl
	ret

; Pokemon Rad: the nurse shoves Goku off the machine, back where he was standing
GokuPushedOffHealingMachine:
	ld a, [wUnusedMapVariable]
	and a
	ret z ; Goku didn't hop on
	ld b, a
	ld a, [wUnusedLastMapWidth]
	ld c, a
	ld a, b
	sub GOKU_MACHINE_OAM_Y
	ld d, a ; Y to move back
	ld a, c
	sub GOKU_MACHINE_OAM_X
	ld e, a ; X to move back
	ld a, SFX_COLLISION ; shove!
	call PlaySound
.moveLoop ; two pixels a frame: he's being pushed
	ld b, 0
	ld a, d
	and a
	jr z, .yDone
	ld b, 1
	bit 7, a
	jr z, .yDone
	ld b, -1
.yDone
	ld c, 0
	ld a, e
	and a
	jr z, .xDone
	ld c, 1
	bit 7, a
	jr z, .xDone
	ld c, -1
.xDone
	ld a, b
	or c
	jr z, .done
	call ShiftPlayerOAM
	call HopWalkAnim
	ld a, d
	sub b
	ld d, a
	ld a, e
	sub c
	ld e, a
	ld a, d
	or e
	jr z, .done
	ld a, d
	and a
	jr z, .secondStep
	ld a, e
	and a
	jr z, .secondStep
.secondStep
	call DelayFrame
	jr .moveLoop
.done
	call HopStandStill
	ld a, SFX_LEDGE
	call PlaySound
	xor a
	ld [wUnusedMapVariable], a
	ld c, 10
	jp DelayFrames
