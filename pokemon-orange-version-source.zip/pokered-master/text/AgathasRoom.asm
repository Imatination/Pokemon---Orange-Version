_AgathaBeforeBattleText::
	text "I'm AGATHA of"
	line "the ELITE FOUR!"
	cont "My, my! Battling"
	cont "you will be fun!"

	para "<PLAYER>: Fun?"
	line "Can I fight a"
	cont "ghost? For real?"

	para "My ghosts will"
	line "fight YOU, dear."

	para "<PLAYER>: So"
	line "I just watch."
	cont "Again."
	done

_AgathaEndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_AgathaAfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_AgathasRoomAgathaDontRunAwayText::
	text "Someone's voice:"
	line "Don't run away!"
	done
