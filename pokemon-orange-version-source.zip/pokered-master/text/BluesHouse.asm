_BluesHouseDaisyRivalAtLabText::
	text "BULMA: Hi,"
	line "<PLAYER>! VEGETA"
	cont "is at OAK's lab."

	para "Yes, his WIFE!"
	line "Don't ask how"
	cont "that happened!"
	done

_BluesHouseDaisyOfferMapText::
	text "BULMA: OAK asked"
	line "you to run an"
	cont "errand?"

	para "Here, this will"
	line "help you!"
	prompt

_GotMapText::
	text "<PLAYER> got a"
	line "@"
	text_ram wStringBuffer
	text "!@"
	text_end

_BluesHouseDaisyBagFullText::
	text "You have too much"
	line "stuff with you."
	done

_BluesHouseDaisyUseMapText::
	text "Use the TOWN MAP"
	line "to find out where"
	cont "you are."
	done

_BluesHouseDaisyWalkingText::
	text "BULMA: Rest your"
	line "#MON when they"
	cont "get tired!"
	done

_BluesHouseTownMapText::
	text "It's a big map!"
	line "This is useful!"
	done

_GravityPCOffText::
	text "GRAVITY MACHINE"
	line "Status: OFF"

	para "TURN ON?"
	done

_GravityPCOnText::
	text "GRAVITY MACHINE"
	line "Status: 100x"

	para "TURN OFF?"
	done

_GravityPCNowOnText::
	text "The GRAVITY is"
	line "now 100 times"
	cont "stronger!"

	para "Every step is"
	line "hard training!"

	para "SELECT picks who"
	line "trains!"
	done

_GravityPCNowOffText::
	text "The GRAVITY is"
	line "back to normal."
	done

_GravityMonLevelUpText::
	text_ram wNameBuffer
	text " grew to"
	line "level @"
	text_decimal wStringBuffer, 2, 4
	text "!"
	done

_GravityFighterLevelUpText::
	text_ram wNameBuffer
	text "'s power"
	line "level: @"
	text_decimal wStringBuffer, 2, 4
	text "!"
	done

_GravityTraineeText::
	text "Training:"
	line "@"
	text_ram wNameBuffer
	text "!@"
	text_end

_GravityPCChooseText::
	text "GRAVITY MACHINE"
	line "Set the GRAVITY:"
	done

_GravityPCNow100Text::
	text "The GRAVITY is"
	line "now 100 times"
	cont "stronger!"
	done

_GravityPCNow200Text::
	text "200 times the"
	line "GRAVITY! Two"
	cont "times the power!"
	done

_GravityPCNow400Text::
	text "400 times the"
	line "GRAVITY! Four"
	cont "times the power!"
	done

_GravityUnlocked200Text::
	text "MAX POWER!"

	para "The GRAVITY"
	line "MACHINE can now"
	cont "go up to 200x!"
	prompt

_GravityUnlocked400Text::
	text "MAX POWER again!"

	para "The GRAVITY"
	line "MACHINE can now"
	cont "go up to 400x!"
	prompt
