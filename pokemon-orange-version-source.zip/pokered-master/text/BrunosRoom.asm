_BrunoBeforeBattleText::
	text "I am BRUNO of"
	line "the ELITE FOUR!"
	cont "I train with my"
	cont "bare hands!"

	para "<PLAYER>: YES!"
	line "FINALLY! A real"
	cont "fighter! Let's go!"

	para "Hoo hah! My"
	line "fighting #MON"
	cont "will battle you!"

	para "<PLAYER>: ..."
	line "Seriously? YOU"
	cont "too, BRUNO?!"
	done

_BrunoEndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_BrunoAfterBattleText::
	text "Nobody battles"
	line "like you do!"

	para "<PLAYER> mumbled"
	line "something about"
	cont "Kamehamehas."
	done

_BrunosRoomBrunoDontRunAwayText::
	text "Someone's voice:"
	line "Don't run away!"
	done
