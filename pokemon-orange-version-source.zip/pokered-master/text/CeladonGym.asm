_CeladonGymErikaPreBattleText::
	text "Hello. Lovely"
	line "weather, isn't"
	cont "it?"

	para "Oh! You're"
	line "<PLAYER>! I've so"
	cont "wanted to battle!"

	para "<PLAYER>: Great!"
	line "Is flower"
	cont "arranging a"
	cont "fighting style?"

	para "Oh my, no. My"
	line "grass #MON"
	cont "will battle you."

	para "<PLAYER> nodded"
	line "sadly. He knew."
	done

_CeladonGymErikaReceivedRainbowBadgeText::
	text "Oh!"
	line "I concede defeat."

	para "You are remarkably"
	line "strong."

	para "I must confer you"
	line "the RAINBOWBADGE."
	prompt

_CeladonGymErikaPostBattleAdviceText::
	text "You are cataloging"
	line "#MON? I must"
	cont "say I'm impressed."

	para "I would never"
	line "collect #MON"
	cont "if they were"
	cont "unattractive."
	done

_CeladonGymRainbowBadgeInfoText::
	text "The RAINBOWBADGE"
	line "will make #MON"
	cont "up to L50 obey."

	para "It also allows"
	line "#MON to use"
	cont "STRENGTH in and"
	cont "out of battle."

	para "Please also take"
	line "this with you."
	done

_CeladonGymReceivedTM21Text::
	text "<PLAYER> received"
	line "@"
	text_ram wStringBuffer
	text "!@"
	text_end

_TM21ExplanationText::
	text_start

	para "TM21 contains"
	line "MEGA DRAIN."

	para "Half the damage"
	line "it inflicts is"
	cont "drained to heal"
	cont "your #MON!"
	done

_CeladonGymTM21NoRoomText::
	text "You should make"
	line "room for this."
	done

_CeladonGymBattleText2::
	text "Whoa! Are you"
	line "<PLAYER>? Let's"
	cont "battle right now!"

	para "<PLAYER> grinned"
	line "and cracked his"
	cont "knuckles. Yes!"
	done

_CeladonGymEndBattleText2::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_CeladonGymAfterBattleText2::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done

_CeladonGymBattleText3::
	text "I've been"
	line "stretching all"
	cont "morning for you!"

	para "<PLAYER>: Ooh!"
	line "A real warrior!"
	cont "Come on!"
	done

_CeladonGymEndBattleText3::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_CeladonGymAfterBattleText3::
	text "Whoa, I'm sore"
	line "from that battle!"

	para "<PLAYER>: How?!"
	line "You didn't move!"
	done

_CeladonGymBattleText4::
	text "You! Me! Battle!"
	line "No running away!"

	para "<PLAYER>: Run?"
	line "I never run from"
	cont "a good fight!"
	done

_CeladonGymEndBattleText4::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_CeladonGymAfterBattleText4::
	text "My hands are"
	line "still shaking!"

	para "<PLAYER>: Then"
	line "let's spar!"
	cont "Hey! Come back!"
	done

_CeladonGymBattleText5::
	text "You look tough!"
	line "Our battle will"
	cont "be epic!"

	para "<PLAYER>: I've"
	line "been waiting all"
	cont "day for this!"
	done

_CeladonGymEndBattleText5::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_CeladonGymAfterBattleText5::
	text "Everyone talks"
	line "about how strong"
	cont "you are!"

	para "<PLAYER>: Then"
	line "why won't anyone"
	cont "fight me?!"
	done

_CeladonGymBattleText6::
	text "I heard about"
	line "your power level!"
	cont "Battle me!"

	para "<PLAYER>: Wow,"
	line "you know about"
	cont "power levels?"
	done

_CeladonGymEndBattleText6::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_CeladonGymAfterBattleText6::
	text "I'll never forget"
	line "our epic clash!"

	para "<PLAYER>: What"
	line "clash? Our hands"
	cont "never touched!"
	done

_CeladonGymBattleText7::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done

_CeladonGymEndBattleText7::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_CeladonGymAfterBattleText7::
	text "Let's battle"
	line "again tomorrow!"

	para "<PLAYER>: Can we"
	line "spar instead?"
	cont "...No? Okay."
	done

_CeladonGymBattleText8::
	text "My #MON and I"
	line "are fired up!"
	cont "Battle time!"

	para "<PLAYER>: Your"
	line "#MON? Wait..."
	cont "who do I punch?"
	done

_CeladonGymEndBattleText8::
	text "Ahh!"
	line "My #MON!"
	prompt

_CeladonGymAfterBattleText8::
	text "I can't believe"
	line "I battled THE"
	cont "<PLAYER>!"

	para "<PLAYER>: You"
	line "still haven't."
	cont "Not really."
	done
