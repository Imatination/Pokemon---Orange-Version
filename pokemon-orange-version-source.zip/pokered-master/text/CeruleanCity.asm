_CeruleanCityRivalPreBattleText::
	text "<RIVAL>: Yo!"
	line "<PLAYER>!"

	para "Battle time! I"
	line "can't wait to"
	cont "beat you!"

	para "<PLAYER>: You"
	line "always say that,"
	cont "then you send"
	cont "out a #MON!"

	para "<RIVAL>: That's"
	line "how battles"
	cont "work!"
	done

_CeruleanCityRivalDefeatedText::
	text "Hey!"
	line "Take it easy!"
	cont "You won already!"
	prompt

_CeruleanCityRivalVictoryText::
	text "Heh!"
	line "You're no match"
	cont "for my genius!"
	prompt

_CeruleanCityRivalIWentToBillsText::
	text "<RIVAL>: Hey,"
	line "guess what?"

	para "I went to BILL's"
	line "and got him to"
	cont "show me his rare"
	cont "#MON!"

	para "That added a lot"
	line "of pages to my"
	cont "#DEX!"

	para "After all, BILL's"
	line "world famous as a"
	cont "#MANIAC!"

	para "He invented the"
	line "#MON Storage"
	cont "System on PC!"

	para "Since you're using"
	line "his system, go"
	cont "thank him!"

	para "Well, I better"
	line "get rolling!"
	cont "Smell ya later!"
	done

_CeruleanCityRocketText::
	text "Hey! Stay out!"
	line "It's not your"
	cont "yard! Huh? Me?"

	para "I'm an innocent"
	line "bystander! Don't"
	cont "you believe me?"
	done

_CeruleanCityRocketReceivedTM28Text::
	text "<PLAYER> recovered"
	line "TM28!@"
	text_end

_CeruleanCityRocketIBetterGetMovingText::
	text_start

	para "I better get"
	line "moving! Bye!@"
	text_end

_CeruleanCityRocketTM28NoRoomText::
	text "Make room for"
	line "this!"

	para "I can't run until"
	line "I give it to you!"
	done

_CeruleanCityRocketIGiveUpText::
	text "Stop!"
	line "I give up! I'll"
	cont "leave quietly!"
	prompt

_CeruleanCityRocketIllReturnTheTMText::
	text "OK! I'll return"
	line "the TM I stole!"
	prompt

_CeruleanCityCooltrainerMText::
	text "You're a trainer"
	line "too? Collecting,"
	cont "fighting, it's a"
	cont "tough life."
	done

_CeruleanCitySuperNerd1Text::
	text "That bush in"
	line "front of the shop"
	cont "is in the way."

	para "There might be a"
	line "way around."
	done

_CeruleanCitySuperNerd2Text::
	text "You're making an"
	line "encyclopedia on"
	cont "#MON? That"
	cont "sounds amusing."
	done

_CeruleanCityGuardText::
	text "The people here"
	line "were robbed."

	para "It's obvious that"
	line "TEAM ROCKET is"
	cont "behind this most"
	cont "heinous crime!"

	para "Even our POLICE"
	line "force has trouble"
	cont "with the ROCKETs!"
	done

_CeruleanCityCooltrainerF1SlowbroUseSonicboomText::
	text "OK! SLOWBRO!"
	line "Use SONICBOOM!"
	cont "Come on, SLOWBRO"
	cont "pay attention!"
	done

_CeruleanCityCooltrainerF1SlowbroPunchText::
	text "SLOWBRO punch!"
	line "No! You blew it"
	cont "again!"
	done

_CeruleanCityCooltrainerF1SlowbroWithdrawText::
	text "SLOWBRO, WITHDRAW!"
	line "No! That's wrong!"

	para "It's so hard to"
	line "control #MON!"

	para "Your #MON's"
	line "obedience depends"
	cont "on your abilities"
	cont "as a trainer!"
	done

_CeruleanCitySlowbroTookASnoozeText::
	text "SLOWBRO took a"
	line "snooze..."
	done

_CeruleanCitySlowbroIsLoafingAroundText::
	text "SLOWBRO is"
	line "loafing around..."
	done

_CeruleanCitySlowbroTurnedAwayText::
	text "SLOWBRO turned"
	line "away..."
	done

_CeruleanCitySlowbroIgnoredOrdersText::
	text "SLOWBRO"
	line "ignored orders..."
	done

_CeruleanCityCooltrainerF2Text::
	text "I want a bright"
	line "red BICYCLE!"

	para "I'll keep it at"
	line "home, so it won't"
	cont "get dirty!"
	done

_CeruleanCitySuperNerd3Text::
	text "This is CERULEAN"
	line "CAVE! Horribly"
	cont "strong #MON"
	cont "live in there!"

	para "The #MON LEAGUE"
	line "champion is the"
	cont "only person who"
	cont "is allowed in!"
	done

_CeruleanCitySignText::
	text "CERULEAN CITY"
	line "A Mysterious,"
	cont "Blue Aura"
	cont "Surrounds It"
	done

_CeruleanCityTrainerTipsText::
	text "TRAINER TIPS"

	para "Pressing B Button"
	line "during evolution"
	cont "cancels the whole"
	cont "process."
	done

_CeruleanCityBikeShopSign::
	text "Grass and caves"
	line "handled easily!"
	cont "BIKE SHOP"
	done

_CeruleanCityGymSign::
	text "CERULEAN CITY"
	line "#MON GYM"
	cont "LEADER: MISTY"

	para "The Tomboyish"
	line "Mermaid!"
	done

_CeruleanCityGokuNimbusIdeaText::
	text "<PLAYER>: A bike"
	line "is nice..."

	para "But you know"
	line "what's way better"
	cont "than a BICYCLE?"

	para "<PLAYER>: NIMBUS!"
	prompt

_CeruleanCityGotNimbusText::
	text "<PLAYER> got the"
	line "FLYING NIMBUS!@"
	text_end

_CeruleanCityNimbusHowToText::
	text_start

	para "Use it from the"
	line "ITEM menu to fly!"
	done

_CeruleanCityFriezaJoinsText::
	text "FRIEZA: Wait!"
	line "P-please... let"
	cont "me join you!"

	para "VEGETA: WHAT?!"
	line "Never! He's a"
	cont "tyrant, KAKAROT!"

	para "<PLAYER>: We'll"
	line "need his power to"
	cont "beat the ELITE"
	cont "FOUR, VEGETA."

	para "VEGETA: ...Tch!"
	line "Fine. But I'm"
	cont "watching him!"
	prompt

_CeruleanCityVegetaGravityText::
	text "VEGETA: Hmph."
	line "If FRIEZA is with"
	cont "us, we train."

	para "Back to PALLET"
	line "TOWN, KAKAROT!"

	para "BULMA built a"
	line "GRAVITY TRAINING"
	cont "ROOM where my"
	cont "house was!"
	done

_CeruleanCityFriezaDemandsText::
	text "FRIEZA: Ohoho..."
	line "Hello again,"
	cont "monkey."

	para "I... miss my"
	line "little #MON."
	cont "I want it back!"

	para "Hand it over, or"
	line "I'll take it!"
	done

_CeruleanCityFriezaBeatenText::
	text "N-no!"
	line "Beaten by a"
	cont "monkey AGAIN?!"
	prompt

_CeruleanCityFriezaWinsText::
	text "Ohoho!"
	line "Too easy,"
	cont "monkey!"
	prompt

_CeruleanCityFriezaPreBattleText::
	text "FRIEZA: Ohoho!"
	line "Hello, monkey."

	para "My starter? Keep"
	line "it! I don't care!"

	para "I found a far"
	line "stronger #MON."
	cont "An alien, just"
	cont "like me!"

	para "Behold... MEWTWO!"
	done

_CeruleanCityFriezaBridgeBeatenText::
	text "Grr!"
	line "A lucky shot,"
	cont "monkey!"
	prompt

_CeruleanCityFriezaBridgeWinsText::
	text "Ohohoho!"
	line "Too weak,"
	cont "monkey!"
	prompt

_CeruleanCityFriezaOffToBillText::
	text "FRIEZA: Hmph!"
	line "Enjoy your little"
	cont "win, monkey."

	para "I'm off to visit"
	line "this BILL..."

	para "...and turn him"
	line "into a CLEFAIRY!"

	para "Ohohohohoho!"
	done

_CeruleanCityFriezaDemandsAgainText::
	text "FRIEZA: Ohoho..."
	line "Hello again,"
	cont "monkey."

	para "MEWTWO is strong,"
	line "but... I miss my"
	cont "little #MON."

	para "I want it back!"
	line "Hand it over, or"
	cont "I'll take it!"
	done

_CeruleanCityMewtwoFleesText::
	text "But MEWTWO broke"
	line "free and flew"
	cont "off!"

	para "It must have gone"
	line "back to its cave."
	prompt
