_CeruleanGymMistyPreBattleText::
	text "Hi, you're a new"
	line "face! I'm MISTY!"

	para "I've dreamed of"
	line "battling a real"
	cont "martial artist!"

	para "<PLAYER>: You"
	line "know martial arts"
	cont "too? Let's go!"

	para "Huh? No! My"
	line "water #MON"
	cont "will battle you!"

	para "<PLAYER>: ...Of"
	line "course they will."
	done

_CeruleanGymMistyTM11ExplanationText::
	text "TM11 teaches"
	line "BUBBLEBEAM!"

	para "Use it on an"
	line "aquatic #MON!"
	done

_CeruleanGymMistyCascadeBadgeInfoText::
	text "The CASCADEBADGE"
	line "makes all #MON"
	cont "up to L30 obey!"

	para "That includes"
	line "even outsiders!"

	para "There's more, you"
	line "can now use CUT"
	cont "any time!"

	para "You can CUT down"
	line "small bushes to"
	cont "open new paths!"

	para "You can also have"
	line "my favorite TM!"
	done

_CeruleanGymMistyReceivedTM11Text::
	text "<PLAYER> received"
	line "TM11!@"
	text_end

_CeruleanGymMistyTM11NoRoomText::
	text "You better make"
	line "room for this!"
	done

_CeruleanGymMistyReceivedCascadeBadgeText::
	text "Wow!"
	line "You're too much!"

	para "All right!"

	para "You can have the"
	line "CASCADEBADGE to"
	cont "show you beat me!@"
	text_end

_CeruleanGymBattleText1::
	text "Feel this aura?"
	line "It's my fighting"
	cont "spirit!"

	para "<PLAYER>: It's"
	line "tiny, but I like"
	cont "your attitude!"
	done

_CeruleanGymEndBattleText1::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_CeruleanGymAfterBattleText1::
	text "You battle like"
	line "a true master!"

	para "<PLAYER>: I"
	line "didn't even get"
	cont "to warm up!"
	done

_CeruleanGymBattleText2::
	text "Everyone says"
	line "you're the best"
	cont "fighter around!"

	para "<PLAYER> started"
	line "powering up."
	cont "Let's do this!"
	done

_CeruleanGymEndBattleText2::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_CeruleanGymAfterBattleText2::
	text "You're a battle"
	line "genius, <PLAYER>!"

	para "<PLAYER>: I"
	line "didn't battle!"
	cont "Your #MON did!"
	done

_CeruleanGymGymGuideChampInMakingText::
	text "Yo! Champ in"
	line "making!"

	para "Here's my advice!"

	para "The LEADER, MISTY,"
	line "is a pro who uses"
	cont "water #MON!"

	para "You can drain all"
	line "their water with"
	cont "plant #MON!"

	para "Or, zap them with"
	line "electricity!"
	done

_CeruleanGymGymGuideBeatMistyText::
	text "You beat MISTY!"
	line "What'd I tell ya?"

	para "You and me kid,"
	line "we make a pretty"
	cont "darn good team!"
	done
