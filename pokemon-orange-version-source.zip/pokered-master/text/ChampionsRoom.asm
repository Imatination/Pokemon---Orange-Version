_ChampionsRoomRivalIntroText::
	text "<RIVAL>: Hey!"
	line "<PLAYER>!"

	para "I'm the new"
	line "#MON LEAGUE"
	cont "champion!"

	para "I've waited my"
	line "whole journey to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Let's finally go"
	cont "all out!"
	cont "Hand to hand!"

	para "<RIVAL>: Hand"
	line "to... what? No!"
	cont "#MON battle!"

	para "<PLAYER>: Sigh."
	line "Okay. One last"
	cont "time..."
	done

_RivalDefeatedText::
	text "NO!"
	line "That can't be!"
	cont "What a battle!"
	prompt

_RivalVictoryText::
	text "Hahaha!"
	line "I won, I won!"

	para "I'm too good for"
	line "you, <PLAYER>!"

	para "You did well to"
	line "even reach me,"
	cont "<RIVAL>, the"
	cont "#MON genius!"

	para "Nice try, loser!"
	line "Hahaha!"
	prompt

_ChampionsRoomRivalAfterBattleText::
	text "My #MON did"
	line "their best!"

	para "<PLAYER>: Great!"
	line "Now YOU do your"
	cont "best. Hands up!"

	para "...Huh? Battle's"
	line "over? Again?"
	done

_ChampionsRoomOakText::
	text "OAK: <PLAYER>!"
	done

_ChampionsRoomOakCongratulatesPlayerText::
	text "OAK: So, you won!"
	line "Congratulations!"
	cont "You're the new"
	cont "#MON LEAGUE"
	cont "champion!"

	para "You've grown up so"
	line "much since you"
	cont "first left with"
	cont "@"
	text_ram wNameBuffer
	text "!"

	para "<PLAYER>, you have"
	line "come of age!"
	done

_ChampionsRoomOakDisappointedWithRivalText::
	text "OAK: <RIVAL>! I'm"
	line "disappointed!"

	para "I came when I"
	line "heard you beat"
	cont "the ELITE FOUR!"

	para "But, when I got"
	line "here, you had"
	cont "already lost!"

	para "<RIVAL>! Do you"
	line "understand why"
	cont "you lost?"

	para "You have forgotten"
	line "to treat your"
	cont "#MON with"
	cont "trust and love!"

	para "Without them, you"
	line "will never become"
	cont "a champ again!"
	done

_ChampionsRoomOakComeWithMeText::
	text "OAK: <PLAYER>!"

	para "You understand"
	line "that your victory"
	cont "was not just your"
	cont "own doing!"

	para "The bond you share"
	line "with your #MON"
	cont "is marvelous!"

	para "<PLAYER>!"
	line "Come with me!"
	done
