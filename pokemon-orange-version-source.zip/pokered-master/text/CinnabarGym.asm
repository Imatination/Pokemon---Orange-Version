_CinnabarGymBlainePreBattleText::
	text "Hah! I'm BLAINE!"
	line "I'm burning to"
	cont "battle you!"

	para "<PLAYER>: Hot"
	line "blooded! I like"
	cont "it! Fists up!"

	para "My fire #MON"
	line "will do the"
	cont "fighting!"

	para "<PLAYER>: Of"
	line "course they will."
	done

_CinnabarGymBlaineReceivedVolcanoBadgeText::
	text "I have"
	line "burnt out!"

	para "You have earned"
	line "the VOLCANOBADGE!@"
	text_end

_CinnabarGymBlainePostBattleAdviceText::
	text "FIRE BLAST is the"
	line "ultimate fire"
	cont "technique!"

	para "Don't waste it on"
	line "water #MON!"
	done

_CinnabarGymBlaineVolcanoBadgeInfoText::
	text "Hah!"

	para "The VOLCANOBADGE"
	line "heightens the"
	cont "SPECIAL abilities"
	cont "of your #MON!"

	para "Here, you can"
	line "have this too!"
	done

_CinnabarGymBlaineReceivedTM38Text::
	text "<PLAYER> received"
	line "@"
	text_ram wStringBuffer
	text "!@"
	text_end

_CinnabarGymBlaineTM38ExplanationText::
	text_start

	para "TM38 contains"
	line "FIRE BLAST!"

	para "Teach it to fire-"
	line "type #MON!"

	para "CHARMELEON or"
	line "PONYTA would be"
	cont "good bets!"
	done

_CinnabarGymBlaineTM38NoRoomText::
	text "Make room for my"
	line "gift!"
	done

_CinnabarGymSuperNerd1BattleText::
	text "Our eyes met!"
	line "That means we"
	cont "have to battle!"

	para "<PLAYER>: I"
	line "LOVE that rule!"
	done

_CinnabarGymSuperNerd1EndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_CinnabarGymSuperNerd1AfterBattleText::
	text "Battle me again"
	line "after I train!"

	para "<PLAYER>: Try"
	line "gravity training!"
	cont "100x is fun!"
	done

_CinnabarGymSuperNerd2BattleText::
	text "I've got moves"
	line "you've never"
	cont "even seen!"

	para "<PLAYER>: Show"
	line "me! Show me!"
	done

_CinnabarGymSuperNerd2EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_CinnabarGymSuperNerd2AfterBattleText::
	text "I gave that"
	line "battle everything"
	cont "I had!"

	para "<PLAYER>: You"
	line "threw a ball and"
	cont "shouted. Twice."
	done

_CinnabarGymSuperNerd3BattleText::
	text "I skipped lunch"
	line "to train for"
	cont "this battle!"

	para "<PLAYER>: You"
	line "skipped LUNCH?"
	cont "Now I'm worried."
	done

_CinnabarGymSuperNerd3EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_CinnabarGymSuperNerd3AfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_CinnabarGymSuperNerd4BattleText::
	text "I came all this"
	line "way just to"
	cont "battle you!"

	para "<PLAYER>: Then"
	line "let's make it"
	cont "worth the trip!"
	done

_CinnabarGymSuperNerd4EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_CinnabarGymSuperNerd4AfterBattleText::
	text "Did you feel"
	line "the tension in"
	cont "that battle?"

	para "<PLAYER>: I felt"
	line "hungry. That's"
	cont "about it."
	done

_CinnabarGymSuperNerd5BattleText::
	text "My heart is"
	line "pounding! Battle"
	cont "me, <PLAYER>!"

	para "<PLAYER>: Now"
	line "we're talking!"
	cont "Don't hold back!"
	done

_CinnabarGymSuperNerd5EndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_CinnabarGymSuperNerd5AfterBattleText::
	text "Our battle was"
	line "so heated!"

	para "<PLAYER> looked"
	line "at his fists."
	cont "Still clean."
	done

_CinnabarGymSuperNerd6BattleText::
	text "Is it true you"
	line "beat a guy who"
	cont "blew up planets?"
	cont "Battle me!"

	para "<PLAYER>: Gladly!"
	line "You must be"
	cont "super strong!"
	done

_CinnabarGymSuperNerd6EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_CinnabarGymSuperNerd6AfterBattleText::
	text "I'll train hard"
	line "and battle you"
	cont "again!"

	para "<PLAYER>: Train"
	line "YOURSELF too! Do"
	cont "some sit-ups!"
	done

_CinnabarGymSuperNerd7BattleText::
	text "My sensei said"
	line "to battle the"
	cont "strongest guy!"

	para "<PLAYER>: Your"
	line "sensei sounds"
	cont "awesome!"
	done

_CinnabarGymSuperNerd7EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_CinnabarGymSuperNerd7AfterBattleText::
	text "That battle"
	line "was electric!"

	para "<PLAYER>'s"
	line "stomach growled."
	cont "Lunch time, then."
	done

_CinnabarGymGymGuideChampInMakingText::
	text "Yo! Champ in"
	line "making!"

	para "The hot-headed"
	line "BLAINE is a fire"
	cont "#MON pro!"

	para "Douse his spirits"
	line "with water!"

	para "You better take"
	line "some BURN HEALs!"
	done

_CinnabarGymGymGuideBeatBlaineText::
	text "<PLAYER>! You beat"
	line "that fire brand!"
	done
