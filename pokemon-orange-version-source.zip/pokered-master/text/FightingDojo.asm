_FightingDojoKarateMasterText::
	text "Grunt!"

	para "I am the KARATE"
	line "MASTER! I am the"
	cont "LEADER here!"

	para "You wish to"
	line "challenge us?"
	cont "Expect no mercy!"

	para "Fwaaa!"
	done

_FightingDojoKarateMasterDefeatedText::
	text "Hwa!"
	line "Arrgh! Beaten!"
	prompt

_FightingDojoKarateMasterIWillGiveYouAPokemonText::
	text "Indeed, I have"
	line "lost!"

	para "But, I beseech"
	line "you, do not take"
	cont "our emblem as"
	cont "your trophy!"

	para "In return, I will"
	line "give you a prized"
	cont "fighting #MON!"

	para "Choose whichever"
	line "one you like!"
	done

_FightingDojoKarateMasterStayAndTrainWithUsText::
	text "Ho!"

	para "Stay and train at"
	line "Karate with us!"
	done

_FightingDojoBlackbelt1BattleText::
	text "They say you can"
	line "fly and shoot"
	cont "energy blasts!"
	cont "Battle me!"

	para "<PLAYER>: Sure!"
	line "Ready when you"
	cont "are!"
	done

_FightingDojoBlackbelt1EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_FightingDojoBlackbelt1AfterBattleText::
	text "I'm exhausted"
	line "after that fight!"

	para "<PLAYER>: From"
	line "what? Yelling"
	cont "move names?"
	done

_FightingDojoBlackbelt2BattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done

_FightingDojoBlackbelt2EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_FightingDojoBlackbelt2AfterBattleText::
	text "Wanna battle"
	line "again?"

	para "<PLAYER>: Only"
	line "if I'm allowed to"
	cont "punch something."
	done

_FightingDojoBlackbelt3BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_FightingDojoBlackbelt3EndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_FightingDojoBlackbelt3AfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_FightingDojoBlackbelt4BattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_FightingDojoBlackbelt4EndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_FightingDojoBlackbelt4AfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done

_FightingDojoHitmonleePokeBallText::
	text "You want the"
	line "hard kicking"
	cont "HITMONLEE?"
	done

_FightingDojoHitmonchanPokeBallText::
	text "You want the"
	line "piston punching"
	cont "HITMONCHAN?"
	done

_FightingDojoBetterNotGetGreedyText::
	text "Better not get"
	line "greedy..."
	done
