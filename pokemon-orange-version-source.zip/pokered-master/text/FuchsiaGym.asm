_FuchsiaGymKogaBeforeBattleText::
	text "Fwahahaha! A"
	line "battle with the"
	cont "great <PLAYER>!"

	para "<PLAYER>: A"
	line "ninja! Ninjas"
	cont "fight for real,"
	cont "right?!"

	para "Of course! My"
	line "poison #MON"
	cont "fight for me!"

	para "<PLAYER>: So"
	line "close. So close."
	done

_FuchsiaGymKogaReceivedSoulBadgeText::
	text "Humph!"
	line "You have proven"
	cont "your worth!"

	para "Here! Take the"
	line "SOULBADGE!"
	prompt
