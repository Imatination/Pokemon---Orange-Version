_FuchsiaGymKogaPostBattleAdviceText::
	text "When afflicted by"
	line "TOXIC, #MON"
	cont "suffer more and"
	cont "more as battle"
	cont "progresses!"

	para "It will surely"
	line "terrorize foes!"
	done

_FuchsiaGymKogaSoulBadgeInfoText::
	text "Now that you have"
	line "the SOULBADGE,"
	cont "the DEFENSE of"
	cont "your #MON"
	cont "increases!"

	para "It also lets you"
	line "SURF outside of"
	cont "battle!"

	para "Ah! Take this"
	line "too!"
	done

_FuchsiaGymKogaReceivedTM06Text::
	text "<PLAYER> received"
	line "@"
	text_ram wStringBuffer
	text "!@"
	text_end

_FuchsiaGymKogaTM06ExplanationText::
	text_start

	para "TM06 contains"
	line "TOXIC!"

	para "It is a secret"
	line "technique over"
	cont "400 years old!"
	done

_FuchsiaGymKogaTM06NoRoomText::
	text "Make space for"
	line "this, child!"
	done

_FuchsiaGymRocker1BattleText::
	text "Prepare yourself!"
	line "This battle will"
	cont "be legendary!"

	para "<PLAYER>'s hair"
	line "flickered gold"
	cont "for a second."
	done

_FuchsiaGymRocker1EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_FuchsiaGymRocker1AfterBattleText::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done

_FuchsiaGymRocker2BattleText::
	text "Stop right there!"
	line "You and me..."
	cont "BATTLE!"

	para "<PLAYER>: Yes!"
	line "Finally someone"
	cont "who gets it!"
	done

_FuchsiaGymRocker2EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_FuchsiaGymRocker2AfterBattleText::
	text "I'm still"
	line "catching my"
	cont "breath!"

	para "<PLAYER>: You sat"
	line "on a rock the"
	cont "whole time!"
	done

_FuchsiaGymRocker3BattleText::
	text "Eek! It's you!"
	line "I'm so excited!"
	cont "Let's battle!"

	para "<PLAYER> started"
	line "to glow a little."
	done

_FuchsiaGymRocker3EndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_FuchsiaGymRocker3AfterBattleText::
	text "Best battle of"
	line "my life!"

	para "<PLAYER>: But"
	line "you just stood"
	cont "there pointing!"
	done

_FuchsiaGymRocker4BattleText::
	text "I've trained my"
	line "whole life to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Hit me with your"
	cont "best shot!"
	done

_FuchsiaGymRocker4EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_FuchsiaGymRocker4AfterBattleText::
	text "Phew! That"
	line "battle was rough!"

	para "<PLAYER> did a"
	line "hundred push-ups"
	cont "out of boredom."
	done

_FuchsiaGymRocker5BattleText::
	text "Let's settle"
	line "this with a"
	cont "battle, champ!"

	para "<PLAYER> flexed."
	line "Bring it on!"
	done

_FuchsiaGymRocker5EndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_FuchsiaGymRocker5AfterBattleText::
	text "Some advice: use"
	line "type matchups!"

	para "<PLAYER>: What"
	line "about fist"
	cont "matchups?"
	done

_FuchsiaGymRocker6BattleText::
	text "I warmed up for"
	line "three whole hours"
	cont "for this battle!"

	para "<PLAYER>: Only"
	line "three? Well, it's"
	cont "a start!"
	done

_FuchsiaGymRocker6EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_FuchsiaGymRocker6AfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_FuchsiaGymGymGuideChampInMakingText::
	text "Yo! Champ in"
	line "making!"

	para "FUCHSIA GYM is"
	line "riddled with"
	cont "invisible walls!"

	para "KOGA might appear"
	line "close, but he's"
	cont "blocked off!"

	para "You have to find"
	line "gaps in the walls"
	cont "to reach him!"
	done

_FuchsiaGymGymGuideBeatKogaText::
	text "It's amazing how"
	line "ninja can terrify"
	cont "even now!"
	done
