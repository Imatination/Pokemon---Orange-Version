_LancesRoomLanceBeforeBattleText::
	text "Ah! I heard"
	line "about you,"
	cont "<PLAYER>!"

	para "I lead the ELITE"
	line "FOUR! I am LANCE,"
	cont "dragon master!"

	para "<PLAYER>: Dragons!"
	line "I know dragons!"
	cont "Can I wish for a"
	cont "real fight?"

	para "My dragons will"
	line "battle you!"

	para "<PLAYER>: Not"
	line "the wish I"
	cont "wanted..."
	done

_LancesRoomLanceEndBattleText::
	text "Ugh!"
	line "That's it! What"
	cont "a battle!"
	prompt

_LancesRoomLanceAfterBattleText::
	text "I still can't"
	line "believe my"
	cont "dragons lost to"
	cont "you, <PLAYER>!"

	para "You are now the"
	line "#MON LEAGUE"
	cont "champion!"

	para "...Or, you would"
	line "have been, but"
	cont "you have one more"
	cont "challenge ahead."

	para "You have to face"
	line "another trainer!"
	cont "His name is..."

	para "<RIVAL>!"
	line "He beat the ELITE"
	cont "FOUR before you!"

	para "He is the real"
	line "#MON LEAGUE"
	cont "champion!@"
	text_end
