_LoreleisRoomLoreleiBeforeBattleText::
	text "Welcome to the"
	line "#MON LEAGUE!"
	cont "I'm LORELEI!"

	para "Battling you is"
	line "my dream come"
	cont "true, <PLAYER>!"

	para "<PLAYER>: Ice!"
	line "Cool! Do you do"
	cont "ice punches?"

	para "My ice #MON"
	line "will do that."

	para "<PLAYER>: Of"
	line "course they will."
	done

_LoreleisRoomLoreleiEndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_LoreleisRoomLoreleiAfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done

_LoreleisRoomLoreleiDontRunAwayText::
	text "Someone's voice:"
	line "Don't run away!"
	done
