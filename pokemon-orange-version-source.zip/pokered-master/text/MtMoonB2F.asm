_MtMoonB2FDomeFossilYouWantText::
	text "You want the"
	line "DOME FOSSIL?"
	done

_MtMoonB2FHelixFossilYouWantText::
	text "You want the"
	line "HELIX FOSSIL?"
	done

_MtMoonB2FReceivedFossilText::
	text "<PLAYER> got the"
	line "@"
	text_ram wStringBuffer
	text "!@"
	text_end

_MtMoonB2FYouHaveNoRoomText::
	text "Look, you've got"
	line "no room for this.@"
	text_end

_MtMoonB2FSuperNerdTheyreBothMineText::
	text "Hey, stop!"

	para "I found these"
	line "fossils! They're"
	cont "both mine!"
	done

_MtMoonB2FSuperNerdOkIllShareText::
	text "OK!"
	line "I'll share!"
	prompt

_MtMoonB2fSuperNerdEachTakeOneText::
	text "We'll each take"
	line "one!"
	cont "No being greedy!"
	done

_MtMoonB2FSuperNerdTheresAPokemonLabText::
	text "Far away, on"
	line "CINNABAR ISLAND,"
	cont "there's a #MON"
	cont "LAB."

	para "They do research"
	line "on regenerating"
	cont "fossils."
	done

_MtMoonB2FSuperNerdThenThisIsMineText::
	text "All right. Then"
	line "this is mine!@"
	text_end

_MtMoonB2FRocket1BattleText::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done

_MtMoonB2FRocket1EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_MtMoonB2FRocket1AfterBattleText::
	text "You're a battle"
	line "genius, <PLAYER>!"

	para "<PLAYER>: I"
	line "didn't battle!"
	cont "Your #MON did!"
	done

_MtMoonB2FRocket2BattleText::
	text "My #MON and I"
	line "are fired up!"
	cont "Battle time!"

	para "<PLAYER>: Your"
	line "#MON? Wait..."
	cont "who do I punch?"
	done

_MtMoonB2FRocket2EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_MtMoonB2FRocket2AfterBattleText::
	text "My #MON did"
	line "their best!"

	para "<PLAYER>: Great!"
	line "Now YOU do your"
	cont "best. Hands up!"

	para "...Huh? Battle's"
	line "over? Again?"
	done

_MtMoonB2FRocket3BattleText::
	text "Feel this aura?"
	line "It's my fighting"
	cont "spirit!"

	para "<PLAYER>: It's"
	line "tiny, but I like"
	cont "your attitude!"
	done

_MtMoonB2FRocket3EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_MtMoonB2FRocket3AfterBattleText::
	text "Battle me again"
	line "after I train!"

	para "<PLAYER>: Try"
	line "gravity training!"
	cont "100x is fun!"
	done

_MtMoonB2FRocket4BattleText::
	text "Everyone says"
	line "you're the best"
	cont "fighter around!"

	para "<PLAYER> started"
	line "powering up."
	cont "Let's do this!"
	done

_MtMoonB2FRocket4EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_MtMoonB2FRocket4AfterBattleText::
	text "I gave that"
	line "battle everything"
	cont "I had!"

	para "<PLAYER>: You"
	line "threw a ball and"
	cont "shouted. Twice."
	done
