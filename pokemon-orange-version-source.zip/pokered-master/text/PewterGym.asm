_PewterGymBrockPreBattleText::
	text "I'm BROCK! I'm"
	line "PEWTER's GYM"
	cont "LEADER!"

	para "I've been waiting"
	line "to battle the"
	cont "famous <PLAYER>!"

	para "<PLAYER>: Rock"
	line "hard defense?"
	cont "Let me test it!"

	para "...With my"
	line "#MON, I mean."
	cont "Rock-types!"

	para "<PLAYER>: Oh."
	line "...Okay. Sure."
	done
