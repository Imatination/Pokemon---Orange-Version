_PewterGymBrockPostBattleAdviceText::
	text "There are all"
	line "kinds of trainers"
	cont "in the world!"

	para "You appear to be"
	line "very gifted as a"
	cont "#MON trainer!"

	para "Go to the GYM in"
	line "CERULEAN and test"
	cont "your abilities!"
	done

_PewterGymBrockWaitTakeThisText::
	text "Wait! Take this"
	line "with you!"
	done

_PewterGymReceivedTM34Text::
	text "<PLAYER> received"
	line "TM34!@"
	text_end

_TM34ExplanationText::
	text_start

	para "A TM contains a"
	line "technique that"
	cont "can be taught to"
	cont "#MON!"

	para "A TM is good only"
	line "once! So when you"
	cont "use one to teach"
	cont "a new technique,"
	cont "pick the #MON"
	cont "carefully!"

	para "TM34 contains"
	line "BIDE!"

	para "Your #MON will"
	line "absorb damage in"
	cont "battle then pay"
	cont "it back double!"
	done

_PewterGymTM34NoRoomText::
	text "You don't have"
	line "room for this!"
	done

_PewterGymBrockReceivedBoulderBadgeText::
	text "I took"
	line "you for granted."

	para "As proof of your"
	line "victory, here's"
	cont "the BOULDER-"
	prompt

_PewterGymFriezaArrivesText::
	text "???: Ho ho ho!"
	line "What a touching"
	cont "little ceremony."
	done

_PewterGymFriezaDemandsText::
	text "FRIEZA: I'll be"
	line "taking that"
	cont "BADGE, thank you!"

	para "BROCK: Who are"
	line "you!?"

	para "Listen. I don't"
	line "want any trouble."

	para "You guys are"
	line "super jacked,"
	cont "I'm just a-"
	done

_PewterGymFriezaStoleBadgeText::
	text "FRIEZA blasted"
	line "BROCK with a"
	cont "DEATH BEAM!"

	para "FRIEZA stole the"
	line "BOULDERBADGE!"
	done

_PewterGymGokuShockedText::
	text "<PLAYER>: BROCK!"
	line "No... NO!"

	para "BROCK isn't"
	line "moving..."
	prompt

_PewterGymGokuSwearsText::
	text "<PLAYER>: FRIEZA!"
	line "You'll pay for"
	cont "this!"

	para "I'll avenge"
	line "BROCK!"

	para "FRIEZA: Ho ho!"
	line "The monkey wants"
	cont "to play?"

	para "Very well! Come"
	line "and die!"
	prompt

_PewterGymFriezaStoleStarterText::
	text "FRIEZA: Oh, and"
	line "I helped myself"
	cont "to the last"
	cont "#MON in OAK's"
	cont "lab!"

	para "Go, @"
	text_ram wNameBuffer
	text "!"
	prompt

_PewterGymStarterFreedText::
	text "FRIEZA dropped"
	line "a # BALL! It's"
	cont "OAK's @"
	text_ram wNameBuffer
	text "!"
	prompt

_PewterGymBrockKnockedOutText::
	text "BROCK is out"
	line "cold..."
	done

_PewterGymFriezaRematchText::
	text "FRIEZA: Ho ho ho!"
	line "Back for more,"
	cont "monkey?"
	prompt

_PewterGymFriezaDefeatedText::
	text "No..."
	line "Not by a mere"
	cont "monkey..."
	prompt

_PewterGymFriezaVictoryText::
	text "Ho ho"
	line "ho! Pathetic!"
	prompt

_PewterGymGokuGivesSenzuText::
	text "<PLAYER>: Hang on,"
	line "BROCK!"

	para "<PLAYER> gave the"
	line "MYSTERY BEAN to"
	cont "BROCK!"

	para "It was a SENZU"
	line "BEAN! BROCK's"
	cont "wounds vanished!"
	done

_PewterGymBrockRevivedText::
	text "BROCK: Ugh..."
	line "I'm alive?!"

	para "Thank you,"
	line "<PLAYER>!"

	para "That bean healed"
	line "me in an instant!"

	para "I've got to grow"
	line "more of these!"

	para "I'll start a"
	line "SENZU BEAN farm!"

	para "Look for them in"
	line "every #MART!"
	done

_PewterGymBrockBadgeText::
	text "BROCK: And this"
	line "belongs to you."

	para "<PLAYER> received"
	line "the BOULDERBADGE!@"
	text_end

_PewterGymBrockBadgeInfoText::
	text_start

	para "That's an official"
	line "#MON LEAGUE"
	cont "BADGE!"

	para "Its bearer's"
	line "#MON become"
	cont "more powerful!"

	para "The technique"
	line "FLASH can now be"
	cont "used any time!"
	done

_PewterGymBrockBoulderBadgeInfoText::
	text_start

	para "That's an official"
	line "#MON LEAGUE"
	cont "BADGE!"

	para "Its bearer's"
	line "#MON become"
	cont "more powerful!"

	para "The technique"
	line "FLASH can now be"
	cont "used any time!"
	prompt

_PewterGymCooltrainerMBattleText::
	text "Our eyes met!"
	line "That means we"
	cont "have to battle!"

	para "<PLAYER>: I"
	line "LOVE that rule!"
	done

_PewterGymCooltrainerMEndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_PewterGymCooltrainerMAfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_PewterGymGuidePreAdviceText::
	text "Hiya! I can tell"
	line "you have what it"
	cont "takes to become a"
	cont "#MON champ!"

	para "I'm no trainer,"
	line "but I can tell"
	cont "you how to win!"

	para "Let me take you"
	line "to the top!"
	done

_PewterGymGuideBeginAdviceText::
	text "All right! Let's"
	line "get happening!"
	prompt

_PewterGymGuideAdviceText::
	text "The 1st #MON"
	line "out in a match is"
	cont "at the top of the"
	cont "#MON LIST!"

	para "By changing the"
	line "order of #MON,"
	cont "matches could be"
	cont "made easier!"
	done

_PewterGymGuideFreeServiceText::
	text "It's a free"
	line "service! Let's"
	cont "get happening!"
	prompt

_PewterGymGuidePostBattleText::
	text "I've got moves"
	line "you've never"
	cont "even seen!"

	para "<PLAYER>: Show"
	line "me! Show me!"
	done
