_PokemonMansion1FScientistBattleText::
	text "I skipped lunch"
	line "to train for"
	cont "this battle!"

	para "<PLAYER>: You"
	line "skipped LUNCH?"
	cont "Now I'm worried."
	done

_PokemonMansion1FScientistEndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_PokemonMansion1FScientistAfterBattleText::
	text "Did you feel"
	line "the tension in"
	cont "that battle?"

	para "<PLAYER>: I felt"
	line "hungry. That's"
	cont "about it."
	done

_PokemonMansion1FSwitchText::
	text "A secret switch!"

	para "Press it?"
	done

_PokemonMansion1FSwitchPressedText::
	text "Who wouldn't?"
	prompt

_PokemonMansion1FSwitchNotPressedText::
	text "Not quite yet!"
	done
