_PokemonMansion2FSuperNerdBattleText::
	text "I came all this"
	line "way just to"
	cont "battle you!"

	para "<PLAYER>: Then"
	line "let's make it"
	cont "worth the trip!"
	done

_PokemonMansion2FSuperNerdEndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_PokemonMansion2FSuperNerdAfterBattleText::
	text "Our battle was"
	line "so heated!"

	para "<PLAYER> looked"
	line "at his fists."
	cont "Still clean."
	done

_PokemonMansion2FDiary1Text::
	text "Diary: July 5"
	line "Guyana,"
	cont "South America"

	para "A new #MON was"
	line "discovered deep"
	cont "in the jungle."
	done

_PokemonMansion2FDiary2Text::
	text "Diary: July 10"
	line "We christened the"
	cont "newly discovered"
	cont "#MON, MEW."
	done

_PokemonMansion2FSwitchText::
	text "A secret switch!"

	para "Press it?"
	done

_PokemonMansion2FSwitchPressedText::
	text "Who wouldn't?"
	prompt

_PokemonMansion2FSwitchNotPressedText::
	text "Not quite yet!"
	done
