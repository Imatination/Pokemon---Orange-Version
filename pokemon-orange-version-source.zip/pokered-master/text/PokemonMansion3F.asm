_PokemonMansion3FSuperNerdBattleText::
	text "My heart is"
	line "pounding! Battle"
	cont "me, <PLAYER>!"

	para "<PLAYER>: Now"
	line "we're talking!"
	cont "Don't hold back!"
	done

_PokemonMansion3FSuperNerdEndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_PokemonMansion3FSuperNerdAfterBattleText::
	text "I'll train hard"
	line "and battle you"
	cont "again!"

	para "<PLAYER>: Train"
	line "YOURSELF too! Do"
	cont "some sit-ups!"
	done

_PokemonMansion3FScientistBattleText::
	text "Is it true you"
	line "beat a guy who"
	cont "blew up planets?"
	cont "Battle me!"

	para "<PLAYER>: Gladly!"
	line "You must be"
	cont "super strong!"
	done

_PokemonMansion3FScientistEndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_PokemonMansion3FScientistAfterBattleText::
	text "That battle"
	line "was electric!"

	para "<PLAYER>'s"
	line "stomach growled."
	cont "Lunch time, then."
	done

_PokemonMansion3FDiaryText::
	text "Diary: Feb. 6"
	line "MEW gave birth."

	para "We named the"
	line "newborn MEWTWO."
	done
