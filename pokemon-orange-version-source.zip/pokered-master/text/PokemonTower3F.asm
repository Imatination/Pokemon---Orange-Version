_PokemonTower3FChanneler1BattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done

_PokemonTower3FChanneler1EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_PokemonTower3FChanneler1AfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_PokemonTower3FChanneler2BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_PokemonTower3FChanneler2EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_PokemonTower3FChanneler2AfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done

_PokemonTower3FChanneler3BattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_PokemonTower3FChanneler3EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_PokemonTower3FChanneler3AfterBattleText::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done
