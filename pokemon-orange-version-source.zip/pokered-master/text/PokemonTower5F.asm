_PokemonTower5FChanneler1Text::
	text "Come, child! I"
	line "sealed this space"
	cont "with white magic!"

	para "You can rest here!"
	done

_PokemonTower5FChanneler2BattleText::
	text "I've trained my"
	line "whole life to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Hit me with your"
	cont "best shot!"
	done

_PokemonTower5FChanneler2EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_PokemonTower5FChanneler2AfterBattleText::
	text "Some advice: use"
	line "type matchups!"

	para "<PLAYER>: What"
	line "about fist"
	cont "matchups?"
	done

_PokemonTower5FChanneler3BattleText::
	text "Let's settle"
	line "this with a"
	cont "battle, champ!"

	para "<PLAYER> flexed."
	line "Bring it on!"
	done

_PokemonTower5FChanneler3EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_PokemonTower5FChanneler3AfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_PokemonTower5FChanneler4BattleText::
	text "I warmed up for"
	line "three whole hours"
	cont "for this battle!"

	para "<PLAYER>: Only"
	line "three? Well, it's"
	cont "a start!"
	done

_PokemonTower5FChanneler4EndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_PokemonTower5FChanneler4AfterBattleText::
	text "Nobody battles"
	line "like you do!"

	para "<PLAYER> mumbled"
	line "something about"
	cont "Kamehamehas."
	done

_PokemonTower5FChanneler5BattleText::
	text "I'm gonna battle"
	line "you so hard!"

	para "<PLAYER> tied his"
	line "belt tighter."
	cont "Let's go!"
	done

_PokemonTower5FChanneler5EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_PokemonTower5FChanneler5AfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done

_PokemonTower5FPurifiedZoneText::
	text "Entered purified,"
	line "protected zone!"

	para "<PLAYER>'s #MON"
	line "are fully healed!"
	done
