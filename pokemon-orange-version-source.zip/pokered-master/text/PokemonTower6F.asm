_PokemonTower6FGhostWasCubonesMotherText::
	text "The GHOST was the"
	line "restless soul of"
	cont "CUBONE's mother!"
	done

_PokemonTower6FSoulWasCalmedText::
	text "The mother's soul"
	line "was calmed."

	para "It departed to"
	line "the afterlife!"
	done

_PokemonTower6FChanneler1BattleText::
	text "Don't go easy on"
	line "me! I want your"
	cont "strongest battle!"

	para "<PLAYER>: My"
	line "strongest? You"
	cont "sure about that?"
	done

_PokemonTower6FChanneler1EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_PokemonTower6FChanneler1AfterBattleText::
	text "Whoa, I'm sore"
	line "from that battle!"

	para "<PLAYER>: How?!"
	line "You didn't move!"
	done

_PokemonTower6FChanneler2BattleText::
	text "Whoa! Are you"
	line "<PLAYER>? Let's"
	cont "battle right now!"

	para "<PLAYER> grinned"
	line "and cracked his"
	cont "knuckles. Yes!"
	done

_PokemonTower6FChanneler2EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_PokemonTower6FChanneler2AfterBattleText::
	text "My hands are"
	line "still shaking!"

	para "<PLAYER>: Then"
	line "let's spar!"
	cont "Hey! Come back!"
	done

_PokemonTower6FChanneler3BattleText::
	text "I've been"
	line "stretching all"
	cont "morning for you!"

	para "<PLAYER>: Ooh!"
	line "A real warrior!"
	cont "Come on!"
	done

_PokemonTower6FChanneler3EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_PokemonTower6FChanneler3AfterBattleText::
	text "Everyone talks"
	line "about how strong"
	cont "you are!"

	para "<PLAYER>: Then"
	line "why won't anyone"
	cont "fight me?!"
	done

_PokemonTower6FBeGoneText::
	text "Be gone..."
	line "Intruders..."
	done
