_PokemonTower7FMrFujiRescueText::
	text "MR.FUJI: Heh? You"
	line "came to save me?"

	para "Thank you. But, I"
	line "came here of my"
	cont "own free will."

	para "I came to calm"
	line "the soul of"
	cont "CUBONE's mother."

	para "I think MAROWAK's"
	line "spirit has gone"
	cont "to the afterlife."

	para "I must thank you"
	line "for your kind"
	cont "concern!"

	para "Follow me to my"
	line "home, #MON"
	cont "HOUSE at the foot"
	cont "of this tower."
	done

_PokemonTower7FRocket1BattleText::
	text "You! Me! Battle!"
	line "No running away!"

	para "<PLAYER>: Run?"
	line "I never run from"
	cont "a good fight!"
	done

_PokemonTower7FRocket1EndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_PokemonTower7FRocket1AfterBattleText::
	text "I'll never forget"
	line "our epic clash!"

	para "<PLAYER>: What"
	line "clash? Our hands"
	cont "never touched!"
	done

_PokemonTower7FRocket2BattleText::
	text "You look tough!"
	line "Our battle will"
	cont "be epic!"

	para "<PLAYER>: I've"
	line "been waiting all"
	cont "day for this!"
	done

_PokemonTower7FRocket2EndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_PokemonTower7FRocket2AfterBattleText::
	text "Let's battle"
	line "again tomorrow!"

	para "<PLAYER>: Can we"
	line "spar instead?"
	cont "...No? Okay."
	done

_PokemonTower7FRocket3BattleText::
	text "I heard about"
	line "your power level!"
	cont "Battle me!"

	para "<PLAYER>: Wow,"
	line "you know about"
	cont "power levels?"
	done

_PokemonTower7FRocket3EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_PokemonTower7FRocket3AfterBattleText::
	text "I can't believe"
	line "I battled THE"
	cont "<PLAYER>!"

	para "<PLAYER>: You"
	line "still haven't."
	cont "Not really."
	done
