_RedsHouse1FMomWakeUpText::
	text "CHI-CHI: <PLAYER>!"
	line "Stop messing"
	cont "around!"

	para "Go out there and"
	line "make some money!"
	cont "You have a family"
	cont "to support!"

	para "PROF.OAK, next"
	line "door, is looking"
	cont "for you. GO!"
	done

_RedsHouse1FMomYouShouldRestText::
	text "CHI-CHI: <PLAYER>!"
	line "You should take a"
	cont "quick rest."
	prompt

_RedsHouse1FMomLookingGreatText::
	text "CHI-CHI: Good!"
	line "You and your"
	cont "#MON are"
	cont "looking great!"
	cont "Take care now!"
	done

_RedsHouse1FTVStandByMeMovieText::
	text "There's a movie"
	line "on TV. Four boys"
	cont "are walking on"
	cont "railroad tracks."

	para "I better go too."
	done

_RedsHouse1FTVWrongSideText::
	text "Oops, wrong side."
	done

_RedsHouse1FBulmaText::
	text "BULMA: Hi, GOKU!"

	para "I turned VEGETA's"
	line "house into a"
	cont "GRAVITY TRAINING"
	cont "ROOM!"

	para "So I'm staying"
	line "here with CHI-CHI"
	cont "for a while."
	done
