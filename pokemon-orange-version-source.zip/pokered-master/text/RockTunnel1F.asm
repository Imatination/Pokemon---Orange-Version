_RockTunnel1FHiker1BattleText::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done

_RockTunnel1FHiker1EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_RockTunnel1FHiker1AfterBattleText::
	text "You battle like"
	line "a true master!"

	para "<PLAYER>: I"
	line "didn't even get"
	cont "to warm up!"
	done

_RockTunnel1FHiker2BattleText::
	text "My #MON and I"
	line "are fired up!"
	cont "Battle time!"

	para "<PLAYER>: Your"
	line "#MON? Wait..."
	cont "who do I punch?"
	done

_RockTunnel1FHiker2EndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_RockTunnel1FHiker2AfterBattleText::
	text "You're a battle"
	line "genius, <PLAYER>!"

	para "<PLAYER>: I"
	line "didn't battle!"
	cont "Your #MON did!"
	done

_RockTunnel1FHiker3BattleText::
	text "Feel this aura?"
	line "It's my fighting"
	cont "spirit!"

	para "<PLAYER>: It's"
	line "tiny, but I like"
	cont "your attitude!"
	done

_RockTunnel1FHiker3EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_RockTunnel1FHiker3AfterBattleText::
	text "My #MON did"
	line "their best!"

	para "<PLAYER>: Great!"
	line "Now YOU do your"
	cont "best. Hands up!"

	para "...Huh? Battle's"
	line "over? Again?"
	done

_RockTunnel1FSuperNerdBattleText::
	text "Everyone says"
	line "you're the best"
	cont "fighter around!"

	para "<PLAYER> started"
	line "powering up."
	cont "Let's do this!"
	done

_RockTunnel1FSuperNerdEndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_RockTunnel1FSuperNerdAfterBattleText::
	text "Battle me again"
	line "after I train!"

	para "<PLAYER>: Try"
	line "gravity training!"
	cont "100x is fun!"
	done

_RockTunnel1FCooltrainerF1BattleText::
	text "Our eyes met!"
	line "That means we"
	cont "have to battle!"

	para "<PLAYER>: I"
	line "LOVE that rule!"
	done

_RockTunnel1FCooltrainerF1EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_RockTunnel1FCooltrainerF1AfterBattleText::
	text "I gave that"
	line "battle everything"
	cont "I had!"

	para "<PLAYER>: You"
	line "threw a ball and"
	cont "shouted. Twice."
	done

_RockTunnel1FCooltrainerF2BattleText::
	text "I've got moves"
	line "you've never"
	cont "even seen!"

	para "<PLAYER>: Show"
	line "me! Show me!"
	done

_RockTunnel1FCooltrainerF2EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_RockTunnel1FCooltrainerF2AfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_RockTunnel1FCooltrainerF3BattleText::
	text "I skipped lunch"
	line "to train for"
	cont "this battle!"

	para "<PLAYER>: You"
	line "skipped LUNCH?"
	cont "Now I'm worried."
	done

_RockTunnel1FCooltrainerF3EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_RockTunnel1FCooltrainerF3AfterBattleText::
	text "Did you feel"
	line "the tension in"
	cont "that battle?"

	para "<PLAYER>: I felt"
	line "hungry. That's"
	cont "about it."
	done

_RockTunnel1FSignText::
	text "ROCK TUNNEL"
	line "CERULEAN CITY -"
	cont "LAVENDER TOWN"
	done
