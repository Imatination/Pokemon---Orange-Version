_RockTunnelB1FHiker3AfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done

_RockTunnelB1FSuperNerd3BattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_RockTunnelB1FSuperNerd3EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_RockTunnelB1FSuperNerd3AfterBattleText::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done
