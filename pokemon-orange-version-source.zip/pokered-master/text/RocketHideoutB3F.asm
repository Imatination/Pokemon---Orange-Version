_RocketHideoutB3FRocket1BattleText::
	text "I'm gonna battle"
	line "you so hard!"

	para "<PLAYER> tied his"
	line "belt tighter."
	cont "Let's go!"
	done

_RocketHideoutB3FRocket1EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_RocketHideoutB3FRocket1AfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done

_RocketHideout3BattleText::
	text "Don't go easy on"
	line "me! I want your"
	cont "strongest battle!"

	para "<PLAYER>: My"
	line "strongest? You"
	cont "sure about that?"
	done

_RocketHideout3EndBattleText3::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_RocketHide3AfterBattleText3::
	text "Whoa, I'm sore"
	line "from that battle!"

	para "<PLAYER>: How?!"
	line "You didn't move!"
	done
