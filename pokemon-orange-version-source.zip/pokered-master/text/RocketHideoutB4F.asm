_RocketHideoutB4FGiovanniImpressedYouGotHereText::
	text "So! I must say, I"
	line "am impressed you"
	cont "got here!"
	done

_RocketHideoutB4FGiovanniWhatCannotBeText::
	text "WHAT!"
	line "This cannot be!"
	prompt

_RocketHideoutB4FGiovanniHopeWeMeetAgainText::
	text "I see that you"
	line "raise #MON"
	cont "with utmost care."

	para "A child like you"
	line "would never"
	cont "understand what I"
	cont "hope to achieve."

	para "I shall step"
	line "aside this time!"

	para "I hope we meet"
	line "again..."
	done

_RocketHideoutB4FRocket1BattleText::
	text "Whoa! Are you"
	line "<PLAYER>? Let's"
	cont "battle right now!"

	para "<PLAYER> grinned"
	line "and cracked his"
	cont "knuckles. Yes!"
	done

_RocketHideoutB4FRocket1EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_RocketHideoutB4FRocket1AfterBattleText::
	text "My hands are"
	line "still shaking!"

	para "<PLAYER>: Then"
	line "let's spar!"
	cont "Hey! Come back!"
	done

_RocketHideoutB4FRocket2BattleText::
	text "I've been"
	line "stretching all"
	cont "morning for you!"

	para "<PLAYER>: Ooh!"
	line "A real warrior!"
	cont "Come on!"
	done

_RocketHideoutB4FRocket2EndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_RocketHideoutB4FRocket2AfterBattleText::
	text "Everyone talks"
	line "about how strong"
	cont "you are!"

	para "<PLAYER>: Then"
	line "why won't anyone"
	cont "fight me?!"
	done

_RocketHideoutB4FRocket3BattleText::
	text "You! Me! Battle!"
	line "No running away!"

	para "<PLAYER>: Run?"
	line "I never run from"
	cont "a good fight!"
	done

_RocketHideoutB4FRocket3EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_RocketHideoutB4FRocket3AfterBattleText::
	text "I'll never forget"
	line "our epic clash!"

	para "<PLAYER>: What"
	line "clash? Our hands"
	cont "never touched!"
	done
