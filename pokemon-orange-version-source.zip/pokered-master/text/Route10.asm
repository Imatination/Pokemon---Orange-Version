_Route10SuperNerd1BattleText::
	text "You look tough!"
	line "Our battle will"
	cont "be epic!"

	para "<PLAYER>: I've"
	line "been waiting all"
	cont "day for this!"
	done

_Route10SuperNerd1EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_Route10SuperNerd1AfterBattleText::
	text "Let's battle"
	line "again tomorrow!"

	para "<PLAYER>: Can we"
	line "spar instead?"
	cont "...No? Okay."
	done

_Route10Hiker1BattleText::
	text "I heard about"
	line "your power level!"
	cont "Battle me!"

	para "<PLAYER>: Wow,"
	line "you know about"
	cont "power levels?"
	done

_Route10Hiker1EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_Route10Hiker1AfterBattleText::
	text "I can't believe"
	line "I battled THE"
	cont "<PLAYER>!"

	para "<PLAYER>: You"
	line "still haven't."
	cont "Not really."
	done

_Route10SuperNerd2BattleText::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done

_Route10SuperNerd2EndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_Route10SuperNerd2AfterBattleText::
	text "You battle like"
	line "a true master!"

	para "<PLAYER>: I"
	line "didn't even get"
	cont "to warm up!"
	done

_Route10CooltrainerF1BattleText::
	text "My #MON and I"
	line "are fired up!"
	cont "Battle time!"

	para "<PLAYER>: Your"
	line "#MON? Wait..."
	cont "who do I punch?"
	done

_Route10CooltrainerF1EndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_Route10CooltrainerF1AfterBattleText::
	text "You're a battle"
	line "genius, <PLAYER>!"

	para "<PLAYER>: I"
	line "didn't battle!"
	cont "Your #MON did!"
	done

_Route10Hiker2BattleText::
	text "Feel this aura?"
	line "It's my fighting"
	cont "spirit!"

	para "<PLAYER>: It's"
	line "tiny, but I like"
	cont "your attitude!"
	done

_Route10Hiker2EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_Route10Hiker2AfterBattleText::
	text "My #MON did"
	line "their best!"

	para "<PLAYER>: Great!"
	line "Now YOU do your"
	cont "best. Hands up!"

	para "...Huh? Battle's"
	line "over? Again?"
	done

_Route10CooltrainerF2BattleText::
	text "Everyone says"
	line "you're the best"
	cont "fighter around!"

	para "<PLAYER> started"
	line "powering up."
	cont "Let's do this!"
	done

_Route10CooltrainerF2EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_Route10CooltrainerF2AfterBattleText::
	text "Battle me again"
	line "after I train!"

	para "<PLAYER>: Try"
	line "gravity training!"
	cont "100x is fun!"
	done

_Route10RockTunnelSignText::
	text "ROCK TUNNEL"
	done

_Route10PowerPlantSignText::
	text "POWER PLANT"
	done
