_Route11Gambler1BattleText::
	text "Our eyes met!"
	line "That means we"
	cont "have to battle!"

	para "<PLAYER>: I"
	line "LOVE that rule!"
	done

_Route11Gambler1EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_Route11Gambler1AfterBattleText::
	text "I gave that"
	line "battle everything"
	cont "I had!"

	para "<PLAYER>: You"
	line "threw a ball and"
	cont "shouted. Twice."
	done

_Route11Gambler2BattleText::
	text "I've got moves"
	line "you've never"
	cont "even seen!"

	para "<PLAYER>: Show"
	line "me! Show me!"
	done

_Route11Gambler2EndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_Route11Gambler2AfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_Route11Youngster1BattleText::
	text "I skipped lunch"
	line "to train for"
	cont "this battle!"

	para "<PLAYER>: You"
	line "skipped LUNCH?"
	cont "Now I'm worried."
	done

_Route11Youngster1EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_Route11Youngster1AfterBattleText::
	text "Did you feel"
	line "the tension in"
	cont "that battle?"

	para "<PLAYER>: I felt"
	line "hungry. That's"
	cont "about it."
	done

_Route11SuperNerd1BattleText::
	text "I came all this"
	line "way just to"
	cont "battle you!"

	para "<PLAYER>: Then"
	line "let's make it"
	cont "worth the trip!"
	done

_Route11SuperNerd1EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_Route11SuperNerd1AfterBattleText::
	text "Our battle was"
	line "so heated!"

	para "<PLAYER> looked"
	line "at his fists."
	cont "Still clean."
	done

_Route11Youngster2BattleText::
	text "My heart is"
	line "pounding! Battle"
	cont "me, <PLAYER>!"

	para "<PLAYER>: Now"
	line "we're talking!"
	cont "Don't hold back!"
	done

_Route11Youngster2EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_Route11Youngster2AfterBattleText5::
	text "I'll train hard"
	line "and battle you"
	cont "again!"

	para "<PLAYER>: Train"
	line "YOURSELF too! Do"
	cont "some sit-ups!"
	done

_Route11Gambler3BattleText::
	text "Is it true you"
	line "beat a guy who"
	cont "blew up planets?"
	cont "Battle me!"

	para "<PLAYER>: Gladly!"
	line "You must be"
	cont "super strong!"
	done

_Route11Gambler3EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_Route11Gambler3AfterBattleText::
	text "That battle"
	line "was electric!"

	para "<PLAYER>'s"
	line "stomach growled."
	cont "Lunch time, then."
	done

_Route11Gambler4BattleText::
	text "My sensei said"
	line "to battle the"
	cont "strongest guy!"

	para "<PLAYER>: Your"
	line "sensei sounds"
	cont "awesome!"
	done

_Route11Gambler4EndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_Route11Gambler4AfterBattleText::
	text "I'm exhausted"
	line "after that fight!"

	para "<PLAYER>: From"
	line "what? Yelling"
	cont "move names?"
	done

_Route11Youngster3BattleText::
	text "They say you can"
	line "fly and shoot"
	cont "energy blasts!"
	cont "Battle me!"

	para "<PLAYER>: Sure!"
	line "Ready when you"
	cont "are!"
	done

_Route11Youngster3EndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_Route11Youngster3AfterBattleText::
	text "Wanna battle"
	line "again?"

	para "<PLAYER>: Only"
	line "if I'm allowed to"
	cont "punch something."
	done

_Route11SuperNerd2BattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done
