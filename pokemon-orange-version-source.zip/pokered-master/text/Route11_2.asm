_Route11SuperNerd2EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_Route11SuperNerd2AfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_Route11Youngster4BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_Route11Youngster4EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_Route11Youngster4AfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done

_Route11DiglettsCaveSignText::
	text "DIGLETT's CAVE"
	done
