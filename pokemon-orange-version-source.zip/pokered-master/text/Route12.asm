_Route12SnorlaxText::
	text "A sleeping #MON"
	line "blocks the way!"
	done

_Route12SnorlaxWokeUpText::
	text "SNORLAX woke up!"

	para "It attacked in a"
	line "grumpy rage!"
	done

_Route12SnorlaxCalmedDownText::
	text "SNORLAX calmed"
	line "down! With a big"
	cont "yawn, it returned"
	cont "to the mountains!"
	done

_Route12Fisher1BattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_Route12Fisher1EndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_Route12Fisher1AfterBattleText::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done

_Route12Fisher2BattleText::
	text "Prepare yourself!"
	line "This battle will"
	cont "be legendary!"

	para "<PLAYER>'s hair"
	line "flickered gold"
	cont "for a second."
	done

_Route12Fisher2EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_Route12Fisher2AfterBattleText::
	text "I'm still"
	line "catching my"
	cont "breath!"

	para "<PLAYER>: You sat"
	line "on a rock the"
	cont "whole time!"
	done

_Route12CooltrainerMBattleText::
	text "Stop right there!"
	line "You and me..."
	cont "BATTLE!"

	para "<PLAYER>: Yes!"
	line "Finally someone"
	cont "who gets it!"
	done

_Route12CooltrainerMEndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_Route12CooltrainerMAfterBattleText::
	text "Best battle of"
	line "my life!"

	para "<PLAYER>: But"
	line "you just stood"
	cont "there pointing!"
	done

_Route12SuperNerdBattleText::
	text "Eek! It's you!"
	line "I'm so excited!"
	cont "Let's battle!"

	para "<PLAYER> started"
	line "to glow a little."
	done

_Route12SuperNerdEndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_Route12SuperNerdAfterBattleText::
	text "Phew! That"
	line "battle was rough!"

	para "<PLAYER> did a"
	line "hundred push-ups"
	cont "out of boredom."
	done

_Route12Fisher3BattleText::
	text "I've trained my"
	line "whole life to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Hit me with your"
	cont "best shot!"
	done

_Route12Fisher3EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_Route12Fisher3AfterBattleText::
	text "Some advice: use"
	line "type matchups!"

	para "<PLAYER>: What"
	line "about fist"
	cont "matchups?"
	done

_Route12Fisher4BattleText::
	text "Let's settle"
	line "this with a"
	cont "battle, champ!"

	para "<PLAYER> flexed."
	line "Bring it on!"
	done

_Route12Fisher4EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_Route12Fisher4AfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_Route12Fisher5BattleText::
	text "I warmed up for"
	line "three whole hours"
	cont "for this battle!"

	para "<PLAYER>: Only"
	line "three? Well, it's"
	cont "a start!"
	done

_Route12Fisher5EndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_Route12Fisher5AfterBattleText::
	text "Nobody battles"
	line "like you do!"

	para "<PLAYER> mumbled"
	line "something about"
	cont "Kamehamehas."
	done

_Route12SignText::
	text "ROUTE 12 "
	line "North to LAVENDER"
	done

_Route12SportFishingSignText::
	text "SPORT FISHING AREA"
	done
