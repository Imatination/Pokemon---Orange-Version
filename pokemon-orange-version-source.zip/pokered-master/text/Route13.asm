_Route13CooltrainerM1BattleText::
	text "I'm gonna battle"
	line "you so hard!"

	para "<PLAYER> tied his"
	line "belt tighter."
	cont "Let's go!"
	done

_Route13CooltrainerM1EndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_Route13CooltrainerM1AfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done

_Route13CooltrainerF1BattleText::
	text "Don't go easy on"
	line "me! I want your"
	cont "strongest battle!"

	para "<PLAYER>: My"
	line "strongest? You"
	cont "sure about that?"
	done

_Route13CooltrainerF1EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_Route13CooltrainerF1AfterBattleText::
	text "Whoa, I'm sore"
	line "from that battle!"

	para "<PLAYER>: How?!"
	line "You didn't move!"
	done

_Route13CooltrainerF2BattleText::
	text "Whoa! Are you"
	line "<PLAYER>? Let's"
	cont "battle right now!"

	para "<PLAYER> grinned"
	line "and cracked his"
	cont "knuckles. Yes!"
	done

_Route13CooltrainerF2EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_Route13CooltrainerF2AfterBattleText::
	text "My hands are"
	line "still shaking!"

	para "<PLAYER>: Then"
	line "let's spar!"
	cont "Hey! Come back!"
	done

_Route13CooltrainerF3BattleText::
	text "I've been"
	line "stretching all"
	cont "morning for you!"

	para "<PLAYER>: Ooh!"
	line "A real warrior!"
	cont "Come on!"
	done

_Route13CooltrainerF3EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_Route13CooltrainerF3AfterBattleText::
	text "Everyone talks"
	line "about how strong"
	cont "you are!"

	para "<PLAYER>: Then"
	line "why won't anyone"
	cont "fight me?!"
	done

_Route13CooltrainerF4BattleText::
	text "You! Me! Battle!"
	line "No running away!"

	para "<PLAYER>: Run?"
	line "I never run from"
	cont "a good fight!"
	done

_Route13CooltrainerF4EndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_Route13CooltrainerF4AfterBattleText::
	text "I'll never forget"
	line "our epic clash!"

	para "<PLAYER>: What"
	line "clash? Our hands"
	cont "never touched!"
	done

_Route13CooltrainerM2BattleText::
	text "You look tough!"
	line "Our battle will"
	cont "be epic!"

	para "<PLAYER>: I've"
	line "been waiting all"
	cont "day for this!"
	done

_Route13CooltrainerM2EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_Route13CooltrainerM2AfterBattleText::
	text "Let's battle"
	line "again tomorrow!"

	para "<PLAYER>: Can we"
	line "spar instead?"
	cont "...No? Okay."
	done

_Route13Beauty1BattleText::
	text "I heard about"
	line "your power level!"
	cont "Battle me!"

	para "<PLAYER>: Wow,"
	line "you know about"
	cont "power levels?"
	done

_Route13Beauty1EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_Route13Beauty1AfterBattleText::
	text "I can't believe"
	line "I battled THE"
	cont "<PLAYER>!"

	para "<PLAYER>: You"
	line "still haven't."
	cont "Not really."
	done

_Route13Beauty2BattleText::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done

_Route13Beauty2EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_Route13Beauty2AfterBattleText::
	text "You battle like"
	line "a true master!"

	para "<PLAYER>: I"
	line "didn't even get"
	cont "to warm up!"
	done

_Route13BikerBattleText::
	text "My #MON and I"
	line "are fired up!"
	cont "Battle time!"

	para "<PLAYER>: Your"
	line "#MON? Wait..."
	cont "who do I punch?"
	done

_Route13BikerEndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_Route13BikerAfterBattleText::
	text "You're a battle"
	line "genius, <PLAYER>!"

	para "<PLAYER>: I"
	line "didn't battle!"
	cont "Your #MON did!"
	done

_Route13CooltrainerM3BattleText::
	text "Feel this aura?"
	line "It's my fighting"
	cont "spirit!"

	para "<PLAYER>: It's"
	line "tiny, but I like"
	cont "your attitude!"
	done

_Route13CooltrainerM3EndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_Route13CooltrainerM3AfterBattleText::
	text "My #MON did"
	line "their best!"

	para "<PLAYER>: Great!"
	line "Now YOU do your"
	cont "best. Hands up!"

	para "...Huh? Battle's"
	line "over? Again?"
	done

_Route13TrainerTips1Text::
	text "TRAINER TIPS"

	para "Look to the left"
	line "of that post!"
	done

_Route13TrainerTips2Text::
	text "TRAINER TIPS"

	para "Use SELECT to"
	line "switch items in"
	cont "the ITEM window!"
	done

_Route13SignText::
	text "ROUTE 13"
	line "North to SILENCE"
	cont "BRIDGE"
	done
