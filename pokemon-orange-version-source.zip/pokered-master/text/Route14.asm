_Route14CooltrainerM1BattleText::
	text "Everyone says"
	line "you're the best"
	cont "fighter around!"

	para "<PLAYER> started"
	line "powering up."
	cont "Let's do this!"
	done

_Route14CooltrainerM1EndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_Route14CooltrainerM1AfterBattleText::
	text "Battle me again"
	line "after I train!"

	para "<PLAYER>: Try"
	line "gravity training!"
	cont "100x is fun!"
	done

_Route14CooltrainerM2BattleText::
	text "Our eyes met!"
	line "That means we"
	cont "have to battle!"

	para "<PLAYER>: I"
	line "LOVE that rule!"
	done

_Route14CooltrainerM2EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_Route14CooltrainerM2AfterBattleText::
	text "I gave that"
	line "battle everything"
	cont "I had!"

	para "<PLAYER>: You"
	line "threw a ball and"
	cont "shouted. Twice."
	done

_Route14CooltrainerM3BattleText::
	text "I've got moves"
	line "you've never"
	cont "even seen!"

	para "<PLAYER>: Show"
	line "me! Show me!"
	done

_Route14CooltrainerM3EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_Route14CooltrainerM3AfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_Route14CooltrainerM4BattleText::
	text "I skipped lunch"
	line "to train for"
	cont "this battle!"

	para "<PLAYER>: You"
	line "skipped LUNCH?"
	cont "Now I'm worried."
	done

_Route14CooltrainerM4EndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_Route14CooltrainerM4AfterBattleText::
	text "Did you feel"
	line "the tension in"
	cont "that battle?"

	para "<PLAYER>: I felt"
	line "hungry. That's"
	cont "about it."
	done

_Route14CooltrainerM5BattleText::
	text "I came all this"
	line "way just to"
	cont "battle you!"

	para "<PLAYER>: Then"
	line "let's make it"
	cont "worth the trip!"
	done

_Route14CooltrainerM5EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_Route14CooltrainerM5AfterBattleText::
	text "Our battle was"
	line "so heated!"

	para "<PLAYER> looked"
	line "at his fists."
	cont "Still clean."
	done

_Route14CooltrainerM6BattleText::
	text "My heart is"
	line "pounding! Battle"
	cont "me, <PLAYER>!"

	para "<PLAYER>: Now"
	line "we're talking!"
	cont "Don't hold back!"
	done

_Route14CooltrainerM6EndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_Route14CooltrainerM6AfterBattleText::
	text "I'll train hard"
	line "and battle you"
	cont "again!"

	para "<PLAYER>: Train"
	line "YOURSELF too! Do"
	cont "some sit-ups!"
	done

_Route14Biker1BattleText::
	text "Is it true you"
	line "beat a guy who"
	cont "blew up planets?"
	cont "Battle me!"

	para "<PLAYER>: Gladly!"
	line "You must be"
	cont "super strong!"
	done

_Route14Biker1EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_Route14Biker1AfterBattleText::
	text "That battle"
	line "was electric!"

	para "<PLAYER>'s"
	line "stomach growled."
	cont "Lunch time, then."
	done

_Route14Biker2BattleText::
	text "My sensei said"
	line "to battle the"
	cont "strongest guy!"

	para "<PLAYER>: Your"
	line "sensei sounds"
	cont "awesome!"
	done

_Route14Biker2EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_Route14Biker2AfterBattleText::
	text "I'm exhausted"
	line "after that fight!"

	para "<PLAYER>: From"
	line "what? Yelling"
	cont "move names?"
	done

_Route14Biker3BattleText::
	text "They say you can"
	line "fly and shoot"
	cont "energy blasts!"
	cont "Battle me!"

	para "<PLAYER>: Sure!"
	line "Ready when you"
	cont "are!"
	done

_Route14Biker3EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_Route14Biker3AfterBattleText::
	text "Wanna battle"
	line "again?"

	para "<PLAYER>: Only"
	line "if I'm allowed to"
	cont "punch something."
	done

_Route14Biker4BattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done

_Route14Biker4EndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_Route14Biker4AfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_Route14SignText::
	text "ROUTE 14"
	line "West to FUCHSIA"
	cont "CITY"
	done
