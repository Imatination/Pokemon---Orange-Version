_Route15CooltrainerF1BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_Route15CooltrainerF1EndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_Route15CooltrainerF1AfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done

_Route15CooltrainerF2BattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_Route15CooltrainerF2EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_Route15CooltrainerF2AfterBattleText::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done

_Route15CooltrainerM1BattleText::
	text "Prepare yourself!"
	line "This battle will"
	cont "be legendary!"

	para "<PLAYER>'s hair"
	line "flickered gold"
	cont "for a second."
	done

_Route15CooltrainerM1EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_Route15CooltrainerM1AfterBattleText::
	text "I'm still"
	line "catching my"
	cont "breath!"

	para "<PLAYER>: You sat"
	line "on a rock the"
	cont "whole time!"
	done

_Route15CooltrainerM2BattleText::
	text "Stop right there!"
	line "You and me..."
	cont "BATTLE!"

	para "<PLAYER>: Yes!"
	line "Finally someone"
	cont "who gets it!"
	done

_Route15CooltrainerM2EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_Route15CooltrainerM2AfterBattleText::
	text "Best battle of"
	line "my life!"

	para "<PLAYER>: But"
	line "you just stood"
	cont "there pointing!"
	done

_Route15Beauty1BattleText::
	text "Eek! It's you!"
	line "I'm so excited!"
	cont "Let's battle!"

	para "<PLAYER> started"
	line "to glow a little."
	done

_Route15Beauty1EndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_Route15Beauty1AfterBattleText::
	text "Phew! That"
	line "battle was rough!"

	para "<PLAYER> did a"
	line "hundred push-ups"
	cont "out of boredom."
	done

_Route15Beauty2BattleText::
	text "I've trained my"
	line "whole life to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Hit me with your"
	cont "best shot!"
	done

_Route15Beauty2EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_Route15Beauty2AfterBattleText::
	text "Some advice: use"
	line "type matchups!"

	para "<PLAYER>: What"
	line "about fist"
	cont "matchups?"
	done

_Route15Biker1BattleText::
	text "Let's settle"
	line "this with a"
	cont "battle, champ!"

	para "<PLAYER> flexed."
	line "Bring it on!"
	done

_Route15Biker1EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_Route15Biker1AfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_Route15Biker2BattleText::
	text "I warmed up for"
	line "three whole hours"
	cont "for this battle!"

	para "<PLAYER>: Only"
	line "three? Well, it's"
	cont "a start!"
	done

_Route15Biker2EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_Route15Biker2AfterBattleText::
	text "Nobody battles"
	line "like you do!"

	para "<PLAYER> mumbled"
	line "something about"
	cont "Kamehamehas."
	done

_Route15CooltrainerF3BattleText::
	text "I'm gonna battle"
	line "you so hard!"

	para "<PLAYER> tied his"
	line "belt tighter."
	cont "Let's go!"
	done

_Route15CooltrainerF3EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_Route15CooltrainerF3AfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done

_Route15CooltrainerF4BattleText::
	text "Don't go easy on"
	line "me! I want your"
	cont "strongest battle!"

	para "<PLAYER>: My"
	line "strongest? You"
	cont "sure about that?"
	done

_Route15CooltrainerF4EndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_Route15CooltrainerF4AfterBattleText::
	text "I'll go train with"
	line "weaker people.@"
	text_end

_Route15SignText::
	text "ROUTE 15"
	line "West to FUCHSIA"
	cont "CITY"
	done
