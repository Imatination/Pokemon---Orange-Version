_Route16Biker1BattleText::
	text "Whoa! Are you"
	line "<PLAYER>? Let's"
	cont "battle right now!"

	para "<PLAYER> grinned"
	line "and cracked his"
	cont "knuckles. Yes!"
	done

_Route16Biker1EndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_Route16Biker1AfterBattleText::
	text "Whoa, I'm sore"
	line "from that battle!"

	para "<PLAYER>: How?!"
	line "You didn't move!"
	done

_Route16Biker2BattleText::
	text "I've been"
	line "stretching all"
	cont "morning for you!"

	para "<PLAYER>: Ooh!"
	line "A real warrior!"
	cont "Come on!"
	done

_Route16Biker2EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_Route16Biker2AfterBattleText::
	text "My hands are"
	line "still shaking!"

	para "<PLAYER>: Then"
	line "let's spar!"
	cont "Hey! Come back!"
	done

_Route16Biker3BattleText::
	text "You! Me! Battle!"
	line "No running away!"

	para "<PLAYER>: Run?"
	line "I never run from"
	cont "a good fight!"
	done

_Route16Biker3EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_Route16Biker3AfterBattleText::
	text "Everyone talks"
	line "about how strong"
	cont "you are!"

	para "<PLAYER>: Then"
	line "why won't anyone"
	cont "fight me?!"
	done

_Route16biker4BattleText::
	text "You look tough!"
	line "Our battle will"
	cont "be epic!"

	para "<PLAYER>: I've"
	line "been waiting all"
	cont "day for this!"
	done

_Route16Biker4EndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_Route16Biker4AfterBattleText::
	text "I'll never forget"
	line "our epic clash!"

	para "<PLAYER>: What"
	line "clash? Our hands"
	cont "never touched!"
	done

_Route16Biker5BattleText::
	text "I heard about"
	line "your power level!"
	cont "Battle me!"

	para "<PLAYER>: Wow,"
	line "you know about"
	cont "power levels?"
	done

_Route16Biker5EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_Route16Biker5AfterBattleText::
	text "Let's battle"
	line "again tomorrow!"

	para "<PLAYER>: Can we"
	line "spar instead?"
	cont "...No? Okay."
	done

_Route16Biker6BattleText::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done

_Route16Biker6EndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_Route16Biker6AfterBattleText::
	text "I can't believe"
	line "I battled THE"
	cont "<PLAYER>!"

	para "<PLAYER>: You"
	line "still haven't."
	cont "Not really."
	done

_Route16Text7::
	text "A sleeping #MON"
	line "blocks the way!"
	done

_Route16SnorlaxWokeUpText::
	text "SNORLAX woke up!"

	para "It attacked in a"
	line "grumpy rage!"
	done

_Route16SnorlaxReturnedToMountainsText::
	text "With a big yawn,"
	line "SNORLAX returned"
	cont "to the mountains!"
	done

_Route16CyclingRoadSignText::
	text "Enjoy the slope!"
	line "CYCLING ROAD"
	done

_Route16SignText::
	text "ROUTE 16"
	line "CELADON CITY -"
	cont "FUCHSIA CITY"
	done
