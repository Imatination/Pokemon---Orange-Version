_Route18CooltrainerM1BattleText::
	text "They say you can"
	line "fly and shoot"
	cont "energy blasts!"
	cont "Battle me!"

	para "<PLAYER>: Sure!"
	line "Ready when you"
	cont "are!"
	done

_Route18CooltrainerM1EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_Route18CooltrainerM1AfterBattleText::
	text "I'm exhausted"
	line "after that fight!"

	para "<PLAYER>: From"
	line "what? Yelling"
	cont "move names?"
	done

_Route18CooltrainerM2BattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done

_Route18CooltrainerM2EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_Route18CooltrainerM2AfterBattleText::
	text "Wanna battle"
	line "again?"

	para "<PLAYER>: Only"
	line "if I'm allowed to"
	cont "punch something."
	done

_Route18CooltrainerM3BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_Route18CooltrainerM3EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_Route18CooltrainerM3AfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_Route18SignText::
	text "ROUTE 18"
	line "CELADON CITY -"
	cont "FUCHSIA CITY"
	done

_Route18CyclingRoadSignText::
	text "CYCLING ROAD"
	line "No pedestrians"
	cont "permitted!"
	done
