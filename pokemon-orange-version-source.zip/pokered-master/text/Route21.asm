_Route21Fisher1BattleText::
	text "I skipped lunch"
	line "to train for"
	cont "this battle!"

	para "<PLAYER>: You"
	line "skipped LUNCH?"
	cont "Now I'm worried."
	done

_Route21Fisher1EndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_Route21Fisher1AfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_Route21Fisher2BattleText::
	text "I came all this"
	line "way just to"
	cont "battle you!"

	para "<PLAYER>: Then"
	line "let's make it"
	cont "worth the trip!"
	done

_Route21Fisher2EndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_Route21Fisher2AfterBattleText::
	text "Did you feel"
	line "the tension in"
	cont "that battle?"

	para "<PLAYER>: I felt"
	line "hungry. That's"
	cont "about it."
	done

_Route21Swimmer1BattleText::
	text "My heart is"
	line "pounding! Battle"
	cont "me, <PLAYER>!"

	para "<PLAYER>: Now"
	line "we're talking!"
	cont "Don't hold back!"
	done

_Route21Swimmer1EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_Route21Swimmer1AfterBattleText::
	text "Our battle was"
	line "so heated!"

	para "<PLAYER> looked"
	line "at his fists."
	cont "Still clean."
	done

_Route21Swimmer2BattleText::
	text "Is it true you"
	line "beat a guy who"
	cont "blew up planets?"
	cont "Battle me!"

	para "<PLAYER>: Gladly!"
	line "You must be"
	cont "super strong!"
	done

_Route21Swimmer2EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_Route21Swimmer2AfterBattleText::
	text "I'll train hard"
	line "and battle you"
	cont "again!"

	para "<PLAYER>: Train"
	line "YOURSELF too! Do"
	cont "some sit-ups!"
	done

_Route21Swimmer3BattleText::
	text "My sensei said"
	line "to battle the"
	cont "strongest guy!"

	para "<PLAYER>: Your"
	line "sensei sounds"
	cont "awesome!"
	done

_Route21Swimmer3EndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_Route21Swimmer3AfterBattleText::
	text "That battle"
	line "was electric!"

	para "<PLAYER>'s"
	line "stomach growled."
	cont "Lunch time, then."
	done

_Route21Swimmer4BattleText::
	text "They say you can"
	line "fly and shoot"
	cont "energy blasts!"
	cont "Battle me!"

	para "<PLAYER>: Sure!"
	line "Ready when you"
	cont "are!"
	done

_Route21Swimmer4EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_Route21Swimmer4AfterBattleText::
	text "I'm exhausted"
	line "after that fight!"

	para "<PLAYER>: From"
	line "what? Yelling"
	cont "move names?"
	done

_Route21Swimmer5BattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done

_Route21Swimmer5EndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_Route21Swimmer5AfterBattleText::
	text "Wanna battle"
	line "again?"

	para "<PLAYER>: Only"
	line "if I'm allowed to"
	cont "punch something."
	done

_Route21Fisher3BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_Route21Fisher3EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_Route21Fisher3AfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_Route21Fisher4BattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_Route21Fisher4EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_Route21Fisher4AfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done
