_Route22RivalBeforeBattleText1::
	text "<RIVAL>: Hey!"
	line "<PLAYER>!"

	para "Let's battle! I"
	line "bet I'm way"
	cont "stronger now!"

	para "<PLAYER>: Then"
	line "show me! Throw"
	cont "a punch!"

	para "<RIVAL>: Ugh,"
	line "not that again!"
	done

_Route22RivalAfterBattleText1::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done

_Route22Rival1DefeatedText::
	text "Awww!"
	line "You just lucked"
	cont "out!"
	prompt

_Route22Rival1VictoryText::
	text "<RIVAL>: What?"
	line "Why do I have 2"
	cont "#MON?"

	para "You should catch"
	cont "some more too!"
	prompt

_Route22RivalBeforeBattleText2::
	text "<RIVAL>: Hey!"
	line "<PLAYER>!"

	para "I trained hard!"
	line "Battle me!"

	para "<PLAYER>: Did"
	line "you do any"
	cont "push-ups this"
	cont "time?"

	para "<RIVAL>: My"
	line "#MON did!"
	cont "Probably!"
	done

_Route22RivalAfterBattleText2::
	text "I'm still"
	line "catching my"
	cont "breath!"

	para "<PLAYER>: You sat"
	line "on a rock the"
	cont "whole time!"
	done

_Route22Rival2DefeatedText::
	text "What!?"

	para "I was just"
	line "careless!"
	prompt

_Route22Rival2VictoryText::
	text "<RIVAL>: Hahaha!"
	line "<PLAYER>! That's"
	cont "your best? You're"
	cont "nowhere near as"
	cont "good as me, pal!"

	para "Go train some"
	line "more! You loser!"
	prompt

_Route22PokemonLeagueSignText::
	text "#MON LEAGUE"
	line "Front Gate"
	done
