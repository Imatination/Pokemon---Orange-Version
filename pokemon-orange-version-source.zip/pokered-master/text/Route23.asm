_Route23YouDontHaveTheBadgeYetText::
	text "You can pass here"
	line "only if you have"
	cont "the @"
	text_ram wNameBuffer
	text "!"

	para "You don't have the"
	line "@"
	text_ram wNameBuffer
	text " yet!"

	para "You have to have"
	line "it to get to"
	cont "#MON LEAGUE!@"
	text_end

_Route23OhThatIsTheBadgeText::
	text "You can pass here"
	line "only if you have"
	cont "the @"
	text_ram wNameBuffer
	text "!"

	para "Oh! That is the"
	line "@"
	text_ram wNameBuffer
	text "!@"
	text_end

_Route23GoRightAheadText::
	text_start

	para "OK then! Please,"
	line "go right ahead!"
	done

_Route23VictoryRoadGateSignText::
	text "VICTORY ROAD GATE"
	line "- #MON LEAGUE"
	done

_Route23VegetaGuardText::
	text "GUARD: Halt! Only"
	line "trainers with all"
	cont "the BADGES may"
	cont "pass!"

	para "VEGETA: BADGES?!"
	line "I am the PRINCE"
	cont "of all SAIYANS!"

	para "I don't need your"
	line "stupid BADGES!"
	prompt

_Route23VegetaRageText::
	text "VEGETA turned"
	line "SUPER SAIYAN!"

	para "GUARDS: Eeek!"
	line "P-please, go"
	cont "right ahead! All"
	cont "of you!"
	done
