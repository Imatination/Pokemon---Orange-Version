_Route24CooltrainerM2EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_Route24CooltrainerM2AfterBattleText::
	text "Best battle of"
	line "my life!"

	para "<PLAYER>: But"
	line "you just stood"
	cont "there pointing!"
	done

_Route24CooltrainerM3BattleText::
	text "Stop right there!"
	line "You and me..."
	cont "BATTLE!"

	para "<PLAYER>: Yes!"
	line "Finally someone"
	cont "who gets it!"
	done

_Route24CooltrainerM3EndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_Route24CooltrainerM3AfterBattleText::
	text "Phew! That"
	line "battle was rough!"

	para "<PLAYER> did a"
	line "hundred push-ups"
	cont "out of boredom."
	done

_Route24CooltrainerF1BattleText::
	text "Eek! It's you!"
	line "I'm so excited!"
	cont "Let's battle!"

	para "<PLAYER> started"
	line "to glow a little."
	done

_Route24CooltrainerF1EndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_Route24CooltrainerF1AfterBattleText::
	text "Some advice: use"
	line "type matchups!"

	para "<PLAYER>: What"
	line "about fist"
	cont "matchups?"
	done

_Route24Youngster1BattleText::
	text "I've trained my"
	line "whole life to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Hit me with your"
	cont "best shot!"
	done

_Route24Youngster1EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_Route24Youngster1AfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_Route24CooltrainerF2BattleText::
	text "Let's settle"
	line "this with a"
	cont "battle, champ!"

	para "<PLAYER> flexed."
	line "Bring it on!"
	done

_Route24CooltrainerF2EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_Route24CooltrainerF2AfterBattleText::
	text "Nobody battles"
	line "like you do!"

	para "<PLAYER> mumbled"
	line "something about"
	cont "Kamehamehas."
	done

_Route24Youngster2BattleText::
	text "I warmed up for"
	line "three whole hours"
	cont "for this battle!"

	para "<PLAYER>: Only"
	line "three? Well, it's"
	cont "a start!"
	done

_Route24Youngster2EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_Route24Youngster2AfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done
