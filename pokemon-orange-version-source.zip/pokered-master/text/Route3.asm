_Route3Text1::
	text "Whew... I better"
	line "take a rest..."
	cont "Groan..."

	para "That tunnel from"
	line "CERULEAN takes a"
	cont "lot out of you!"
	done

_Route3Youngster1BattleText::
	text "Feel this aura?"
	line "It's my fighting"
	cont "spirit!"

	para "<PLAYER>: It's"
	line "tiny, but I like"
	cont "your attitude!"
	done

_Route3Youngster1EndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_Route3Youngster1AfterBattleText::
	text "Battle me again"
	line "after I train!"

	para "<PLAYER>: Try"
	line "gravity training!"
	cont "100x is fun!"
	done

_Route3Youngster2BattleText::
	text "Everyone says"
	line "you're the best"
	cont "fighter around!"

	para "<PLAYER> started"
	line "powering up."
	cont "Let's do this!"
	done

_Route3Youngster2EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_Route3Youngster2AfterBattleText::
	text "I gave that"
	line "battle everything"
	cont "I had!"

	para "<PLAYER>: You"
	line "threw a ball and"
	cont "shouted. Twice."
	done

_Route3CooltrainerF1BattleText::
	text "Our eyes met!"
	line "That means we"
	cont "have to battle!"

	para "<PLAYER>: I"
	line "LOVE that rule!"
	done

_Route3CooltrainerF1EndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_Route3CooltrainerF1AfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_Route3Youngster3BattleText::
	text "I've got moves"
	line "you've never"
	cont "even seen!"

	para "<PLAYER>: Show"
	line "me! Show me!"
	done

_Route3Youngster3EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_Route3Youngster3AfterBattleText::
	text "Did you feel"
	line "the tension in"
	cont "that battle?"

	para "<PLAYER>: I felt"
	line "hungry. That's"
	cont "about it."
	done

_Route3CooltrainerF2BattleText::
	text "I skipped lunch"
	line "to train for"
	cont "this battle!"

	para "<PLAYER>: You"
	line "skipped LUNCH?"
	cont "Now I'm worried."
	done

_Route3CooltrainerF2EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_Route3CooltrainerF2AfterBattleText::
	text "Our battle was"
	line "so heated!"

	para "<PLAYER> looked"
	line "at his fists."
	cont "Still clean."
	done

_Route3Youngster4BattleText::
	text "I came all this"
	line "way just to"
	cont "battle you!"

	para "<PLAYER>: Then"
	line "let's make it"
	cont "worth the trip!"
	done

_Route3Youngster4EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_Route3Youngster4AfterBattleText::
	text "I'll train hard"
	line "and battle you"
	cont "again!"

	para "<PLAYER>: Train"
	line "YOURSELF too! Do"
	cont "some sit-ups!"
	done

_Route3Youngster5BattleText::
	text "My heart is"
	line "pounding! Battle"
	cont "me, <PLAYER>!"

	para "<PLAYER>: Now"
	line "we're talking!"
	cont "Don't hold back!"
	done

_Route3Youngster5EndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_Route3Youngster5AfterBattleText::
	text "That battle"
	line "was electric!"

	para "<PLAYER>'s"
	line "stomach growled."
	cont "Lunch time, then."
	done

_Route3CooltrainerF3BattleText::
	text "Is it true you"
	line "beat a guy who"
	cont "blew up planets?"
	cont "Battle me!"

	para "<PLAYER>: Gladly!"
	line "You must be"
	cont "super strong!"
	done

_Route3CooltrainerF3EndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_Route3CooltrainerF3AfterBattleText::
	text "I'm exhausted"
	line "after that fight!"

	para "<PLAYER>: From"
	line "what? Yelling"
	cont "move names?"
	done

_Route3SignText::
	text "ROUTE 3"
	line "MT.MOON AHEAD"
	done
