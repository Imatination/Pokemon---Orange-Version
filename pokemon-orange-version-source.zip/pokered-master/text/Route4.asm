_Route4CooltrainerF1Text::
	text "Ouch! I tripped"
	line "over a rocky"
	cont "#MON, GEODUDE!"
	done

_Route4CooltrainerF2BattleText::
	text "My sensei said"
	line "to battle the"
	cont "strongest guy!"

	para "<PLAYER>: Your"
	line "sensei sounds"
	cont "awesome!"
	done

_Route4CooltrainerF2EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_Route4CooltrainerF2AfterBattleText::
	text "Wanna battle"
	line "again?"

	para "<PLAYER>: Only"
	line "if I'm allowed to"
	cont "punch something."
	done

_Route4MtMoonSignText::
	text "MT.MOON"
	line "Tunnel Entrance"
	done

_Route4SignText::
	text "ROUTE 4"
	line "MT.MOON -"
	cont "CERULEAN CITY"
	done

_Route4GokuSeesExitText::
	text "<PLAYER>: Hey..."
	line "I think I can see"
	cont "the exit of this"
	cont "cave on the other"
	cont "side of the"
	cont "mountain!"

	para "Why walk around"
	line "in the dark?"
	cont "I'll make my own"
	cont "tunnel!"

	para "HAAAAAAA..."
	prompt

_Route4GokuSuperSaiyanText::
	text "<PLAYER> turned"
	line "SUPER SAIYAN!"

	para "KA... ME..."
	line "HA... ME..."

	para "HAAAAAAAAA!!!"
	prompt

_Route4GokuBlastedText::
	text "<PLAYER> blasted a"
	line "hole straight"
	cont "through MT.MOON!"

	para "<PLAYER>: Heh!"
	line "Now that's a"
	cont "shortcut!"
	done

_Route4VegetaIntroText::
	text "VEGETA: KAKAROT!"
	line "Took you long"
	cont "enough!"

	para "I've been"
	line "training non-stop"
	cont "since we met!"

	para "I'm far stronger"
	line "now... and so is"
	cont "my @"
	text_ram wNameBuffer
	text "!"

	para "Let's settle"
	line "this, KAKAROT!"
	done

_Route4VegetaDefeatedText::
	text "No!"
	line "Not again...!"
	prompt

_Route4VegetaVictoryText::
	text "Ha!"
	line "Pathetic,"
	cont "KAKAROT!"
	prompt

_Route4VegetaBeatenText::
	text "VEGETA: Hmph..."
	line "You win again,"
	cont "KAKAROT."

	para "Fine! I'll travel"
	line "with you... until"
	cont "I can beat you!"
	prompt

_Route4VegetaBlastText::
	text "VEGETA: But I"
	line "don't use YOUR"
	cont "tunnels!"

	para "BIG BANG..."
	line "ATTACK!!!"
	prompt

_Route4VegetaTunnelText::
	text "VEGETA blasted a"
	line "huge hole through"
	cont "MT.MOON!"
	prompt

_Route4VegetaItemsText::
	text "VEGETA: Hmph. I"
	line "grabbed these on"
	cont "the way through."

	para "<PLAYER> got 2"
	line "MOON STONEs, a"
	cont "DOME FOSSIL, a"
	cont "HELIX FOSSIL and"
	cont "TM12!@"
	text_end
