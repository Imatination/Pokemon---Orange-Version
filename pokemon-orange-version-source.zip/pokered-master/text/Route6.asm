_Route6CooltrainerM1BattleText::
	text "They say you can"
	line "fly and shoot"
	cont "energy blasts!"
	cont "Battle me!"

	para "<PLAYER>: Sure!"
	line "Ready when you"
	cont "are!"
	done

_Route6CooltrainerM1EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_Route6CooltrainerAfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_Route6CooltrainerF1BattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done

_Route6CooltrainerF1EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_Route6Youngster1BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_Route6Youngster1EndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_Route6Youngster1AfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done

_Route6CooltrainerM2BattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_Route6CooltrainerM2EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_Route6CooltrainerM2AfterBattleText::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done

_Route6CooltrainerF2BattleText::
	text "Prepare yourself!"
	line "This battle will"
	cont "be legendary!"

	para "<PLAYER>'s hair"
	line "flickered gold"
	cont "for a second."
	done

_Route6CooltrainerF2EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_Route6CooltrainerF2AfterBattleText::
	text "I'm still"
	line "catching my"
	cont "breath!"

	para "<PLAYER>: You sat"
	line "on a rock the"
	cont "whole time!"
	done

_Route6Youngster2BattleText::
	text "Stop right there!"
	line "You and me..."
	cont "BATTLE!"

	para "<PLAYER>: Yes!"
	line "Finally someone"
	cont "who gets it!"
	done

_Route6Youngster2EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_Route6Youngster2AfterBattleText::
	text "Best battle of"
	line "my life!"

	para "<PLAYER>: But"
	line "you just stood"
	cont "there pointing!"
	done

_Route6UndergroundPathSignText::
	text "UNDERGROUND PATH"
	line "CERULEAN CITY -"
	cont "VERMILION CITY"
	done
