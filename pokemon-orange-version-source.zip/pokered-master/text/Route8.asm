_Route8SuperNerd1BattleText::
	text "Eek! It's you!"
	line "I'm so excited!"
	cont "Let's battle!"

	para "<PLAYER> started"
	line "to glow a little."
	done

_Route8SuperNerd1EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_Route8SuperNerd1AfterBattleText::
	text "Phew! That"
	line "battle was rough!"

	para "<PLAYER> did a"
	line "hundred push-ups"
	cont "out of boredom."
	done

_Route8Gambler1BattleText::
	text "I've trained my"
	line "whole life to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Hit me with your"
	cont "best shot!"
	done

_Route8Gambler1EndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_Route8Gambler1AfterBattleText::
	text "Some advice: use"
	line "type matchups!"

	para "<PLAYER>: What"
	line "about fist"
	cont "matchups?"
	done

_Route8SuperNerd2BattleText::
	text "Let's settle"
	line "this with a"
	cont "battle, champ!"

	para "<PLAYER> flexed."
	line "Bring it on!"
	done

_Route8SuperNerd2EndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_Route8SuperNerd2AfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_Route8CooltrainerF1BattleText::
	text "I warmed up for"
	line "three whole hours"
	cont "for this battle!"

	para "<PLAYER>: Only"
	line "three? Well, it's"
	cont "a start!"
	done

_Route8CooltrainerF1EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_Route8CooltrainerF1AfterBattleText::
	text "Nobody battles"
	line "like you do!"

	para "<PLAYER> mumbled"
	line "something about"
	cont "Kamehamehas."
	done

_Route8SuperNerd3BattleText::
	text "I'm gonna battle"
	line "you so hard!"

	para "<PLAYER> tied his"
	line "belt tighter."
	cont "Let's go!"
	done

_Route8SuperNerd3EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_Route8SuperNerd3AfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done

_Route8CooltrainerF2BattleText::
	text "Don't go easy on"
	line "me! I want your"
	cont "strongest battle!"

	para "<PLAYER>: My"
	line "strongest? You"
	cont "sure about that?"
	done

_Route8CooltrainerF2EndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_Route8CooltrainerF2AfterBattleText::
	text "Whoa, I'm sore"
	line "from that battle!"

	para "<PLAYER>: How?!"
	line "You didn't move!"
	done

_Route8CooltrainerF3BattleText::
	text "Whoa! Are you"
	line "<PLAYER>? Let's"
	cont "battle right now!"

	para "<PLAYER> grinned"
	line "and cracked his"
	cont "knuckles. Yes!"
	done

_Route8CooltrainerF3EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_Route8CooltrainerF3AfterBattleText::
	text "My hands are"
	line "still shaking!"

	para "<PLAYER>: Then"
	line "let's spar!"
	cont "Hey! Come back!"
	done

_Route8Gambler2BattleText::
	text "I've been"
	line "stretching all"
	cont "morning for you!"

	para "<PLAYER>: Ooh!"
	line "A real warrior!"
	cont "Come on!"
	done

_Route8Gambler2EndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_Route8Gambler2AfterBattleText::
	text "Everyone talks"
	line "about how strong"
	cont "you are!"

	para "<PLAYER>: Then"
	line "why won't anyone"
	cont "fight me?!"
	done

_Route8CooltrainerF4BattleText::
	text "You! Me! Battle!"
	line "No running away!"

	para "<PLAYER>: Run?"
	line "I never run from"
	cont "a good fight!"
	done

_Route8CooltrainerF4EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_Route8CooltrainerF4AfterBattleText::
	text "I'll never forget"
	line "our epic clash!"

	para "<PLAYER>: What"
	line "clash? Our hands"
	cont "never touched!"
	done

_Route8UndergroundSignText::
	text "UNDERGROUND PATH"
	line "CELADON CITY -"
	cont "LAVENDER TOWN"
	done
