_Route9CooltrainerF1BattleText::
	text "You look tough!"
	line "Our battle will"
	cont "be epic!"

	para "<PLAYER>: I've"
	line "been waiting all"
	cont "day for this!"
	done

_Route9CooltrainerF1EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_Route9CooltrainerF1AfterBattleText::
	text "Let's battle"
	line "again tomorrow!"

	para "<PLAYER>: Can we"
	line "spar instead?"
	cont "...No? Okay."
	done

_Route9CooltrainerM1BattleText::
	text "I heard about"
	line "your power level!"
	cont "Battle me!"

	para "<PLAYER>: Wow,"
	line "you know about"
	cont "power levels?"
	done

_Route9CooltrainerM1EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_Route9CooltrainerM1AfterBattleText::
	text "I can't believe"
	line "I battled THE"
	cont "<PLAYER>!"

	para "<PLAYER>: You"
	line "still haven't."
	cont "Not really."
	done

_Route9CooltrainerM2BattleText::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done

_Route9CooltrainerM2EndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_Route9CooltrainerM2AfterBattleText::
	text "You battle like"
	line "a true master!"

	para "<PLAYER>: I"
	line "didn't even get"
	cont "to warm up!"
	done

_Route9CooltrainerF2BattleText::
	text "My #MON and I"
	line "are fired up!"
	cont "Battle time!"

	para "<PLAYER>: Your"
	line "#MON? Wait..."
	cont "who do I punch?"
	done

_Route9CooltrainerF2EndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_Route9CooltrainerF2AfterBattleText::
	text "You're a battle"
	line "genius, <PLAYER>!"

	para "<PLAYER>: I"
	line "didn't battle!"
	cont "Your #MON did!"
	done

_Route9Hiker1BattleText::
	text "Feel this aura?"
	line "It's my fighting"
	cont "spirit!"

	para "<PLAYER>: It's"
	line "tiny, but I like"
	cont "your attitude!"
	done

_Route9Hiker1EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_Route9Hiker1AfterBattleText::
	text "My #MON did"
	line "their best!"

	para "<PLAYER>: Great!"
	line "Now YOU do your"
	cont "best. Hands up!"

	para "...Huh? Battle's"
	line "over? Again?"
	done

_Route9Hiker2BattleText::
	text "Everyone says"
	line "you're the best"
	cont "fighter around!"

	para "<PLAYER> started"
	line "powering up."
	cont "Let's do this!"
	done

_Route9Hiker2EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_Route9Hiker2AfterBattleText::
	text "Battle me again"
	line "after I train!"

	para "<PLAYER>: Try"
	line "gravity training!"
	cont "100x is fun!"
	done

_Route9Youngster1BattleText::
	text "Our eyes met!"
	line "That means we"
	cont "have to battle!"

	para "<PLAYER>: I"
	line "LOVE that rule!"
	done

_Route9Youngster1EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_Route9Youngster1AfterBattleText::
	text "I gave that"
	line "battle everything"
	cont "I had!"

	para "<PLAYER>: You"
	line "threw a ball and"
	cont "shouted. Twice."
	done

_Route9Hiker3BattleText::
	text "I've got moves"
	line "you've never"
	cont "even seen!"

	para "<PLAYER>: Show"
	line "me! Show me!"
	done

_Route9Hiker3EndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_Route9Hiker3AfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_Route9Youngster2BattleText::
	text "I skipped lunch"
	line "to train for"
	cont "this battle!"

	para "<PLAYER>: You"
	line "skipped LUNCH?"
	cont "Now I'm worried."
	done

_Route9Youngster2EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_Route9Youngster2AfterBattleText::
	text "Did you feel"
	line "the tension in"
	cont "that battle?"

	para "<PLAYER>: I felt"
	line "hungry. That's"
	cont "about it."
	done

_Route9SignText::
	text "ROUTE 9"
	line "CERULEAN CITY-"
	cont "ROCK TUNNEL"
	done
