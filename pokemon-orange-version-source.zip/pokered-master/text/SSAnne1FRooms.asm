_SSAnne1FRoomsWigglytuffText::
	text "WIGGLYTUFF: Puup"
	line "pupuu!@"
	text_end

_SSAnne1FRoomsGentleman1BattleText::
	text "I came all this"
	line "way just to"
	cont "battle you!"

	para "<PLAYER>: Then"
	line "let's make it"
	cont "worth the trip!"
	done

_SSAnne1FRoomsGentleman1EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_SSAnne1FRoomsGentleman1AfterBattleText::
	text "Our battle was"
	line "so heated!"

	para "<PLAYER> looked"
	line "at his fists."
	cont "Still clean."
	done

_SSAnne1FRoomsGentleman2BattleText::
	text "My heart is"
	line "pounding! Battle"
	cont "me, <PLAYER>!"

	para "<PLAYER>: Now"
	line "we're talking!"
	cont "Don't hold back!"
	done

_SSAnne1FRoomsGentleman2EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_SSAnne1FRoomsGentleman2AfterBattleText::
	text "I'll train hard"
	line "and battle you"
	cont "again!"

	para "<PLAYER>: Train"
	line "YOURSELF too! Do"
	cont "some sit-ups!"
	done

_SSAnne1FRoomsYoungsterBattleText::
	text "Is it true you"
	line "beat a guy who"
	cont "blew up planets?"
	cont "Battle me!"

	para "<PLAYER>: Gladly!"
	line "You must be"
	cont "super strong!"
	done

_SSAnne1FRoomsYoungsterEndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_SSAnne1FRoomsYoungsterAfterBattleText::
	text "That battle"
	line "was electric!"

	para "<PLAYER>'s"
	line "stomach growled."
	cont "Lunch time, then."
	done

_SSAnne1FRoomsCooltrainerFBattleText::
	text "My sensei said"
	line "to battle the"
	cont "strongest guy!"

	para "<PLAYER>: Your"
	line "sensei sounds"
	cont "awesome!"
	done

_SSAnne1FRoomsCooltrainerFEndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_SSAnne1FRoomsCooltrainerFAfterBattleText::
	text "I'm exhausted"
	line "after that fight!"

	para "<PLAYER>: From"
	line "what? Yelling"
	cont "move names?"
	done

_SSAnne1FRoomsGirl1Text::
	text "Waiter, I would"
	line "like a cherry pie"
	cont "please!"
	done

_SSAnne1FRoomsMiddleAgedManText::
	text "A cruise is so"
	line "elegant yet cozy!"
	done

_SSAnne1FRoomsLittleGirlText::
	text "I always travel"
	line "with WIGGLYTUFF!"
	done

_SSAnne1FRoomsGirl2Text::
	text "We are cruising"
	line "around the world."
	done

_SSAnne1FRoomsGentleman3Text::
	text "Ssh! I'm a GLOBAL"
	line "POLICE agent!"

	para "I'm on the trail"
	line "of TEAM ROCKET!"
	done
