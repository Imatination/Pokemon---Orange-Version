_SSAnne2FWaiterText::
	text "This ship, she is"
	line "a luxury liner"
	cont "for trainers!"

	para "At every port, we"
	line "hold parties with"
	cont "invited trainers!"
	done

_SSAnne2FRivalText::
	text "<RIVAL>: Bonjour!"
	line "<PLAYER>!"

	para "Fancy meeting"
	line "you on this ship!"
	cont "Let's battle!"

	para "<PLAYER>: On a"
	line "boat? Sweet! I'll"
	cont "try not to sink"
	cont "it this time!"

	para "<RIVAL>: With"
	line "#MON, weirdo!"
	done

_SSAnne2FRivalDefeatedText::
	text "Humph!"

	para "At least you're"
	line "raising your"
	cont "#MON!"
	prompt

_SSAnne2FRivalVictoryText::
	text "<PLAYER>! What are"
	line "you, seasick?"

	para "You should shape"
	line "up, pal!"
	prompt

_SSAnne2FRivalCutMasterText::
	text "<RIVAL>: I heard"
	line "there was a CUT"
	cont "master on board."

	para "But, he was just a"
	line "seasick, old man!"

	para "But, CUT itself is"
	line "really useful!"

	para "You should go see"
	line "him! Smell ya!"
	done
