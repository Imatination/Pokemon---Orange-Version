_SSAnne2FRoomsGentleman3Text::
	text "In all my travels"
	line "I've never seen"
	cont "any #MON sleep"
	cont "like this one!"

	para "It was something"
	line "like this!"
	prompt

_SSAnne2FRoomsGentleman4Text::
	text "Ah yes, I have"
	line "seen some #MON"
	cont "ferry people"
	cont "across the water!"
	done

_SSAnne2FRoomsGrampsText::
	text "#MON can CUT"
	line "down small bushes."
	done

_SSAnne2FRoomsGentleman5Text::
	text "Have you gone to"
	line "the SAFARI ZONE"
	cont "in FUCHSIA CITY?"

	para "It had many rare"
	line "kinds of #MON!!"
	done

_SSAnne2FRoomsLittleBoyText::
	text "Me and my Daddy"
	line "think the SAFARI"
	cont "ZONE is awesome!"
	done

_SSAnne2FRoomsBrunetteGirlText::
	text "The CAPTAIN looked"
	line "really sick and"
	cont "pale!"
	done

_SSAnne2FRoomsBeautyText::
	text "I hear many people"
	line "get seasick!"
	done

_SSAnne2FRoomsGentleman1BattleText::
	text "They say you can"
	line "fly and shoot"
	cont "energy blasts!"
	cont "Battle me!"

	para "<PLAYER>: Sure!"
	line "Ready when you"
	cont "are!"
	done

_SSAnne2FRoomsGentleman1EndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_SSAnne2FRoomsGentleman1AfterBattleText::
	text "Wanna battle"
	line "again?"

	para "<PLAYER>: Only"
	line "if I'm allowed to"
	cont "punch something."
	done

_SSAnne2FRoomsFisherBattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done

_SSAnne2FRoomsFisherEndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_SSAnne2FRoomsFisherAfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_SSAnne2FRoomsGentleman2BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_SSAnne2FRoomsGentleman2EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_SSAnne2FRoomsGentleman2AfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done

_SSAnne2FRoomsCooltrainerFBattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_SSAnne2FRoomsCooltrainerFEndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_SSAnne2FRoomsCooltrainerFAfterBattleText::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done
