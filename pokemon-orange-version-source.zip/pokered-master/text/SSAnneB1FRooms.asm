_SSAnneB1FRoomsMachokeText::
	text "MACHOKE: Gwoh!"
	line "Goggoh!@"
	text_end

_SSAnneB1FRoomsSailor1BattleText::
	text "Prepare yourself!"
	line "This battle will"
	cont "be legendary!"

	para "<PLAYER>'s hair"
	line "flickered gold"
	cont "for a second."
	done

_SSAnneB1FRoomsSailor1EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_SSAnneB1FRoomsSailor1AfterBattleText::
	text "I'm still"
	line "catching my"
	cont "breath!"

	para "<PLAYER>: You sat"
	line "on a rock the"
	cont "whole time!"
	done

_SSAnneB1FRoomsSailor2BattleText::
	text "Stop right there!"
	line "You and me..."
	cont "BATTLE!"

	para "<PLAYER>: Yes!"
	line "Finally someone"
	cont "who gets it!"
	done

_SSAnneB1FRoomsSailor2EndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_SSAnneB1FRoomsSailor2AfterBattleText::
	text "Best battle of"
	line "my life!"

	para "<PLAYER>: But"
	line "you just stood"
	cont "there pointing!"
	done

_SSAnneB1FRoomsSailor3BattleText::
	text "Eek! It's you!"
	line "I'm so excited!"
	cont "Let's battle!"

	para "<PLAYER> started"
	line "to glow a little."
	done

_SSAnneB1FRoomsSailor3EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_SSAnneB1FRoomsSailor3AfterBattleText::
	text "Phew! That"
	line "battle was rough!"

	para "<PLAYER> did a"
	line "hundred push-ups"
	cont "out of boredom."
	done

_SSAnneB1FRoomsSailor4BattleText::
	text "I like feisty"
	line "kids like you!@"
	text_end

_SSAnneB1FRoomsSailor4EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_SSAnneB1FRoomsSailor4AfterBattleText::
	text "Some advice: use"
	line "type matchups!"

	para "<PLAYER>: What"
	line "about fist"
	cont "matchups?"
	done

_SSAnneB1FRoomsSailor5BattleText::
	text "I've trained my"
	line "whole life to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Hit me with your"
	cont "best shot!"
	done

_SSAnneB1FRoomsSailor5EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_SSAnneB1FRoomsSailor5AfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_SSAnneB1FRoomsFisherBattleText::
	text "Let's settle"
	line "this with a"
	cont "battle, champ!"

	para "<PLAYER> flexed."
	line "Bring it on!"
	done

_SSAnneB1FRoomsFisherEndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_SSAnneB1FRoomsFisherAfterBattleText::
	text "Nobody battles"
	line "like you do!"

	para "<PLAYER> mumbled"
	line "something about"
	cont "Kamehamehas."
	done

_SSAnneB1FRoomsSuperNerdText::
	text "My buddy, MACHOKE,"
	line "is super strong!"

	para "He has enough"
	line "STRENGTH to move"
	cont "big rocks!"
	done
