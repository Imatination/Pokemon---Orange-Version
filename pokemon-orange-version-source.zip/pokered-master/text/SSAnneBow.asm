_SSAnneBowSuperNerdText::
	text "The party's over."
	line "The ship will be"
	cont "departing soon."
	done

_SSAnneBowSailor1Text::
	text "Scrubbing decks"
	line "is hard work!"
	done

_SSAnneBowCooltrainerMText::
	text "Urf. I feel ill."

	para "I stepped out to"
	line "get some air."
	done

_SSAnneBowSailor2BattleText::
	text "I warmed up for"
	line "three whole hours"
	cont "for this battle!"

	para "<PLAYER>: Only"
	line "three? Well, it's"
	cont "a start!"
	done

_SSAnneBowSailor2EndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_SSAnneBowSailor2AfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done

_SSAnneBowSailor3BattleText::
	text "I'm gonna battle"
	line "you so hard!"

	para "<PLAYER> tied his"
	line "belt tighter."
	cont "Let's go!"
	done

_SSAnneBowSailor3EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_SSAnneBowSailor3AfterBattleText::
	text "Whoa, I'm sore"
	line "from that battle!"

	para "<PLAYER>: How?!"
	line "You didn't move!"
	done
