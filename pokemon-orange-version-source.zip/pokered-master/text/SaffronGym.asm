_SaffronGymSabrinaText::
	text "I had a vision"
	line "of your arrival."

	para "I foresaw an"
	line "amazing battle"
	cont "between us!"

	para "<PLAYER>: Did"
	line "you foresee me"
	cont "punching anyone?"

	para "...No. Only my"
	line "psychic #MON."

	para "<PLAYER>: Your"
	line "visions are"
	cont "kinda boring."
	done

_SaffronGymSabrinaReceivedMarshBadgeText::
	text "I'm"
	line "shocked!"
	cont "But, a loss is a"
	cont "loss."

	para "I admit I didn't"
	line "work hard enough"
	cont "to win!"

	para "You earned the"
	line "MARSHBADGE!@"
	text_end

_SaffronGymSabrinaPostBattleAdviceText::
	text "Everyone has"
	line "psychic power!"
	cont "People just don't"
	cont "realize it!"
	done

_SaffronGymSabrinaMarshBadgeInfoText::
	text "The MARSHBADGE"
	line "makes #MON up"
	cont "to L70 obey you!"

	para "Stronger #MON"
	line "will become wild,"
	cont "ignoring your"
	cont "orders in battle!"

	para "Just don't raise"
	line "your #MON too"
	cont "much!"

	para "Wait, please take"
	line "this TM with you!"
	done

_SaffronGymSabrinaReceivedTM46Text::
	text "<PLAYER> received"
	line "TM46!@"
	text_end

_TM46ExplanationText::
	text_start

	para "TM46 is PSYWAVE!"
	line "It uses powerful"
	cont "psychic waves to"
	cont "inflict damage!"
	done

_SaffronGymSabrinaTM46NoRoomText::
	text "Your pack is full"
	line "of other items!"
	done

_SaffronGymGuideChampInMakingText::
	text "Yo! Champ in"
	line "making!"

	para "SABRINA's #MON"
	line "use psychic power"
	cont "instead of force!"

	para "Fighting #MON"
	line "are weak against"
	cont "psychic #MON!"

	para "They get creamed"
	line "before they can"
	cont "even aim a punch!"
	done

_SaffronGymGuideBeatSabrinaText::
	text "Psychic power,"
	line "huh?"

	para "If I had that,"
	line "I'd make a bundle"
	cont "at the slots!"
	done

_SaffronGymChanneler1BattleText::
	text "Don't go easy on"
	line "me! I want your"
	cont "strongest battle!"

	para "<PLAYER>: My"
	line "strongest? You"
	cont "sure about that?"
	done

_SaffronGymChanneler1EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_SaffronGymChanneler1AfterBattleText::
	text "My hands are"
	line "still shaking!"

	para "<PLAYER>: Then"
	line "let's spar!"
	cont "Hey! Come back!"
	done

_SaffronGymYoungster1BattleText::
	text "Whoa! Are you"
	line "<PLAYER>? Let's"
	cont "battle right now!"

	para "<PLAYER> grinned"
	line "and cracked his"
	cont "knuckles. Yes!"
	done

_SaffronGymYoungster1EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_SaffronGymYoungster1AfterBattleText::
	text "Everyone talks"
	line "about how strong"
	cont "you are!"

	para "<PLAYER>: Then"
	line "why won't anyone"
	cont "fight me?!"
	done

_SaffronGymChanneler2BattleText::
	text "I've been"
	line "stretching all"
	cont "morning for you!"

	para "<PLAYER>: Ooh!"
	line "A real warrior!"
	cont "Come on!"
	done

_SaffronGymChanneler2EndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_SaffronGymChanneler2AfterBattleText::
	text "I'll never forget"
	line "our epic clash!"

	para "<PLAYER>: What"
	line "clash? Our hands"
	cont "never touched!"
	done

_SaffronGymYoungster2BattleText::
	text "You! Me! Battle!"
	line "No running away!"

	para "<PLAYER>: Run?"
	line "I never run from"
	cont "a good fight!"
	done

_SaffronGymYoungster2EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_SaffronGymYoungster2AfterBattleText::
	text "Let's battle"
	line "again tomorrow!"

	para "<PLAYER>: Can we"
	line "spar instead?"
	cont "...No? Okay."
	done

_SaffronGymChanneler3BattleText::
	text "You look tough!"
	line "Our battle will"
	cont "be epic!"

	para "<PLAYER>: I've"
	line "been waiting all"
	cont "day for this!"
	done

_SaffronGymChanneler3EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_SaffronGymChanneler3AfterBattleText::
	text "I can't believe"
	line "I battled THE"
	cont "<PLAYER>!"

	para "<PLAYER>: You"
	line "still haven't."
	cont "Not really."
	done

_SaffronGymYoungster3BattleText::
	text "I heard about"
	line "your power level!"
	cont "Battle me!"

	para "<PLAYER>: Wow,"
	line "you know about"
	cont "power levels?"
	done

_SaffronGymYoungster3EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_SaffronGymYoungster3AfterBattleText::
	text "You battle like"
	line "a true master!"

	para "<PLAYER>: I"
	line "didn't even get"
	cont "to warm up!"
	done

_SaffronGymYoungster4BattleText::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done

_SaffronGymYoungster4EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_SaffronGymYoungster4AfterBattleText::
	text "You're a battle"
	line "genius, <PLAYER>!"

	para "<PLAYER>: I"
	line "didn't battle!"
	cont "Your #MON did!"
	done
