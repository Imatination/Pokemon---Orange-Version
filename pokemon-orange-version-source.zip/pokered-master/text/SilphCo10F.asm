_SilphCo10FSilphWorkerFImScaredText::
	text "Waaaaa!"
	cont "I'm scared!"
	done

_SilphCo10FSilphWorkerFQuietAboutMyCryingText::
	text "Please keep quiet"
	line "about my crying!"
	done

_SilphCo10FRocketBattleText::
	text "My #MON and I"
	line "are fired up!"
	cont "Battle time!"

	para "<PLAYER>: Your"
	line "#MON? Wait..."
	cont "who do I punch?"
	done

_SilphCo10FRocketEndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_SilphCo10FRocketAfterBattleText::
	text "My #MON did"
	line "their best!"

	para "<PLAYER>: Great!"
	line "Now YOU do your"
	cont "best. Hands up!"

	para "...Huh? Battle's"
	line "over? Again?"
	done

_SilphCo10FScientistBattleText::
	text "Feel this aura?"
	line "It's my fighting"
	cont "spirit!"

	para "<PLAYER>: It's"
	line "tiny, but I like"
	cont "your attitude!"
	done

_SilphCo10FScientistEndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_SilphCo10FScientistAfterBattleText::
	text "Battle me again"
	line "after I train!"

	para "<PLAYER>: Try"
	line "gravity training!"
	cont "100x is fun!"
	done
