_SilphCo11FSilphPresidentText::
	text "PRESIDENT: Thank"
	line "you for saving"
	cont "SILPH!"

	para "I will never"
	line "forget you saved"
	cont "us in our moment"
	cont "of peril!"

	para "I have to thank"
	line "you in some way!"

	para "Because I am rich,"
	line "I can give you"
	cont "anything!"

	para "Here, maybe this"
	line "will do!"
	prompt

_SilphCo11FSilphPresidentReceivedMasterBallText::
	text "<PLAYER> got a"
	line "@"
	text_ram wStringBuffer
	text "!@"
	text_end

_SilphCo11FSilphPresidentMasterBallDescriptionText::
	text "PRESIDENT: You"
	line "can't buy that"
	cont "anywhere!"

	para "It's our secret"
	line "prototype MASTER"
	cont "BALL!"

	para "It will catch any"
	line "#MON without"
	cont "fail!"

	para "You should be"
	line "quiet about using"
	cont "it, though."
	done

_SilphCo11FSilphPresidentNoRoomText::
	text "You have no"
	line "room for this."
	done

_SilphCo11FBeautyText::
	text "SECRETARY: Thank"
	line "you for rescuing"
	cont "all of us!"

	para "We admire your"
	line "courage."
	done

_SilphCo11FGiovanniText::
	text "Ah <PLAYER>!"
	line "So we meet again!"

	para "The PRESIDENT and"
	line "I are discussing"
	cont "a vital business"
	cont "proposition."

	para "Keep your nose"
	line "out of grown-up"
	cont "matters..."

	para "Or, experience a"
	line "world of pain!"
	done

_SilphCo11FGiovanniILostAgainText::
	text "Arrgh!!"
	line "I lost again!?"
	prompt

_SilphCo11FGiovanniYouRuinedOurPlansText::
	text "Blast it all!"
	line "You ruined our"
	cont "plans for SILPH!"

	para "But, TEAM ROCKET"
	line "will never fall!"

	para "<PLAYER>! Never"
	line "forget that all"
	cont "#MON exist"
	cont "for TEAM ROCKET!"

	para "I must go, but I"
	line "shall return!"
	done

_SilphCo11FRocket1BattleText::
	text "Everyone says"
	line "you're the best"
	cont "fighter around!"

	para "<PLAYER> started"
	line "powering up."
	cont "Let's do this!"
	done

_SilphCo11FRocket1EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_SilphCo11FRocket1AfterBattleText::
	text "I gave that"
	line "battle everything"
	cont "I had!"

	para "<PLAYER>: You"
	line "threw a ball and"
	cont "shouted. Twice."
	done

_SilphCo11FRocket2BattleText::
	text "Our eyes met!"
	line "That means we"
	cont "have to battle!"

	para "<PLAYER>: I"
	line "LOVE that rule!"
	done

_SilphCo11FRocket2EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_SilphCo11FRocket2AfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_SilphCo11FPorygonText::
	text "The monitor has"
	line "#MON on it!"
	done
