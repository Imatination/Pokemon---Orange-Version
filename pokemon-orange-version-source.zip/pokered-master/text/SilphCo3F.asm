_SilphCo3FSilphWorkerMWhatShouldIDoText::
	text "I work for SILPH."
	line "What should I do?"
	done

_SilphCo3FSilphWorkerMYouSavedUsText::
	text "<PLAYER>! You and"
	line "your #MON"
	cont "saved us!"
	done

_SilphCo3FRocketBattleText::
	text "Is it true you"
	line "beat a guy who"
	cont "blew up planets?"
	cont "Battle me!"

	para "<PLAYER>: Gladly!"
	line "You must be"
	cont "super strong!"
	done

_SilphCo3FRocketEndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_SilphCo3FRocketAfterBattleText::
	text "I'm exhausted"
	line "after that fight!"

	para "<PLAYER>: From"
	line "what? Yelling"
	cont "move names?"
	done

_SilphCo3FScientistBattleText::
	text "My sensei said"
	line "to battle the"
	cont "strongest guy!"

	para "<PLAYER>: Your"
	line "sensei sounds"
	cont "awesome!"
	done

_SilphCo3FScientistEndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_SilphCo3FScientistAfterBattleText::
	text "Wanna battle"
	line "again?"

	para "<PLAYER>: Only"
	line "if I'm allowed to"
	cont "punch something."
	done
