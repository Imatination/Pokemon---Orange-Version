_SilphCo4FSilphWorkerMImHidingText::
	text "Sssh! Can't you"
	line "see I'm hiding?"
	done

_SilphCo4FSilphWorkerMTeamRocketIsGoneText::
	text "Huh? TEAM ROCKET"
	line "is gone?"
	done

_SilphCo4FRocket1BattleText::
	text "They say you can"
	line "fly and shoot"
	cont "energy blasts!"
	cont "Battle me!"

	para "<PLAYER>: Sure!"
	line "Ready when you"
	cont "are!"
	done

_SilphCo4FRocket1EndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_SilphCo4FRocket1AfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_SilphCo4FScientistBattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done

_SilphCo4FScientistEndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_SilphCo4FScientistAfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done

_SilphCo4FRocket2BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_SilphCo4FRocket2EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_SilphCo4FRocket2AfterBattleText::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done
