_SilphCo5FSilphWorkerMThatsYouRightText::
	text "TEAM ROCKET is"
	line "in an uproar over"
	cont "some intruder."
	cont "That's you right?"
	done

_SilphCo5FSilphWorkerMYoureOurHeroText::
	text "TEAM ROCKET took"
	line "off! You're our"
	cont "hero! Thank you!"
	done

_SilphCo5FRocket1BattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_SilphCo5FRocket1EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_SilphCo5FRocket1AfterBattleText::
	text "I'm still"
	line "catching my"
	cont "breath!"

	para "<PLAYER>: You sat"
	line "on a rock the"
	cont "whole time!"
	done

_SilphCo5FScientistBattleText::
	text "Prepare yourself!"
	line "This battle will"
	cont "be legendary!"

	para "<PLAYER>'s hair"
	line "flickered gold"
	cont "for a second."
	done

_SilphCo5FScientistEndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_SilphCo5FScientistAfterBattleText::
	text "Best battle of"
	line "my life!"

	para "<PLAYER>: But"
	line "you just stood"
	cont "there pointing!"
	done

_SilphCo5FRockerBattleText::
	text "Stop right there!"
	line "You and me..."
	cont "BATTLE!"

	para "<PLAYER>: Yes!"
	line "Finally someone"
	cont "who gets it!"
	done
