_SilphCo5FRockerEndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_SilphCo5FRockerAfterBattleText::
	text "Phew! That"
	line "battle was rough!"

	para "<PLAYER> did a"
	line "hundred push-ups"
	cont "out of boredom."
	done

_SilphCo5FRocket2BattleText::
	text "Eek! It's you!"
	line "I'm so excited!"
	cont "Let's battle!"

	para "<PLAYER> started"
	line "to glow a little."
	done

_SilphCo5FRocket2EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_SilphCo5FRocket2AfterBattleText::
	text "Some advice: use"
	line "type matchups!"

	para "<PLAYER>: What"
	line "about fist"
	cont "matchups?"
	done

_SilphCo5FPokemonReport1Text::
	text "It's a #MON"
	line "REPORT!"

	para "#MON LAB"
	line "created PORYGON,"
	cont "the first virtual"
	cont "reality #MON."
	done

_SilphCo5FPokemonReport2Text::
	text "It's a #MON"
	line "REPORT!"

	para "Over 160 #MON"
	line "techniques have"
	cont "been confirmed."
	done

_SilphCo5FPokemonReport3Text::
	text "It's a #MON"
	line "REPORT!"

	para "4 #MON evolve"
	line "only when traded"
	cont "by link-cable."
	done
