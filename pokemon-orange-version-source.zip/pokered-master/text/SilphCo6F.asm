_SilphCo6FSilphWorkerM1TookOverTheBuildingText::
	text "The ROCKETs came"
	line "and took over the"
	cont "building!"
	done

_SilphCo6FSilphWorkerM1BackToWorkText::
	text "Well, better get"
	line "back to work!"
	done

_SilphCo6FSilphWorkerMHelpMePleaseText::
	text "Oh dear, oh dear."
	line "Help me please!"
	done

_SilphCo6FSilphWorkerMWeGotEngagedText::
	text "We got engaged!"
	line "Heheh!"
	done

_SilphCo6FSilphWorkerF1SuchACowardText::
	text "Look at him! He's"
	line "such a coward!"
	done

_SilphCo6FSilphWorkerF1HaveToMarryHimText::
	text "I feel so sorry"
	line "for him, I have"
	cont "to marry him!"
	done

_SilphCo6FSilphWorkerF2TeamRocketConquerWorldText::
	text "TEAM ROCKET is"
	line "trying to conquer"
	cont "the world with"
	cont "#MON!"
	done

_SilphCo6FSilphWorkerF2TeamRocketRanText::
	text "TEAM ROCKET ran"
	line "because of you!"
	done

_SilphCo6FSilphWorkerM3TargetedSilphText::
	text "They must have"
	line "targeted SILPH"
	cont "for our #MON"
	cont "products."
	done

_SilphCo6FSilphWorkerM3WorkForSilphText::
	text "Come work for"
	line "SILPH when you"
	cont "get older!"
	done

_SilphCo6FRocket1BattleText::
	text "I've trained my"
	line "whole life to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Hit me with your"
	cont "best shot!"
	done

_SilphCo6FRocket1EndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_SilphCo6FRocket1AfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_SilphCo6FScientistBattleText::
	text "Let's settle"
	line "this with a"
	cont "battle, champ!"

	para "<PLAYER> flexed."
	line "Bring it on!"
	done

_SilphCo6FScientistEndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_SilphCo6FScientistAfterBattleText::
	text "Nobody battles"
	line "like you do!"

	para "<PLAYER> mumbled"
	line "something about"
	cont "Kamehamehas."
	done

_SilphCo6FRocket2BattleText::
	text "I warmed up for"
	line "three whole hours"
	cont "for this battle!"

	para "<PLAYER>: Only"
	line "three? Well, it's"
	cont "a start!"
	done

_SilphCo6FRocket2EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_SilphCo6FRocket2AfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done
