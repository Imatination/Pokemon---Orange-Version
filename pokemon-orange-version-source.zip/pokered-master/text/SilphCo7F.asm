_SilphCo7FSilphWorkerM1HaveThisPokemonText::
	text "Oh! Hi! You're"
	line "not a ROCKET! You"
	cont "came to save us?"
	cont "Why, thank you!"

	para "I want you to"
	line "have this #MON"
	cont "for saving us."
	prompt

_SilphCo7FSilphWorkerM1LaprasDescriptionText::
	text "It's LAPRAS. It's"
	line "very intelligent."

	para "We kept it in our"
	line "lab, but it will"
	cont "be much better"
	cont "off with you!"

	para "I think you will"
	line "be a good trainer"
	cont "for LAPRAS!"

	para "It's a good"
	line "swimmer. It'll"
	cont "give you a lift!"
	done

_SilphCo7FSilphWorkerM1IsOurPresidentOkText::
	text "TEAM ROCKET's"
	line "BOSS went to the"
	cont "boardroom! Is our"
	cont "PRESIDENT OK?"
	done

_SilphCo7FSilphWorkerM1SavedText::
	text "Saved at last!"
	line "Thank you!"
	done

_SilphCo7FSilphWorkerM2AfterTheMasterBallText::
	text "TEAM ROCKET was"
	line "after the MASTER"
	cont "BALL which will"
	cont "catch any #MON!"
	done

_SilphCo7FSilphWorkerM2CancelledMasterBallText::
	text "We canceled the"
	line "MASTER BALL"
	cont "project because"
	cont "of TEAM ROCKET."
	done

_SilphCo7FSilphWorkerM3ItWouldBeBadText::
	text "It would be bad"
	line "if TEAM ROCKET"
	cont "took over SILPH"
	cont "or our #MON!"
	done

_SilphCo7FSilphWorkerM3YouChasedOffTeamRocketText::
	text "Wow! You chased"
	line "off TEAM ROCKET"
	cont "all by yourself?"
	done

_SilphCo7FSilphWorkerM4ItsReallyDangerousHereText::
	text "You! It's really"
	line "dangerous here!"
	cont "You came to save"
	cont "me? You can't!"
	done

_SilphCo7FSilphWorkerM4SafeAtLastText::
	text "Safe at last!"
	line "Oh thank you!"
	done

_SilphCo7FRocket1BattleText::
	text "I'm gonna battle"
	line "you so hard!"

	para "<PLAYER> tied his"
	line "belt tighter."
	cont "Let's go!"
	done

_SilphCo7FRocket1EndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_SilphCo7FRocket1AfterBattleText::
	text "Whoa, I'm sore"
	line "from that battle!"

	para "<PLAYER>: How?!"
	line "You didn't move!"
	done

_SilphCo7FScientistBattleText::
	text "Don't go easy on"
	line "me! I want your"
	cont "strongest battle!"

	para "<PLAYER>: My"
	line "strongest? You"
	cont "sure about that?"
	done

_SilphCo7FScientistEndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_SilphCo7FScientistAfterBattleText::
	text "My hands are"
	line "still shaking!"

	para "<PLAYER>: Then"
	line "let's spar!"
	cont "Hey! Come back!"
	done

_SilphCo7FRocket2BattleText::
	text "Whoa! Are you"
	line "<PLAYER>? Let's"
	cont "battle right now!"

	para "<PLAYER> grinned"
	line "and cracked his"
	cont "knuckles. Yes!"
	done

_SilphCo7FRocket2EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_SilphCo7FRocket2AfterBattleText::
	text "Everyone talks"
	line "about how strong"
	cont "you are!"

	para "<PLAYER>: Then"
	line "why won't anyone"
	cont "fight me?!"
	done

_SilphCo7FRocket3BattleText::
	text "I've been"
	line "stretching all"
	cont "morning for you!"

	para "<PLAYER>: Ooh!"
	line "A real warrior!"
	cont "Come on!"
	done

_SilphCo7FRocket3EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_SilphCo7FRocket3AfterBattleText::
	text "I'll never forget"
	line "our epic clash!"

	para "<PLAYER>: What"
	line "clash? Our hands"
	cont "never touched!"
	done

_SilphCo7FRivalText::
	text "<RIVAL>: <PLAYER>!"
	line "Let's battle!"

	para "<PLAYER>: You"
	line "know what I'm"
	cont "gonna ask..."
	done

_SilphCo7FRivalWaitedHereText::
	text "<RIVAL>: Hahaha!"
	line "I thought you'd"
	cont "turn up if I"
	cont "waited here!"

	para "I guess TEAM"
	line "ROCKET slowed you"
	cont "down! Not that I"
	cont "care!"

	para "I saw you in"
	line "SAFFRON, so I"
	cont "decided to see if"
	cont "you got better!"
	done

_SilphCo7FRivalDefeatedText::
	text "Oh ho!"
	line "So, you are ready"
	cont "for BOSS ROCKET!"
	prompt

_SilphCo7FRivalVictoryText::
	text "<RIVAL>: How can"
	line "I put this?"

	para "You're not good"
	line "enough to play"
	cont "with us big boys!"
	prompt

_SilphCo7FRivalGoodLuckToYouText::
	text "Well, <PLAYER>!"

	para "I'm moving on up"
	line "and ahead!"

	para "By checking my"
	line "#DEX, I'm"
	cont "starting to see"
	cont "what's strong and"
	cont "how they evolve!"

	para "I'm going to the"
	line "#MON LEAGUE"
	cont "to boot out the"
	cont "ELITE FOUR!"

	para "I'll become the"
	line "world's most"
	cont "powerful trainer!"

	para "<PLAYER>, well"
	line "good luck to you!"
	cont "Don't sweat it!"
	cont "Smell ya!"
	done
