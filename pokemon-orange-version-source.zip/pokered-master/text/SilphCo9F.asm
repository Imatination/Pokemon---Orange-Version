SilphCo9FNurseYouLookTiredText::
	text "You look tired!"
	line "You should take a"
	cont "quick nap!"
	prompt

SilphCo9FNurseDontGiveUpText::
	text "Don't give up!"
	done

SilphCo9FNurseThankYouText::
	text "Thank you so"
	line "much!"
	done

_SilphCo9FRocket1BattleText::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done

_SilphCo9FRocket1EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_SilphCo9FRocket1AfterBattleText::
	text "You're a battle"
	line "genius, <PLAYER>!"

	para "<PLAYER>: I"
	line "didn't battle!"
	cont "Your #MON did!"
	done

_SilphCo9FScientistBattleText::
	text "My #MON and I"
	line "are fired up!"
	cont "Battle time!"

	para "<PLAYER>: Your"
	line "#MON? Wait..."
	cont "who do I punch?"
	done

_SilphCo9FScientistEndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_SilphCo9FScientistAfterBattleText::
	text "My #MON did"
	line "their best!"

	para "<PLAYER>: Great!"
	line "Now YOU do your"
	cont "best. Hands up!"

	para "...Huh? Battle's"
	line "over? Again?"
	done

_SilphCo9FRocket2BattleText::
	text "Feel this aura?"
	line "It's my fighting"
	cont "spirit!"

	para "<PLAYER>: It's"
	line "tiny, but I like"
	cont "your attitude!"
	done

_SilphCo9FRocket2EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_SilphCo9FRocket2AfterBattleText::
	text "Battle me again"
	line "after I train!"

	para "<PLAYER>: Try"
	line "gravity training!"
	cont "100x is fun!"
	done
