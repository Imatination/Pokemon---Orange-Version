_VermilionGymLTSurgePreBattleText::
	text "Hey, kid! I'm"
	line "LT.SURGE! I can't"
	cont "wait to battle"
	cont "you, soldier!"

	para "<PLAYER>: Ooh, a"
	line "soldier! You must"
	cont "be a tough guy!"

	para "Sure am! My"
	line "electric #MON"
	cont "will zap you!"

	para "<PLAYER>: Your"
	line "#MON. Not you."
	cont "Figures..."
	done
