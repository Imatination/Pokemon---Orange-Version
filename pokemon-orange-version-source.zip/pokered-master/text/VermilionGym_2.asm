_VermilionGymLTSurgePostBattleAdviceText::
	text "A little word of"
	line "advice, kid!"

	para "Electricity is"
	line "sure powerful!"

	para "But, it's useless"
	line "against ground-"
	cont "type #MON!"
	done

_VermilionGymLTSurgeThunderBadgeInfoText::
	text "The THUNDERBADGE"
	line "cranks up your"
	cont "#MON's SPEED!"

	para "It also lets your"
	line "#MON FLY any"
	cont "time, kid!"

	para "You're special,"
	line "kid! Take this!"
	done

_VermilionGymLTSurgeReceivedTM24Text::
	text "<PLAYER> received "
	line "@"
	text_ram wStringBuffer
	text "!@"
	text_end

_TM24ExplanationText::
	text_start

	para "TM24 contains"
	line "THUNDERBOLT!"

	para "Teach it to an"
	line "electric #MON!"
	done

_VermilionGymLTSurgeTM24NoRoomText::
	text "Yo kid, make room"
	line "in your pack!"
	done

_VermilionGymLTSurgeReceivedThunderBadgeText::
	text "Whoa!"

	para "You're the real"
	line "deal, kid!"

	para "Fine then, take"
	line "the THUNDERBADGE!"
	prompt

_VermilionGymGentlemanBattleText::
	text "Everyone says"
	line "you're the best"
	cont "fighter around!"

	para "<PLAYER> started"
	line "powering up."
	cont "Let's do this!"
	done

_VermilionGymGentlemanEndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_VermilionGymGentlemanAfterBattleText::
	text "I gave that"
	line "battle everything"
	cont "I had!"

	para "<PLAYER>: You"
	line "threw a ball and"
	cont "shouted. Twice."
	done

_VermilionGymSuperNerdBattleText::
	text "Our eyes met!"
	line "That means we"
	cont "have to battle!"

	para "<PLAYER>: I"
	line "LOVE that rule!"
	done

_VermilionGymSuperNerdEndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_VermilionGymSuperNerdAfterBattleText::
	text "That was such"
	line "a fierce fight!"

	para "<PLAYER>: Fierce?"
	line "Your #MON fell"
	cont "asleep halfway!"
	done

_VermilionGymSailorBattleText::
	text "I've got moves"
	line "you've never"
	cont "even seen!"

	para "<PLAYER>: Show"
	line "me! Show me!"
	done

_VermilionGymSailorEndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_VermilionGymSailorAfterBattleText::
	text "Did you feel"
	line "the tension in"
	cont "that battle?"

	para "<PLAYER>: I felt"
	line "hungry. That's"
	cont "about it."
	done

_VermilionGymGymGuideChampInMakingText::
	text "Yo! Champ in"
	line "making!"

	para "LT.SURGE has a"
	line "nickname. People"
	cont "refer to him as"
	cont "the Lightning"
	cont "American!"

	para "He's an expert on"
	line "electric #MON!"

	para "Birds and water"
	line "#MON are at"
	cont "risk! Beware of"
	cont "paralysis too!"

	para "LT.SURGE is very"
	line "cautious!"

	para "You'll have to"
	line "break a code to"
	cont "get to him!"
	done

_VermilionGymGymGuideBeatLTSurgeText::
	text "Whew! That match"
	line "was electric!"
	done
