_VictoryRoad2FMoltresBattleText::
	text "Gyaoo!@"
	text_end

_VictoryRoad2FHikerBattleText::
	text "My heart is"
	line "pounding! Battle"
	cont "me, <PLAYER>!"

	para "<PLAYER>: Now"
	line "we're talking!"
	cont "Don't hold back!"
	done

_VictoryRoad2FHikerEndBattleText::
	text "Ow!"
	line "My pride! Great"
	cont "battle!"
	prompt

_VictoryRoad2FHikerAfterBattleText::
	text "That battle"
	line "was electric!"

	para "<PLAYER>'s"
	line "stomach growled."
	cont "Lunch time, then."
	done

_VictoryRoad2FSuperNerd1BattleText::
	text "Is it true you"
	line "beat a guy who"
	cont "blew up planets?"
	cont "Battle me!"

	para "<PLAYER>: Gladly!"
	line "You must be"
	cont "super strong!"
	done

_VictoryRoad2FSuperNerd1EndBattleText::
	text "Phew"
	line "So intense!"
	prompt

_VictoryRoad2FSuperNerd1AfterBattleText::
	text "I'm exhausted"
	line "after that fight!"

	para "<PLAYER>: From"
	line "what? Yelling"
	cont "move names?"
	done

_VictoryRoad2FCooltrainerMBattleText::
	text "My sensei said"
	line "to battle the"
	cont "strongest guy!"

	para "<PLAYER>: Your"
	line "sensei sounds"
	cont "awesome!"
	done

_VictoryRoad2FCooltrainerMEndBattleText::
	text "Gah!"
	line "I lost in style,"
	cont "though!"
	prompt

_VictoryRoad2FCooltrainerMAfterBattleText::
	text "Wanna battle"
	line "again?"

	para "<PLAYER>: Only"
	line "if I'm allowed to"
	cont "punch something."
	done

_VictoryRoad2FSuperNerd2BattleText::
	text "They say you can"
	line "fly and shoot"
	cont "energy blasts!"
	cont "Battle me!"

	para "<PLAYER>: Sure!"
	line "Ready when you"
	cont "are!"
	done

_VictoryRoad2FSuperNerd2EndBattleText::
	text "Eek!"
	line "You didn't even"
	cont "break a sweat!"
	prompt

_VictoryRoad2FSuperNerd2AfterBattleText::
	text "You're my hero,"
	line "<PLAYER>!"

	para "<PLAYER>: Fight"
	line "me and I'll be"
	cont "your sensei!"

	para "...They ran off."
	done

_VictoryRoad2FSuperNerd3BattleText::
	text "Battle! Battle!"
	line "Battle! I can't"
	cont "wait any longer!"

	para "<PLAYER>: Me"
	line "neither! Hyah!"
	done

_VictoryRoad2FSuperNerd3EndBattleText::
	text "Ahh!"
	line "My #MON need"
	cont "a nap now!"
	prompt

_VictoryRoad2FSuperNerd3AfterBattleText::
	text "Want a rematch"
	line "sometime?"

	para "<PLAYER>: Only"
	line "if YOU fight me."
	cont "Not your pet."
	done
