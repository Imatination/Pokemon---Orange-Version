_VictoryRoad3FCooltrainerM1BattleText::
	text "Hey, strong guy!"
	line "I challenge you"
	cont "to a battle!"

	para "<PLAYER> dropped"
	line "into a fighting"
	cont "stance. Alright!"
	done

_VictoryRoad3FCooltrainerM1EndBattleText::
	text "Wow!"
	line "What an amazing"
	cont "battle!"
	prompt

_VictoryRoad3FCooltrainerM1AfterBattleText::
	text "You're so cool"
	line "when you battle!"

	para "<PLAYER>: I"
	line "just stood there!"
	cont "For ten minutes!"
	done

_VictoryRoad3FCooltrainerF1BattleText::
	text "Ha! I bet you"
	line "can't handle my"
	cont "battle style!"

	para "<PLAYER>: What"
	line "style? Crane?"
	cont "Turtle? Show me!"
	done

_VictoryRoad3FCooltrainerF1EndBattleText::
	text "Huh?"
	line "I lost already?"
	prompt

_VictoryRoad3FCooltrainerF1AfterBattleText::
	text "I'm still"
	line "catching my"
	cont "breath!"

	para "<PLAYER>: You sat"
	line "on a rock the"
	cont "whole time!"
	done

_VictoryRoad3FCooltrainerM2BattleText::
	text "Prepare yourself!"
	line "This battle will"
	cont "be legendary!"

	para "<PLAYER>'s hair"
	line "flickered gold"
	cont "for a second."
	done

_VictoryRoad3FCooltrainerM2EndBattleText::
	text "Aw!"
	line "Totally worth it!"
	cont "Great fight!"
	prompt

_VictoryRoad3FCooltrainerM2AfterBattleText::
	text "Best battle of"
	line "my life!"

	para "<PLAYER>: But"
	line "you just stood"
	cont "there pointing!"
	done

_VictoryRoad3FCooltrainerF2BattleText::
	text "Stop right there!"
	line "You and me..."
	cont "BATTLE!"

	para "<PLAYER>: Yes!"
	line "Finally someone"
	cont "who gets it!"
	done

_VictoryRoad3FCooltrainerF2EndBattleText::
	text "Whoa"
	line "That was the"
	cont "best battle ever!"
	prompt

_VictoryRoad3FCooltrainerF2AfterBattleText::
	text "Phew! That"
	line "battle was rough!"

	para "<PLAYER> did a"
	line "hundred push-ups"
	cont "out of boredom."
	done
