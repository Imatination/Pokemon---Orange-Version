_ViridianForestYoungster1Text::
	text "I came here with"
	line "some friends!"

	para "They're out for"
	line "#MON fights!"
	done

_ViridianForestYoungster2BattleText::
	text "Eek! It's you!"
	line "I'm so excited!"
	cont "Let's battle!"

	para "<PLAYER> started"
	line "to glow a little."
	done

_ViridianForestYoungster2EndBattleText::
	text "Ahh!"
	line "What a rush!"
	cont "Thanks, <PLAYER>!"
	prompt

_ViridianForestYoungster2AfterBattleText::
	text "Some advice: use"
	line "type matchups!"

	para "<PLAYER>: What"
	line "about fist"
	cont "matchups?"
	done

_ViridianForestYoungster3BattleText::
	text "I've trained my"
	line "whole life to"
	cont "battle you!"

	para "<PLAYER>: Me too!"
	line "Hit me with your"
	cont "best shot!"
	done

_ViridianForestYoungster3EndBattleText::
	text "Wow!"
	line "I'm gonna tell"
	cont "everyone!"
	prompt

_ViridianForestYoungster3AfterBattleText::
	text "That battle was"
	line "so intense!"

	para "<PLAYER> sighed."
	line "Nobody threw a"
	cont "single punch."
	done

_ViridianForestYoungster4BattleText::
	text "Let's settle"
	line "this with a"
	cont "battle, champ!"

	para "<PLAYER> flexed."
	line "Bring it on!"
	done

_ViridianForestYoungster4EndBattleText::
	text "Aww!"
	line "My #MON lost!"
	cont "But I had fun!"
	prompt

_ViridianForestYoungster4AfterBattleText::
	text "Nobody battles"
	line "like you do!"

	para "<PLAYER> mumbled"
	line "something about"
	cont "Kamehamehas."
	done

_ViridianForestYoungster5Text::
	text "I ran out of #"
	line "BALLs to catch"
	cont "#MON with!"

	para "You should carry"
	line "extras!"
	done

_ViridianForestTrainerTips1Text::
	text "TRAINER TIPS"

	para "If you want to"
	line "avoid battles,"
	cont "stay away from"
	cont "grassy areas!"
	done

_ViridianForestUseAntidoteSignText::
	text "For poison, use"
	line "ANTIDOTE! Get it"
	cont "at #MON MARTs!"
	done

_ViridianForestTrainerTips2Text::
	text "TRAINER TIPS"

	para "Contact PROF.OAK"
	line "via PC to get"
	cont "your #DEX"
	cont "evaluated!"
	done

_ViridianForestTrainerTips3Text::
	text "TRAINER TIPS"

	para "No stealing of"
	line "#MON from"
	cont "other trainers!"
	cont "Catch only wild"
	cont "#MON!"
	done

_ViridianForestTrainerTips4Text::
	text "TRAINER TIPS"

	para "Weaken #MON"
	line "before attempting"
	cont "capture!"

	para "When healthy,"
	line "they may escape!"
	done

_ViridianForestLeavingSignText::
	text "LEAVING"
	line "VIRIDIAN FOREST"
	cont "PEWTER CITY AHEAD"
	done
