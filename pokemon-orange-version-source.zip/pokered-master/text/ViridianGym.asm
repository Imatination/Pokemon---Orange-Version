_ViridianGymGiovanniPreBattleText::
	text "Fwahahaha! I've"
	line "longed to battle"
	cont "you, <PLAYER>!"

	para "<PLAYER>: A"
	line "big boss! You"
	cont "must be strong!"
	cont "Fight me!"

	para "I am! My #MON"
	line "are very strong!"

	para "<PLAYER> slumped."
	line "Not this again."
	done

_ViridianGymGiovanniReceivedEarthBadgeText::
	text "Ha!"
	line "That was a truly"
	cont "intense fight!"
	cont "You have won!"
	cont "As proof, here is"
	cont "the EARTHBADGE!@"
	text_end

_ViridianGymGiovanniPostBattleAdviceText::
	text "Having lost, I"
	line "cannot face my"
	cont "underlings!"
	cont "TEAM ROCKET is"
	cont "finished forever!"

	para "I will dedicate my"
	line "life to the study"
	cont "of #MON!"

	para "Let us meet again"
	line "some day!"
	cont "Farewell!@"
	text_end

_ViridianGymGiovanniEarthBadgeInfoText::
	text "The EARTHBADGE"
	line "makes #MON of"
	cont "any level obey!"

	para "It is evidence of"
	line "your mastery as a"
	cont "#MON trainer!"

	para "With it, you can"
	line "enter the #MON"
	cont "LEAGUE!"

	para "It is my gift for"
	line "your #MON"
	cont "LEAGUE challenge!"
	done

_ViridianGymGiovanniReceivedTM27Text::
	text "<PLAYER> received"
	line "TM27!@"
	text_end

_ViridianGymGiovanniTM27ExplanationText::
	text_start

	para "TM27 is FISSURE!"
	line "It will take out"
	cont "#MON with just"
	cont "one hit!"

	para "I made it when I"
	line "ran the GYM here,"
	cont "too long ago..."
	done

_ViridianGymGiovanniTM27NoRoomText::
	text "You do not have"
	line "space for this!"
	done

_ViridianGymCooltrainerM1BattleText::
	text "I warmed up for"
	line "three whole hours"
	cont "for this battle!"

	para "<PLAYER>: Only"
	line "three? Well, it's"
	cont "a start!"
	done

_ViridianGymCooltrainerM1EndBattleText::
	text "Wow!"
	line "Can I get your"
	cont "autograph?"
	prompt

_ViridianGymCooltrainerM1AfterBattleText::
	text "Our battle will"
	line "go down in"
	cont "history!"

	para "<PLAYER> yawned"
	line "and scratched"
	cont "his head."
	done

_ViridianGymHiker1BattleText::
	text "I'm gonna battle"
	line "you so hard!"

	para "<PLAYER> tied his"
	line "belt tighter."
	cont "Let's go!"
	done

_ViridianGymHiker1EndBattleText::
	text "Ahh!"
	line "My #MON!"
	prompt

_ViridianGymHiker1AfterBattleText::
	text "Whoa, I'm sore"
	line "from that battle!"

	para "<PLAYER>: How?!"
	line "You didn't move!"
	done

_ViridianGymRocker1BattleText::
	text "Don't go easy on"
	line "me! I want your"
	cont "strongest battle!"

	para "<PLAYER>: My"
	line "strongest? You"
	cont "sure about that?"
	done

_ViridianGymRocker1EndBattleText::
	text "Wow!"
	line "You are so"
	cont "strong!"
	prompt

_ViridianGymRocker1AfterBattleText::
	text "My hands are"
	line "still shaking!"

	para "<PLAYER>: Then"
	line "let's spar!"
	cont "Hey! Come back!"
	done

_ViridianGymHiker2BattleText::
	text "Whoa! Are you"
	line "<PLAYER>? Let's"
	cont "battle right now!"

	para "<PLAYER> grinned"
	line "and cracked his"
	cont "knuckles. Yes!"
	done

_ViridianGymHiker2EndBattleText::
	text "Yes!"
	line "You're the real"
	cont "deal, <PLAYER>!"
	prompt

_ViridianGymHiker2AfterBattleText::
	text "Everyone talks"
	line "about how strong"
	cont "you are!"

	para "<PLAYER>: Then"
	line "why won't anyone"
	cont "fight me?!"
	done

_ViridianGymCooltrainerM2BattleText::
	text "I've been"
	line "stretching all"
	cont "morning for you!"

	para "<PLAYER>: Ooh!"
	line "A real warrior!"
	cont "Come on!"
	done

_ViridianGymCooltrainerM2EndBattleText::
	text "Ugh!"
	line "You're way too"
	cont "powerful!"
	prompt

_ViridianGymCooltrainerM2AfterBattleText::
	text "I'll never forget"
	line "our epic clash!"

	para "<PLAYER>: What"
	line "clash? Our hands"
	cont "never touched!"
	done

_ViridianGymHiker3BattleText::
	text "You! Me! Battle!"
	line "No running away!"

	para "<PLAYER>: Run?"
	line "I never run from"
	cont "a good fight!"
	done

_ViridianGymHiker3EndBattleText::
	text "Ugh!"
	line "I lost! But my"
	cont "heart is racing!"
	prompt

_ViridianGymHiker3AfterBattleText::
	text "Let's battle"
	line "again tomorrow!"

	para "<PLAYER>: Can we"
	line "spar instead?"
	cont "...No? Okay."
	done

_ViridianGymRocker2BattleText::
	text "You look tough!"
	line "Our battle will"
	cont "be epic!"

	para "<PLAYER>: I've"
	line "been waiting all"
	cont "day for this!"
	done

_ViridianGymRocker2EndBattleText::
	text "No!"
	line "I've never lost"
	cont "so fast!"
	prompt

_ViridianGymRocker2AfterBattleText::
	text "I can't believe"
	line "I battled THE"
	cont "<PLAYER>!"

	para "<PLAYER>: You"
	line "still haven't."
	cont "Not really."
	done

_ViridianGymCooltrainerM3BattleText::
	text "I heard about"
	line "your power level!"
	cont "Battle me!"

	para "<PLAYER>: Wow,"
	line "you know about"
	cont "power levels?"
	done

_ViridianGymCooltrainerM3EndBattleText::
	text "Oh!"
	line "So that's the"
	cont "famous <PLAYER>!"
	prompt

_ViridianGymCooltrainerM3AfterBattleText::
	text "You battle like"
	line "a true master!"

	para "<PLAYER>: I"
	line "didn't even get"
	cont "to warm up!"
	done

_ViridianGymGuidePreBattleText::
	text "Yo! Champ in"
	line "making!"

	para "Even I don't know"
	line "VIRIDIAN LEADER's"
	cont "identity!"

	para "This will be the"
	line "toughest of all"
	cont "the GYM LEADERs!"

	para "I heard that the"
	line "trainers here"
	cont "like ground-type"
	cont "#MON!"
	done

_ViridianGymGuidePostBattleText::
	text "Fight me! Er, I"
	line "mean, battle me!"

	para "<PLAYER>: Fight!"
	line "You said fight!"
	cont "No take-backs!"
	done
